import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok } from "@/lib/api";
import { z } from "zod";
import { auth } from "@/auth";
import { asRole, type SessionUser } from "@/lib/rbac";
import { normalizeText, normalizePhone } from "@/lib/search/normalize";
import { rateLimit } from "@/lib/rate-limit";

const querySchema = z.object({
  q: z.string().trim().min(1).max(120),
  modules: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = {
    id: session.user.id,
    role: asRole(session.user.role),
    managerId: session.user.managerId ?? null,
  };

  const limitResult = rateLimit(`search:${user.id}`, 60, 60_000);
  if (!limitResult.ok) {
    throw new Error("rate_limited");
  }

  const query = querySchema.parse(Object.fromEntries(new URL(req.url).searchParams));
  const normalized = normalizeText(query.q);
  const phoneNormalized = normalizePhone(query.q);

  const modules = query.modules
    ? query.modules.split(",").map((item) => item.trim()).filter(Boolean)
    : undefined;

  const where: Record<string, unknown> = {
    OR: [
      { normalizedText: { contains: normalized } },
      ...(phoneNormalized ? [{ normalizedText: { contains: phoneNormalized } }] : []),
    ],
  };

  if (modules && modules.length > 0) {
    where.entityType = { in: modules };
  }

  if (user.role === "AGENT") {
    where.ownerAgentId = user.id;
  } else if (user.role === "MANAGER") {
    // manager sees own + direct reports; filter in JS after fetch for simplicity
  }

  let rows = await prisma.searchIndex.findMany({
    where,
    take: query.limit * 2,
    orderBy: { updatedAt: "desc" },
  });

  if (user.role === "MANAGER") {
    const reports = await prisma.user.findMany({ where: { managerId: user.id }, select: { id: true } });
    const allowed = new Set([user.id, ...reports.map((r) => r.id)]);
    rows = rows.filter((row) => !row.ownerAgentId || allowed.has(row.ownerAgentId));
  }

  // Boost owned records
  rows.sort((a, b) => {
    const aOwned = a.ownerAgentId === user.id ? 1 : 0;
    const bOwned = b.ownerAgentId === user.id ? 1 : 0;
    if (aOwned !== bOwned) return bOwned - aOwned;
    const aExact = a.normalizedText.startsWith(normalized) ? 1 : 0;
    const bExact = b.normalizedText.startsWith(normalized) ? 1 : 0;
    if (aExact !== bExact) return bExact - aExact;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });

  const results = rows.slice(0, query.limit).map((row) => ({
    entityType: row.entityType,
    entityId: row.entityId,
    title: row.title,
    subtitle: row.subtitle,
    updatedAt: row.updatedAt,
  }));

  // Log history
  await prisma.searchHistory.create({
    data: { userId: user.id, query: query.q },
  });

  return ok({ q: query.q, results, total: results.length });
});
