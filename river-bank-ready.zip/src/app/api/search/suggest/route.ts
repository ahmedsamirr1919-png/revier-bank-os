import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok } from "@/lib/api";
import { z } from "zod";
import { auth } from "@/auth";
import { asRole, type SessionUser } from "@/lib/rbac";
import { normalizeText } from "@/lib/search/normalize";
import { rateLimit } from "@/lib/rate-limit";

const querySchema = z.object({
  q: z.string().trim().min(1).max(120),
});

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = {
    id: session.user.id,
    role: asRole(session.user.role),
    managerId: session.user.managerId ?? null,
  };

  const limitResult = rateLimit(`suggest:${user.id}`, 60, 60_000);
  if (!limitResult.ok) throw new Error("rate_limited");

  const query = querySchema.parse(Object.fromEntries(new URL(req.url).searchParams));
  const normalized = normalizeText(query.q);

  const where: Record<string, unknown> = {
    normalizedText: { contains: normalized },
  };
  if (user.role === "AGENT") where.ownerAgentId = user.id;

  const rows = await prisma.searchIndex.findMany({
    where,
    take: 8,
    orderBy: { updatedAt: "desc" },
    select: { title: true, entityType: true, entityId: true },
  });

  return ok(rows);
});
