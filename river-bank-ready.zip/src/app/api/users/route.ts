import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, paginated, parseBody, parseQuery, requireUser } from "@/lib/api";
import { z } from "zod";
import { hashSync } from "bcryptjs";
import { asRole, type SessionUser } from "@/lib/rbac";
import { auth } from "@/auth";

const createSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email(),
  password: z.string().min(8).max(128),
  role: z.enum(["ADMIN", "MANAGER", "AGENT"]).default("AGENT"),
  managerId: z.string().optional().nullable(),
  isActive: z.boolean().default(true),
});

const listQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  q: z.string().trim().max(120).optional(),
});

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");

  const query = parseQuery(req, listQuery);
  const where: Record<string, unknown> = {};
  if (query.q) {
    where.OR = [
      { name: { contains: query.q } },
      { email: { contains: query.q } },
    ];
  }

  const [total, items] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where,
      orderBy: { createdAt: "asc" },
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        mustChangePassword: true,
        managerId: true,
        manager: { select: { id: true, name: true } },
        createdAt: true,
      },
    }),
  ]);

  return ok(paginated(items, total, query.page, query.pageSize));
});

export const POST = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");

  const input = await parseBody(req, createSchema);
  const passwordHash = hashSync(input.password, 12);

  const created = await prisma.user.create({
    data: {
      name: input.name,
      email: input.email,
      passwordHash,
      role: input.role,
      managerId: input.managerId ?? null,
      isActive: input.isActive,
    },
    select: { id: true, name: true, email: true, role: true, isActive: true, managerId: true },
  });

  return ok(created, 201);
});
