import { prisma } from "@/lib/prisma";
import { handle, ok, requireUser } from "@/lib/api";
import { assignableAgentWhere } from "@/lib/rbac";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  const agents = await prisma.user.findMany({
    where: assignableAgentWhere(user),
    orderBy: [{ role: "asc" }, { name: "asc" }],
    select: { id: true, name: true, email: true, role: true },
  });
  return ok({ items: agents });
});
