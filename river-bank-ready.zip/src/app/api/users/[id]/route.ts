import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, notFound, ok, parseBody } from "@/lib/api";
import { z } from "zod";
import { asRole, type SessionUser } from "@/lib/rbac";
import { auth } from "@/auth";

const updateSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  email: z.string().trim().email().optional(),
  role: z.enum(["ADMIN", "MANAGER", "AGENT"]).optional(),
  managerId: z.string().nullable().optional(),
  isActive: z.boolean().optional(),
  password: z.string().min(8).max(128).optional(),
});

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const PATCH = handle<Ctx>(async (req: NextRequest, { params }) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");

  const { id } = await params;
  const input = await parseBody(req, updateSchema);

  const data: Record<string, unknown> = {};
  if (input.name !== undefined) data.name = input.name;
  if (input.email !== undefined) data.email = input.email;
  if (input.role !== undefined) data.role = input.role;
  if (input.managerId !== undefined) data.managerId = input.managerId;
  if (input.isActive !== undefined) data.isActive = input.isActive;
  if (input.password) {
    const { hashSync } = await import("bcryptjs");
    data.passwordHash = hashSync(input.password, 12);
    data.mustChangePassword = true;
  }

  const existing = await prisma.user.findUnique({ where: { id }, select: { id: true } });
  if (!existing) return notFound("User not found");

  const updated = await prisma.user.update({
    where: { id },
    data,
    select: { id: true, name: true, email: true, role: true, isActive: true, managerId: true },
  });

  return ok(updated);
});

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");

  const { id } = await params;
  if (id === session.user.id) throw new Error("cannot_delete_self");

  const existing = await prisma.user.findUnique({ where: { id }, select: { id: true } });
  if (!existing) return notFound("User not found");

  await prisma.user.delete({ where: { id } });
  return ok({ id, deleted: true });
});
