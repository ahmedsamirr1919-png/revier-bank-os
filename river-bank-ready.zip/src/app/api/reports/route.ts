import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok } from "@/lib/api";
import { asRole, customerScope, dealScope, feedbackScope, type SessionUser } from "@/lib/rbac";
import { auth } from "@/auth";

export const dynamic = "force-dynamic";

function parseDate(value: string | null, fallback: Date) {
  if (!value) return fallback;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? fallback : date;
}

function monthKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export const GET = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) {
    throw new Error("unauthorized");
  }
  const user: SessionUser = {
    id: session.user.id,
    role: asRole(session.user.role),
    managerId: session.user.managerId ?? null,
  };

  const { searchParams } = new URL(req.url);
  const now = new Date();
  const defaultFrom = new Date(now.getFullYear(), now.getMonth(), 1);
  const defaultTo = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
  const from = parseDate(searchParams.get("from"), defaultFrom);
  const to = parseDate(searchParams.get("to"), defaultTo);

  const customerWhere = { ...customerScope(user), isDeleted: false };
  const dealWhere = { ...dealScope(user), isDeleted: false };
  const scopedDeals = { ...dealWhere, createdAt: { gte: from, lte: to } };
  const scopedClosed = { ...dealWhere, stage: "CLOSED_WON", closedAt: { gte: from, lte: to } };
  const scopedCustomers = { ...customerWhere, createdAt: { gte: from, lte: to } };
  const scopedFeedback = { ...feedbackScope(user), createdAt: { gte: from, lte: to } };

  const [
    totalCustomers,
    newCustomers,
    deals,
    closedDeals,
    feedbackRows,
    dealStageGroups,
    sourceGroups,
  ] = await Promise.all([
    prisma.customer.count({ where: customerWhere }),
    prisma.customer.count({ where: scopedCustomers }),
    prisma.deal.findMany({
      where: scopedDeals,
      select: { id: true, value: true, stage: true, agentId: true, agent: { select: { name: true } }, customerId: true },
    }),
    prisma.deal.findMany({
      where: scopedClosed,
      select: { value: true, commissionAmount: true, agentId: true, agent: { select: { name: true } } },
    }),
    prisma.feedback.findMany({
      where: scopedFeedback,
      select: { rating: true, isNegative: true, status: true, categories: true, agentId: true, agent: { select: { name: true } } },
    }),
    prisma.deal.groupBy({ by: ["stage"], where: scopedDeals, _count: { _all: true } }),
    prisma.customer.groupBy({ by: ["source"], where: scopedCustomers, _count: { _all: true } }),
  ]);

  const totalDeals = deals.length;
  const wonDeals = closedDeals.length;
  const lostDeals = deals.filter((deal) => deal.stage === "CLOSED_LOST").length;
  const revenue = closedDeals.reduce((sum, deal) => sum + deal.value, 0);
  const commission = closedDeals.reduce((sum, deal) => sum + deal.commissionAmount, 0);
  const winRate = totalDeals ? Math.round((wonDeals / totalDeals) * 100) : 0;
  const avgDealSize = wonDeals ? Math.round(revenue / wonDeals) : 0;

  // Re-query closed deals with closedAt for monthly
  const closedWithDate = await prisma.deal.findMany({
    where: scopedClosed,
    select: { closedAt: true, value: true },
  });
  const months = new Map<string, number>();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(to);
    d.setMonth(d.getMonth() - i);
    const key = monthKey(d);
    months.set(key, 0);
  }
  for (const deal of closedWithDate) {
    if (!deal.closedAt) continue;
    const key = monthKey(deal.closedAt);
    if (months.has(key)) months.set(key, (months.get(key) ?? 0) + deal.value);
  }
  const monthlySales = [...months.entries()].map(([key, value]) => {
    const [year, month] = key.split("-");
    return { month: `${month}/${year.slice(2)}`, revenue: value };
  });

  const agentMap = new Map<string, { name: string; dealsWon: number; revenue: number; commission: number }>();
  for (const deal of closedDeals) {
    const name = deal.agent?.name ?? "—";
    const entry = agentMap.get(name) ?? { name, dealsWon: 0, revenue: 0, commission: 0 };
    entry.dealsWon += 1;
    entry.revenue += deal.value;
    entry.commission += deal.commissionAmount;
    agentMap.set(name, entry);
  }
  const agentPerformance = [...agentMap.values()].sort((a, b) => b.revenue - a.revenue);

  const ratingValues = feedbackRows.map((row) => row.rating).filter((rating) => rating > 0);
  const avgRating = ratingValues.length
    ? Number((ratingValues.reduce((sum, value) => sum + value, 0) / ratingValues.length).toFixed(1))
    : 0;
  const negativeFeedback = feedbackRows.filter((row) => row.isNegative).length;
  const resolvedFeedback = feedbackRows.filter((row) => row.status === "RESOLVED").length;

  return ok({
    period: { from, to },
    summary: {
      totalCustomers,
      newCustomers,
      totalDeals,
      wonDeals,
      lostDeals,
      revenue,
      commission,
      winRate,
      avgDealSize,
      avgRating,
      totalFeedback: feedbackRows.length,
      negativeFeedback,
      resolvedFeedback,
    },
    dealsByStage: dealStageGroups.map((group) => ({ stage: group.stage, count: group._count._all })),
    leadsBySource: sourceGroups.map((group) => ({ source: group.source, count: group._count._all })),
    monthlySales,
    agentPerformance,
  });
});
