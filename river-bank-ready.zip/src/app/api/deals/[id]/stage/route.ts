import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, parseBody, requireUser } from "@/lib/api";
import { dealStageSchema } from "@/lib/validation/deal";
import { dealAccessWhere } from "@/lib/access";
import { dealListSelect, TERMINAL_DEAL_STAGES } from "@/lib/queries/deals";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const PATCH = handle<Ctx>(async (req: NextRequest, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, dealStageSchema);

  const existing = await prisma.deal.findFirst({
    where: dealAccessWhere(user, id),
    select: { id: true, code: true, stage: true, propertyId: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Deal not found");

  if (existing.stage === input.stage) {
    return ok({ id, stage: input.stage, changed: false });
  }

  const deal = await prisma.deal.update({
    where: { id },
    data: {
      stage: input.stage,
      closedAt: TERMINAL_DEAL_STAGES.includes(input.stage) ? new Date() : null,
      lostReason: input.stage === "CLOSED_LOST" ? input.lostReason ?? null : null,
      stageHistory: {
        create: {
          fromStage: existing.stage,
          toStage: input.stage,
          changedById: user.id,
          changedByName: user.name,
          note: input.note ?? (input.stage === "CLOSED_LOST" ? input.lostReason ?? null : null),
        },
      },
    },
    select: dealListSelect,
  });

  if (input.stage === "CLOSED_WON" && existing.propertyId) {
    await prisma.property.update({
      where: { id: existing.propertyId },
      data: { status: "SOLD" },
    });
  }

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "STATUS_CHANGE",
    entityType: "Deal",
    entityId: deal.id,
    description: `Changed deal ${deal.code} stage: ${existing.stage} → ${deal.stage}`,
    metadata: { from: existing.stage, to: deal.stage, note: input.note ?? null },
  });

  return ok(deal);
});
