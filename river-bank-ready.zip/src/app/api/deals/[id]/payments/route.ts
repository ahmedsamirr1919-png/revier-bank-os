import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { z } from "zod";
import { dealAccessWhere } from "@/lib/access";
import { asRole, type SessionUser } from "@/lib/rbac";
import { auth } from "@/auth";

const createSchema = z.object({
  amount: z.coerce.number().int().positive(),
  currency: z.string().trim().max(3).default("EGP"),
  method: z.enum(["CASH", "BANK_TRANSFER", "CARD", "CHEQUE"]).default("BANK_TRANSFER"),
  status: z.enum(["PAID", "PENDING", "OVERDUE"]).default("PAID"),
  paidAt: z.coerce.date().optional(),
  dueAt: z.coerce.date().optional().nullable(),
  receiptUrl: z.string().trim().url().max(600).optional().nullable(),
  notes: z.string().trim().max(1000).optional().nullable(),
});

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const GET = handle<Ctx>(async (_req, { params }) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };

  const { id } = await params;
  const deal = await prisma.deal.findFirst({
    where: dealAccessWhere(user, id),
    select: { id: true },
  });
  if (!deal) throw new Error("not_found");

  const payments = await prisma.dealPayment.findMany({
    where: { dealId: id },
    orderBy: { paidAt: "desc" },
    include: { createdBy: { select: { id: true, name: true } } },
  });
  return ok(payments);
});

export const POST = handle<Ctx>(async (req, { params }) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };

  const { id } = await params;
  const deal = await prisma.deal.findFirst({
    where: dealAccessWhere(user, id),
    select: { id: true },
  });
  if (!deal) throw new Error("not_found");

  const input = await parseBody(req, createSchema);
  const payment = await prisma.dealPayment.create({
    data: {
      dealId: id,
      amount: input.amount,
      currency: input.currency,
      method: input.method,
      status: input.status,
      paidAt: input.paidAt ?? new Date(),
      dueAt: input.dueAt ?? null,
      receiptUrl: input.receiptUrl ?? null,
      notes: input.notes ?? null,
      createdById: user.id,
    },
  });
  return ok(payment, 201);
});
