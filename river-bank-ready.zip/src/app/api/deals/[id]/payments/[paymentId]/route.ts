import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, notFound, ok, parseBody } from "@/lib/api";
import { z } from "zod";
import { dealAccessWhere } from "@/lib/access";
import { asRole, type SessionUser } from "@/lib/rbac";
import { auth } from "@/auth";

const updateSchema = z.object({
  status: z.enum(["PAID", "PENDING", "OVERDUE"]).optional(),
  notes: z.string().trim().max(1000).optional().nullable(),
  receiptUrl: z.string().trim().url().max(600).optional().nullable(),
});

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string; paymentId: string }> };

export const PATCH = handle<Ctx>(async (req, { params }) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };

  const { id, paymentId } = await params;
  const deal = await prisma.deal.findFirst({ where: dealAccessWhere(user, id), select: { id: true } });
  if (!deal) throw new Error("not_found");

  const payment = await prisma.dealPayment.findFirst({ where: { id: paymentId, dealId: id } });
  if (!payment) return notFound("Payment not found");

  const input = await parseBody(req, updateSchema);
  const updated = await prisma.dealPayment.update({
    where: { id: paymentId },
    data: {
      ...(input.status !== undefined ? { status: input.status } : {}),
      ...(input.notes !== undefined ? { notes: input.notes } : {}),
      ...(input.receiptUrl !== undefined ? { receiptUrl: input.receiptUrl } : {}),
    },
  });
  return ok(updated);
});

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };

  const { id, paymentId } = await params;
  const deal = await prisma.deal.findFirst({ where: dealAccessWhere(user, id), select: { id: true } });
  if (!deal) throw new Error("not_found");

  const payment = await prisma.dealPayment.findFirst({ where: { id: paymentId, dealId: id } });
  if (!payment) return notFound("Payment not found");

  await prisma.dealPayment.delete({ where: { id: paymentId } });
  return ok({ id: paymentId, deleted: true });
});
