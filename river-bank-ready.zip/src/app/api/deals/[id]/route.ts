import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, notFound, ok, parseBody, requireUser } from "@/lib/api";
import { dealInputSchema } from "@/lib/validation/deal";
import { dealAccessWhere, assertAssignableAgent, assertCustomerAccess, resolveAssigneeId } from "@/lib/access";
import { commissionFor, dealListSelect, TERMINAL_DEAL_STAGES } from "@/lib/queries/deals";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const GET = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id } = await params;

  const deal = await prisma.deal.findFirst({
    where: dealAccessWhere(user, id, { allowDeleted: true }),
    include: {
      customer: {
        select: {
          id: true,
          code: true,
          fullName: true,
          phone: true,
          email: true,
          status: true,
          assignedAgentId: true,
        },
      },
      property: { select: { id: true, code: true, title: true, status: true, price: true } },
      agent: { select: { id: true, name: true, email: true } },
      stageHistory: {
        orderBy: { createdAt: "desc" },
        take: 50,
      },
      tasks: {
        orderBy: { dueAt: "asc" },
        take: 20,
        select: {
          id: true,
          title: true,
          type: true,
          priority: true,
          status: true,
          dueAt: true,
          assignedTo: { select: { id: true, name: true } },
        },
      },
    },
  });

  if (!deal) return notFound("Deal not found");
  return ok(deal);
});

export const PATCH = handle<Ctx>(async (req: NextRequest, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, dealInputSchema);

  const existing = await prisma.deal.findFirst({
    where: dealAccessWhere(user, id),
    select: { id: true, code: true, title: true, stage: true, propertyId: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Deal not found");

  const customer = await assertCustomerAccess(user, input.customerId);
  const agent = await assertAssignableAgent(user, resolveAssigneeId(user, input.agentId));
  if (input.propertyId) {
    const property = await prisma.property.findFirst({
      where: { id: input.propertyId, isDeleted: false },
      select: { id: true },
    });
    if (!property) throw new ApiError("invalid_property", 422, "Property not found");
  }

  const stageChanged = input.stage !== existing.stage;
  const now = new Date();
  const closedAt = TERMINAL_DEAL_STAGES.includes(input.stage)
    ? existing.stage === input.stage
      ? undefined
      : now
    : null;

  const deal = await prisma.deal.update({
    where: { id },
    data: {
      title: input.title,
      customerId: customer.id,
      propertyId: input.propertyId ?? null,
      agentId: agent.id,
      value: input.value,
      currency: input.currency,
      commissionRate: input.commissionRate,
      commissionAmount: commissionFor(input.value, input.commissionRate),
      stage: input.stage,
      ...(input.probability !== undefined ? { probability: input.probability } : {}),
      expectedCloseDate: input.expectedCloseDate ?? null,
      ...(closedAt !== undefined ? { closedAt } : {}),
      lostReason: input.stage === "CLOSED_LOST" ? input.lostReason ?? null : null,
      notes: input.notes ?? null,
      ...(stageChanged
        ? {
            stageHistory: {
              create: {
                fromStage: existing.stage,
                toStage: input.stage,
                changedById: user.id,
                changedByName: user.name,
                note: input.stage === "CLOSED_LOST" ? input.lostReason ?? null : null,
              },
            },
          }
        : {}),
    },
    select: dealListSelect,
  });

  if (input.stage === "CLOSED_WON" && input.propertyId) {
    await prisma.property.update({ where: { id: input.propertyId }, data: { status: "SOLD" } });
  }

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: stageChanged ? "STATUS_CHANGE" : "UPDATE",
    entityType: "Deal",
    entityId: deal.id,
    description: stageChanged
      ? `Changed deal ${deal.code} stage: ${existing.stage} → ${deal.stage}`
      : `Updated deal ${deal.code} (${deal.title})`,
    metadata: stageChanged ? { from: existing.stage, to: deal.stage } : { value: deal.value },
  });

  return ok(deal);
});

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id } = await params;

  const existing = await prisma.deal.findFirst({
    where: { ...dealAccessWhere(user, id), isDeleted: false },
    select: { id: true, code: true, title: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Deal not found");

  await prisma.deal.update({ where: { id }, data: { isDeleted: true, deletedAt: new Date() } });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "DELETE",
    entityType: "Deal",
    entityId: id,
    description: `Deleted deal ${existing.code} (${existing.title})`,
  });

  return ok({ id, deleted: true });
});
