import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, paginated, parseBody, parseQuery, requireUser } from "@/lib/api";
import { dealInputSchema, dealListQuery } from "@/lib/validation/deal";
import { dealListSelect, dealOrderBy, dealWhere, commissionFor, TERMINAL_DEAL_STAGES } from "@/lib/queries/deals";
import { assertAssignableAgent, assertCustomerAccess, resolveAssigneeId } from "@/lib/access";
import { canDelete } from "@/lib/rbac";
import { createWithCode } from "@/lib/codes";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

const TERMINAL_STAGES = TERMINAL_DEAL_STAGES;

export const GET = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const query = parseQuery(req, dealListQuery);
  const trash = query.trash === "1" && canDelete(user.role);
  const where = dealWhere(user, query, trash);

  const [total, items] = await Promise.all([
    prisma.deal.count({ where }),
    prisma.deal.findMany({
      where,
      orderBy: dealOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: dealListSelect,
    }),
  ]);

  return ok(paginated(items, total, query.page, query.pageSize));
});

export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const input = await parseBody(req, dealInputSchema);

  const customer = await assertCustomerAccess(user, input.customerId);
  const agentId = resolveAssigneeId(user, input.agentId);
  const agent = await assertAssignableAgent(user, agentId);
  if (input.propertyId) {
    const property = await prisma.property.findFirst({
      where: { id: input.propertyId, isDeleted: false },
      select: { id: true },
    });
    if (!property) throw new ApiError("invalid_property", 422, "Property not found");
  }

  const title = input.title || `${customer.fullName} deal`;
  const closedAt = TERMINAL_STAGES.includes(input.stage) ? new Date() : null;

  const deal = await createWithCode("deal", (code) =>
    prisma.deal.create({
      data: {
        code,
        title,
        customerId: customer.id,
        propertyId: input.propertyId ?? null,
        agentId: agent.id,
        value: input.value,
        currency: input.currency,
        commissionRate: input.commissionRate,
        commissionAmount: commissionFor(input.value, input.commissionRate),
        stage: input.stage,
        probability: input.probability ?? 20,
        expectedCloseDate: input.expectedCloseDate ?? null,
        closedAt,
        lostReason: input.stage === "CLOSED_LOST" ? input.lostReason ?? null : null,
        notes: input.notes ?? null,
        stageHistory: {
          create: {
            toStage: input.stage,
            changedById: user.id,
            changedByName: user.name,
            note: "Deal created",
          },
        },
      },
      select: dealListSelect,
    }),
  );

  if (deal.stage === "CLOSED_WON" && input.propertyId) {
    await prisma.property.update({ where: { id: input.propertyId }, data: { status: "SOLD" } });
  }

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "CREATE",
    entityType: "Deal",
    entityId: deal.id,
    description: `Created deal ${deal.code} (${deal.title})`,
    metadata: { value: deal.value, stage: deal.stage },
  });

  return ok(deal, 201);
});
