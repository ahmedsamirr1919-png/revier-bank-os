import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, parseQuery } from "@/lib/api";
import { z } from "zod";
import { auth } from "@/auth";
import { asRole, type SessionUser } from "@/lib/rbac";

const createSchema = z.object({
  name: z.string().trim().min(1).max(120),
  module: z.string().trim().min(1).max(60),
  filtersJson: z.string().min(2).max(5000),
  isShared: z.boolean().default(false),
});

const listQuery = z.object({
  module: z.string().optional(),
});

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };

  const query = parseQuery(req, listQuery);
  const where: Record<string, unknown> = {
    OR: [{ ownerId: user.id }, { isShared: true }],
  };
  if (query.module) where.module = query.module;

  const items = await prisma.savedSearch.findMany({
    where,
    orderBy: { updatedAt: "desc" },
    include: { owner: { select: { id: true, name: true } } },
  });
  return ok(items);
});

export const POST = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };

  const input = await parseBody(req, createSchema);
  const created = await prisma.savedSearch.create({
    data: {
      name: input.name,
      module: input.module,
      filtersJson: input.filtersJson,
      isShared: input.isShared,
      ownerId: user.id,
    },
  });
  return ok(created, 201);
});
