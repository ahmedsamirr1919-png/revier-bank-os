import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, notFound, ok } from "@/lib/api";
import { auth } from "@/auth";
import { asRole, type SessionUser } from "@/lib/rbac";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };

  const { id } = await params;
  const existing = await prisma.savedSearch.findUnique({ where: { id } });
  if (!existing) return notFound("Saved search not found");
  if (existing.ownerId !== user.id && user.role !== "ADMIN") throw new Error("forbidden");

  await prisma.savedSearch.delete({ where: { id } });
  return ok({ id, deleted: true });
});
