import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, notFound, ok, parseBody, requireUser } from "@/lib/api";
import { taskInputSchema } from "@/lib/validation/task";
import { taskAccessWhere } from "@/lib/access";
import { taskListSelect } from "@/lib/queries/tasks";
import { validateTaskLinks } from "@/lib/task-links";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const GET = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id } = await params;

  const task = await prisma.task.findFirst({
    where: taskAccessWhere(user, id),
    include: {
      customer: { select: { id: true, code: true, fullName: true, phone: true } },
      deal: { select: { id: true, code: true, title: true, stage: true } },
      property: { select: { id: true, code: true, title: true } },
      assignedTo: { select: { id: true, name: true, email: true } },
      createdBy: { select: { id: true, name: true } },
    },
  });

  if (!task) return notFound("Task not found");
  return ok(task);
});

export const PATCH = handle<Ctx>(async (req: NextRequest, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, taskInputSchema);

  const existing = await prisma.task.findFirst({
    where: taskAccessWhere(user, id),
    select: { id: true, status: true, title: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Task not found");

  const assignee = await validateTaskLinks(user, input);
  const completedAt =
    input.status === "DONE"
      ? existing.status === "DONE"
        ? undefined
        : new Date()
      : null;

  const task = await prisma.task.update({
    where: { id },
    data: {
      title: input.title,
      description: input.description ?? null,
      type: input.type,
      priority: input.priority,
      status: input.status,
      dueAt: input.dueAt,
      ...(completedAt !== undefined ? { completedAt } : {}),
      customerId: input.customerId ?? null,
      dealId: input.dealId ?? null,
      propertyId: input.propertyId ?? null,
      assignedToId: assignee.id,
    },
    select: taskListSelect,
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: existing.status !== task.status ? "STATUS_CHANGE" : "UPDATE",
    entityType: "Task",
    entityId: task.id,
    description:
      existing.status !== task.status
        ? `Task “${task.title}” status: ${existing.status} → ${task.status}`
        : `Updated task “${task.title}”`,
    metadata: { dueAt: task.dueAt, assignee: assignee.name },
  });

  return ok(task);
});

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id } = await params;

  const existing = await prisma.task.findFirst({
    where: taskAccessWhere(user, id),
    select: { id: true, title: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Task not found");

  await prisma.task.delete({ where: { id } });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "DELETE",
    entityType: "Task",
    entityId: id,
    description: `Deleted task “${existing.title}”`,
  });

  return ok({ id, deleted: true });
});
