import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, parseBody, requireUser } from "@/lib/api";
import { taskStatusSchema } from "@/lib/validation/task";
import { taskAccessWhere } from "@/lib/access";
import { taskListSelect } from "@/lib/queries/tasks";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const PATCH = handle<Ctx>(async (req: NextRequest, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, taskStatusSchema);

  const existing = await prisma.task.findFirst({
    where: taskAccessWhere(user, id),
    select: { id: true, title: true, status: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Task not found");

  if (existing.status === input.status) {
    return ok({ id, status: input.status, changed: false });
  }

  const task = await prisma.task.update({
    where: { id },
    data: {
      status: input.status,
      completedAt: input.status === "DONE" ? new Date() : null,
    },
    select: taskListSelect,
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "STATUS_CHANGE",
    entityType: "Task",
    entityId: task.id,
    description: `Task “${task.title}” status: ${existing.status} → ${task.status}`,
    metadata: { from: existing.status, to: task.status },
  });

  return ok(task);
});
