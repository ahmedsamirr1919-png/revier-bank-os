import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, paginated, parseBody, parseQuery, requireUser } from "@/lib/api";
import { taskInputSchema, taskListQuery } from "@/lib/validation/task";
import { taskListSelect, taskOrderBy, taskWhere } from "@/lib/queries/tasks";
import { validateTaskLinks } from "@/lib/task-links";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const query = parseQuery(req, taskListQuery);
  const where = taskWhere(user, query);

  const [total, items] = await Promise.all([
    prisma.task.count({ where }),
    prisma.task.findMany({
      where,
      orderBy: taskOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: taskListSelect,
    }),
  ]);

  return ok(paginated(items, total, query.page, query.pageSize));
});

export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const input = await parseBody(req, taskInputSchema);
  const assignee = await validateTaskLinks(user, input);

  const task = await prisma.task.create({
    data: {
      title: input.title,
      description: input.description ?? null,
      type: input.type,
      priority: input.priority,
      status: input.status,
      dueAt: input.dueAt,
      completedAt: input.status === "DONE" ? new Date() : null,
      customerId: input.customerId ?? null,
      dealId: input.dealId ?? null,
      propertyId: input.propertyId ?? null,
      assignedToId: assignee.id,
      createdById: user.id,
    },
    select: taskListSelect,
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "CREATE",
    entityType: "Task",
    entityId: task.id,
    description: `Created task “${task.title}”`,
    metadata: { dueAt: task.dueAt, assignee: assignee.name },
  });

  return ok(task, 201);
});
