import { handle, ok, requireUser } from "@/lib/api";
import { prisma } from "@/lib/prisma";
import { userScope } from "@/lib/rbac";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  const users = await prisma.user.findMany({
    where: userScope(user),
    orderBy: { name: "asc" },
    select: { id: true, name: true, email: true, role: true },
  });
  return ok({ items: users });
});
