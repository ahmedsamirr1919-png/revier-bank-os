import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, paginated, parseQuery, requireUser } from "@/lib/api";
import { z } from "zod";
import { asRole, type SessionUser } from "@/lib/rbac";
import { auth } from "@/auth";

const querySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  action: z.string().optional(),
  entityType: z.string().optional(),
  userId: z.string().optional(),
  q: z.string().trim().max(120).optional(),
});

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = {
    id: session.user.id,
    role: asRole(session.user.role),
    managerId: session.user.managerId ?? null,
  };
  if (user.role !== "ADMIN" && user.role !== "MANAGER") {
    throw new Error("forbidden");
  }

  const query = parseQuery(req, querySchema);

  const where: Record<string, unknown> = {};
  if (query.action) where.action = query.action;
  if (query.entityType) where.entityType = query.entityType;
  if (query.userId) where.userId = query.userId;
  if (query.q) {
    where.OR = [
      { description: { contains: query.q } },
      { userEmail: { contains: query.q } },
      { entityType: { contains: query.q } },
    ];
  }

  if (user.role === "MANAGER") {
    const reports = await prisma.user.findMany({
      where: { managerId: user.id },
      select: { id: true },
    });
    const ids = [user.id, ...reports.map((report) => report.id)];
    where.userId = query.userId && ids.includes(query.userId) ? query.userId : { in: ids };
  }

  const [total, items] = await Promise.all([
    prisma.activityLog.count({ where }),
    prisma.activityLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      include: { user: { select: { id: true, name: true, email: true, role: true } } },
    }),
  ]);

  return ok(paginated(items, total, query.page, query.pageSize));
});
