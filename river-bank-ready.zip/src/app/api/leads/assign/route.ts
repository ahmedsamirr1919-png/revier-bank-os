import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, requireUser, ApiError } from "@/lib/api";
import { autoAssignUnassigned } from "@/lib/leads";
import { canAssignLeads, type SessionUser } from "@/lib/rbac";
import { asRole } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const sessionUser: SessionUser = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: asRole(user.role),
    managerId: user.managerId,
  };

  if (!canAssignLeads(sessionUser.role)) {
    throw new ApiError("forbidden", 403, "Only sales managers and administrators can auto-assign leads");
  }

  const result = await autoAssignUnassigned(sessionUser);

  for (const assignment of result.assignments) {
    await logActivity({
      userId: user.id,
      userEmail: user.email,
      action: "ASSIGN",
      entityType: "Customer",
      entityId: assignment.customerId,
      description: `Auto-assigned lead ${assignment.customerId} to agent ${assignment.agentId}`,
      metadata: assignment,
    });
  }

  return ok(result);
});
