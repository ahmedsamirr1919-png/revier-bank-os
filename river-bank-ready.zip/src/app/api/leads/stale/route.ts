import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, requireUser } from "@/lib/api";
import { staleLeads } from "@/lib/leads";
import { DEFAULT_STALE_DAYS } from "@/lib/constants";
import { asRole, type SessionUser } from "@/lib/rbac";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const sessionUser: SessionUser = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: asRole(user.role),
    managerId: user.managerId,
  };

  const setting = await prisma.setting.findUnique({ where: { key: "settings.staleLeadDays" } });
  const fromSetting = Number(setting?.value ?? DEFAULT_STALE_DAYS);
  const daysParam = Number(req.nextUrl.searchParams.get("days"));
  const days = Number.isFinite(daysParam) && daysParam > 0 ? Math.min(Math.floor(daysParam), 90) : Number.isFinite(fromSetting) && fromSetting > 0 ? Math.min(Math.floor(fromSetting), 90) : DEFAULT_STALE_DAYS;

  const items = await staleLeads(sessionUser, days);
  return ok({ days, items });
});
