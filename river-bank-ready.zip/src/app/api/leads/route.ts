import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, requireUser } from "@/lib/api";
import { leadPipelineStats } from "@/lib/leads";
import { asRole, type SessionUser } from "@/lib/rbac";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const sessionUser: SessionUser = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: asRole(user.role),
    managerId: user.managerId,
  };
  const stats = await leadPipelineStats(sessionUser);
  return ok(stats);
});
