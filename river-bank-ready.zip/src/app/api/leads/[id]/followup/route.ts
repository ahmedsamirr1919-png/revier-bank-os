import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, requireUser, notFound } from "@/lib/api";
import { z } from "zod";
import { customerAccessWhere } from "@/lib/access";
import { validateTaskLinks } from "@/lib/task-links";
import { asRole, type SessionUser } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";
import { TASK_PRIORITIES } from "@/lib/constants";

const followUpSchema = z
  .object({
    title: z.string().trim().min(2).max(160).optional(),
    dueAt: z.coerce.date({ message: "Due date is required" }),
    priority: z.enum(TASK_PRIORITIES).default("MEDIUM"),
  })
  .strict();

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const POST = handle<Ctx>(async (req, { params }) => {
  const user = await requireUser();
  const sessionUser: SessionUser = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: asRole(user.role),
    managerId: user.managerId,
  };

  const { id } = await params;
  const customer = await prisma.customer.findFirst({
    where: customerAccessWhere(sessionUser, id),
    select: { id: true, fullName: true, assignedAgentId: true, status: true },
  });
  if (!customer) return notFound("Customer not found");

  const input = await parseBody(req, followUpSchema);
  const task = await prisma.task.create({
    data: {
      title: input.title?.trim() || `Follow-up with ${customer.fullName}`,
      type: "FOLLOW_UP",
      priority: input.priority,
      status: "PENDING",
      dueAt: input.dueAt,
      customerId: customer.id,
      assignedToId: customer.assignedAgentId ?? user.id,
    },
    select: {
      id: true,
      title: true,
      type: true,
      priority: true,
      status: true,
      dueAt: true,
      completedAt: true,
      createdAt: true,
      customerId: true,
      assignedToId: true,
      customer: { select: { id: true, code: true, fullName: true } },
      assignedTo: { select: { id: true, name: true } },
    },
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "CREATE",
    entityType: "Task",
    entityId: task.id,
    description: `Created follow-up task ${task.title} for customer ${customer.fullName}`,
    metadata: { customerId: customer.id, taskId: task.id, type: task.type, dueAt: task.dueAt },
  });

  return ok(task, 201);
});
