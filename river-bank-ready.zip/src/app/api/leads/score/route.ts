import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, requireUser, ApiError } from "@/lib/api";
import { z } from "zod";
import { customerAccessWhere } from "@/lib/access";
import { applyLeadScore } from "@/lib/leads";
import { logActivity } from "@/lib/activity";
import { asRole, type SessionUser } from "@/lib/rbac";

const scoreSchema = z.object({ customerId: z.string().trim().min(1) }).strict();

export const dynamic = "force-dynamic";

export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const sessionUser: SessionUser = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: asRole(user.role),
    managerId: user.managerId,
  };

  const input = await parseBody(req, scoreSchema);
  const customer = await prisma.customer.findFirst({
    where: customerAccessWhere(sessionUser, input.customerId),
    select: {
      id: true,
      source: true,
      status: true,
      budgetMax: true,
      propertyType: true,
      _count: { select: { activities: true } },
    },
  });
  if (!customer) {
    throw new ApiError("not_found", 404, "Customer not found");
  }

  const computed = await applyLeadScore(customer);
  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "UPDATE",
    entityType: "Customer",
    entityId: customer.id,
    description: `Recomputed lead score ${computed.score} (${computed.scoreStatus}) for ${customer.id}`,
    metadata: { score: computed.score, scoreStatus: computed.scoreStatus },
  });

  const updated = await prisma.customer.findUnique({
    where: { id: customer.id },
    select: { id: true, score: true, scoreStatus: true },
  });
  return ok(updated);
});
