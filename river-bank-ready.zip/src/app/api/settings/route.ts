import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { z } from "zod";
import { asRole, type SessionUser } from "@/lib/rbac";
import { auth } from "@/auth";

const updateSchema = z.object({
  key: z.string().min(1).max(120),
  value: z.string().min(1).max(500),
});

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");
  const settings = await prisma.setting.findMany({ orderBy: { key: "asc" } });
  return ok(settings);
});

export const PATCH = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");
  const input = await parseBody(req, updateSchema);
  const setting = await prisma.setting.upsert({
    where: { key: input.key },
    update: { value: input.value },
    create: { key: input.key, value: input.value },
  });
  return ok(setting);
});
