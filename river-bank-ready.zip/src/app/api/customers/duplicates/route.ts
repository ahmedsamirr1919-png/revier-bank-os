import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseQuery } from "@/lib/api";
import { z } from "zod";
import { auth } from "@/auth";
import { asRole, type SessionUser } from "@/lib/rbac";
import { normalizePhone } from "@/lib/search/normalize";
import { phoneticKey } from "@/lib/search/names";

const querySchema = z.object({
  phone: z.string().optional(),
  email: z.string().optional(),
  name: z.string().optional(),
});

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };

  const query = parseQuery(req, querySchema);
  const conditions: Record<string, unknown>[] = [];

  if (query.phone) {
    const normalized = normalizePhone(query.phone);
    conditions.push({ phone: { contains: normalized.slice(-9) } });
  }
  if (query.email) {
    conditions.push({ email: { equals: query.email.trim().toLowerCase() } });
  }
  if (query.name) {
    conditions.push({ namePhoneticKey: phoneticKey(query.name) });
  }

  if (conditions.length === 0) return ok([]);

  const where: Record<string, unknown> = { OR: conditions, isDeleted: false };
  if (user.role === "AGENT") where.assignedAgentId = user.id;
  if (user.role === "MANAGER") {
    const reports = await prisma.user.findMany({ where: { managerId: user.id }, select: { id: true } });
    where.assignedAgentId = { in: [user.id, ...reports.map((r) => r.id)] };
  }

  const items = await prisma.customer.findMany({
    where,
    take: 10,
    select: { id: true, code: true, fullName: true, phone: true, email: true, status: true },
  });

  return ok(items);
});
