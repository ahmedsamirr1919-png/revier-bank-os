import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, parseBody, requireUser } from "@/lib/api";
import { assignSchema } from "@/lib/validation/customer";
import { assertAssignableAgent, assertCustomerAccess } from "@/lib/access";
import { canAssignLeads } from "@/lib/rbac";
import { logActivity, notify } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const POST = handle<Ctx>(async (req, { params }) => {
  const user = await requireUser();
  if (!canAssignLeads(user.role)) {
    throw new ApiError("forbidden", 403, "You cannot reassign customers");
  }
  const { id } = await params;
  const input = await parseBody(req, assignSchema);

  const customer = await assertCustomerAccess(user, id);
  const agent = input.assignedAgentId
    ? await assertAssignableAgent(user, input.assignedAgentId)
    : null;

  await prisma.customer.update({
    where: { id: customer.id },
    data: { assignedAgentId: agent?.id ?? null },
  });

  await Promise.all([
    prisma.customerActivity.create({
      data: {
        customerId: customer.id,
        userId: user.id,
        type: "ASSIGNMENT",
        title: agent ? "Assigned to agent" : "Unassigned",
        body: agent ? `Assigned to ${agent.name}` : "Removed agent assignment",
        metadata: JSON.stringify({ agentId: agent?.id ?? null }),
      },
    }),
    logActivity({
      userId: user.id,
      userEmail: user.email,
      action: "ASSIGN",
      entityType: "Customer",
      entityId: customer.id,
      description: agent
        ? `Assigned customer ${customer.fullName} to ${agent.name}`
        : `Unassigned customer ${customer.fullName}`,
      metadata: { agentId: agent?.id ?? null, note: input.note ?? null },
    }),
    agent
      ? notify({
          userId: agent.id,
          type: "ASSIGNMENT",
          title: "New customer assigned",
          body: `${customer.fullName} has been assigned to you.`,
          link: `/customers/${customer.id}`,
        })
      : Promise.resolve(),
  ]);

  return ok({ id: customer.id, assignedAgentId: agent?.id ?? null });
});
