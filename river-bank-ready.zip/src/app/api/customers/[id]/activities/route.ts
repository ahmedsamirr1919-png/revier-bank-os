import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { customerActivitySchema } from "@/lib/validation/customer";
import { assertCustomerAccess } from "@/lib/access";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const GET = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  await assertCustomerAccess(user, id);

  const items = await prisma.customerActivity.findMany({
    where: { customerId: id },
    orderBy: { occurredAt: "desc" },
    take: 200,
    include: { user: { select: { id: true, name: true } } },
  });
  return ok({ items });
});

export const POST = handle<Ctx>(async (req, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const customer = await assertCustomerAccess(user, id);
  const input = await parseBody(req, customerActivitySchema);

  const activity = await prisma.customerActivity.create({
    data: {
      customerId: customer.id,
      userId: user.id,
      type: input.type,
      title: input.title,
      body: input.body ?? null,
      outcome: input.outcome ?? null,
      occurredAt: input.occurredAt ?? new Date(),
    },
    include: { user: { select: { id: true, name: true } } },
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "CREATE",
    entityType: "CustomerActivity",
    entityId: activity.id,
    description: `Logged ${input.type.toLowerCase()} for customer ${customer.fullName}`,
  });

  return ok(activity, 201);
});
