import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, notFound, ok, parseBody, requireUser } from "@/lib/api";
import { customerInputSchema } from "@/lib/validation/customer";
import { assertAssignableAgent, customerAccessWhere } from "@/lib/access";
import { applyLeadScore } from "@/lib/leads";
import { canDelete } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";
import { normalizeNameAr, normalizeNameEn, phoneticKey } from "@/lib/search/names";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const GET = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id } = await params;

  const customer = await prisma.customer.findFirst({
    where: customerAccessWhere(user, id),
    include: {
      assignedAgent: { select: { id: true, name: true, email: true } },
      createdBy: { select: { id: true, name: true, email: true } },
      deals: {
        where: { isDeleted: false },
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          code: true,
          title: true,
          stage: true,
          value: true,
          currency: true,
          expectedCloseDate: true,
        },
      },
      interests: {
        orderBy: { createdAt: "desc" },
        include: {
          property: {
            select: { id: true, code: true, title: true, price: true, status: true, location: true },
          },
        },
      },
      activities: {
        orderBy: { occurredAt: "desc" },
        take: 100,
        include: { user: { select: { id: true, name: true } } },
      },
      feedback: {
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          rating: true,
          comment: true,
          status: true,
          source: true,
          createdAt: true,
          isNegative: true,
        },
      },
    },
  });

  if (!customer) return notFound("Customer not found");
  return ok(customer);
});

export const PATCH = handle<Ctx>(async (req, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, customerInputSchema);

  const existing = await prisma.customer.findFirst({
    where: customerAccessWhere(user, id),
    select: { id: true, code: true, status: true, assignedAgentId: true, fullName: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Customer not found");

  let assignedAgentId = existing.assignedAgentId;
  if (user.role !== "AGENT" && input.assignedAgentId !== undefined) {
    const requested = input.assignedAgentId ?? null;
    if (requested !== existing.assignedAgentId) {
      if (requested) {
        const agent = await assertAssignableAgent(user, requested);
        assignedAgentId = agent.id;
      } else {
        assignedAgentId = null;
      }
    }
  }

  const status = input.status ?? existing.status;
  const statusChanged = status !== existing.status;

  const customer = await prisma.customer.update({
    where: { id: existing.id },
    data: {
      fullName: input.fullName,
      nameNormalizedAr: normalizeNameAr(input.fullName),
      nameNormalizedEn: normalizeNameEn(input.fullName),
      namePhoneticKey: phoneticKey(input.fullName),
      phone: input.phone,
      email: input.email ?? null,
      whatsapp: input.whatsapp ?? null,
      source: input.source,
      status,
      budgetMin: input.budgetMin ?? null,
      budgetMax: input.budgetMax ?? null,
      currency: input.currency,
      preferredArea: input.preferredArea ?? null,
      propertyType: input.propertyType ?? null,
        purpose: input.purpose ?? null,
      notes: input.notes ?? null,
      ...(user.role === "AGENT" ? {} : { assignedAgentId }),
    },
    select: { id: true, code: true, fullName: true, status: true, assignedAgentId: true, score: true, scoreStatus: true },
  });

  const writes: Promise<unknown>[] = [
    logActivity({
      userId: user.id,
      userEmail: user.email,
      action: "UPDATE",
      entityType: "Customer",
      entityId: customer.id,
      description: `Updated customer ${customer.code} (${customer.fullName})`,
    }),
  ];

  if (statusChanged) {
    writes.push(
      prisma.customerActivity.create({
        data: {
          customerId: customer.id,
          userId: user.id,
          type: "STATUS_CHANGE",
          title: "Status changed",
          body: `${existing.status} → ${status}`,
          metadata: JSON.stringify({ from: existing.status, to: status }),
        },
      }),
    );
  }

  await Promise.all(writes);

  const scored = await prisma.customer.findUnique({
    where: { id: customer.id },
    select: {
      id: true,
      source: true,
      status: true,
      budgetMax: true,
      propertyType: true,
      _count: { select: { activities: true } },
    },
  });
  if (scored) {
    await applyLeadScore(scored);
  }

  return ok(customer);
});

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  if (!canDelete(user.role)) {
    throw new ApiError("forbidden", 403, "Only administrators can delete customers");
  }
  const { id } = await params;

  const existing = await prisma.customer.findFirst({
    where: { id },
    select: { id: true, code: true, fullName: true, isDeleted: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Customer not found");
  if (existing.isDeleted) return ok({ id, deleted: true });

  await prisma.customer.update({
    where: { id },
    data: { isDeleted: true, deletedAt: new Date() },
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "DELETE",
    entityType: "Customer",
    entityId: id,
    description: `Deleted customer ${existing.code} (${existing.fullName})`,
  });

  return ok({ id, deleted: true });
});
