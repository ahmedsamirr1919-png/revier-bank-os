import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, requireUser } from "@/lib/api";
import { canDelete } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const POST = handle<Ctx>(async (_req: NextRequest, { params }) => {
  const user = await requireUser();
  if (!canDelete(user.role)) {
    throw new ApiError("forbidden", 403, "Only administrators can restore customers");
  }
  const { id } = await params;

  const existing = await prisma.customer.findUnique({
    where: { id },
    select: { id: true, code: true, fullName: true, isDeleted: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Customer not found");

  if (existing.isDeleted) {
    await prisma.customer.update({
      where: { id },
      data: { isDeleted: false, deletedAt: null },
    });
  }

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "RESTORE",
    entityType: "Customer",
    entityId: id,
    description: `Restored customer ${existing.code} (${existing.fullName})`,
  });

  return ok({ id, restored: true });
});
