import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { customerInputSchema, importSchema } from "@/lib/validation/customer";
import { assignableAgentWhere } from "@/lib/rbac";
import { createWithCode } from "@/lib/codes";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

function pick(row: Record<string, string>, ...keys: string[]) {
  const normalized = Object.fromEntries(
    Object.entries(row).map(([key, value]) => [key.trim().toLowerCase().replace(/[\s_-]+/g, ""), value]),
  );
  for (const key of keys) {
    const value = normalized[key.toLowerCase().replace(/[\s_-]+/g, "")];
    if (value !== undefined && value !== null) return String(value).trim();
  }
  return "";
}

export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const { rows } = await parseBody(req, importSchema);

  const allowedAgents = await prisma.user.findMany({
    where: assignableAgentWhere(user),
    select: { id: true, email: true },
  });
  const agentByEmail = new Map(allowedAgents.map((agent) => [agent.email.toLowerCase(), agent.id]));

  const existingPhones = new Set(
    (
      await prisma.customer.findMany({
        where: { isDeleted: false },
        select: { phone: true },
      })
    ).map((row) => row.phone.replace(/\D/g, "")),
  );
  const seenPhones = new Set<string>();

  let imported = 0;
  let skipped = 0;
  const errors: Array<{ row: number; message: string }> = [];

  for (let index = 0; index < rows.length; index += 1) {
    const row = rows[index];
    const rowNumber = index + 2; // account for the CSV header line
    const agentEmail = pick(row, "agentEmail", "agent email", "assignedAgentEmail", "agent").toLowerCase();

    const candidate = {
      fullName: pick(row, "fullName", "full name", "name"),
      phone: pick(row, "phone", "mobile", "phoneNumber"),
      email: pick(row, "email", "emailAddress"),
      whatsapp: pick(row, "whatsapp", "whatsApp"),
      source: (pick(row, "source") || "OTHER").toUpperCase().replace(/[\s-]+/g, "_"),
      status: (pick(row, "status") || "NEW").toUpperCase().replace(/[\s-]+/g, "_"),
      budgetMin: pick(row, "budgetMin", "budget min", "minBudget"),
      budgetMax: pick(row, "budgetMax", "budget max", "maxBudget"),
      currency: (pick(row, "currency") || "EGP").toUpperCase(),
      preferredArea: pick(row, "preferredArea", "preferred area", "area"),
      propertyType: (pick(row, "propertyType", "property type", "type") || "").toUpperCase() || null,
      assignedAgentId: agentEmail ? (agentByEmail.get(agentEmail) ?? null) : null,
      notes: pick(row, "notes", "note", "comments"),
    };

    const parsed = customerInputSchema.safeParse(candidate);
    if (!parsed.success) {
      skipped += 1;
      errors.push({
        row: rowNumber,
        message: (Object.values(parsed.error.flatten().fieldErrors).flat()[0] as string) ?? "Invalid row",
      });
      continue;
    }

    const normalizedPhone = parsed.data.phone.replace(/\D/g, "");
    if (existingPhones.has(normalizedPhone) || seenPhones.has(normalizedPhone)) {
      skipped += 1;
      errors.push({ row: rowNumber, message: "A customer with this phone number already exists" });
      continue;
    }

    try {
      await createWithCode("customer", (code) =>
        prisma.customer.create({
          data: {
            code,
            fullName: parsed.data.fullName,
            phone: parsed.data.phone,
            email: parsed.data.email ?? null,
            whatsapp: parsed.data.whatsapp ?? null,
            source: parsed.data.source,
            status: parsed.data.status ?? "NEW",
            budgetMin: parsed.data.budgetMin ?? null,
            budgetMax: parsed.data.budgetMax ?? null,
            currency: parsed.data.currency,
            preferredArea: parsed.data.preferredArea ?? null,
            propertyType: parsed.data.propertyType ?? null,
            assignedAgentId: user.role === "AGENT" ? user.id : parsed.data.assignedAgentId ?? null,
            createdById: user.id,
            notes: parsed.data.notes ?? null,
          },
        }),
      );
      imported += 1;
      seenPhones.add(normalizedPhone);
    } catch (error) {
      skipped += 1;
      errors.push({ row: rowNumber, message: (error as Error).message || "Could not import row" });
    }
  }

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "IMPORT",
    entityType: "Customer",
    description: `Imported ${imported} customers from CSV (${skipped} skipped)`,
    metadata: { imported, skipped, total: rows.length },
  });

  return ok({ imported, skipped, total: rows.length, errors: errors.slice(0, 50) });
});
