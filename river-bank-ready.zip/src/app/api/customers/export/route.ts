import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, parseQuery, requireUser } from "@/lib/api";
import { customerListQuery } from "@/lib/validation/customer";
import { customerWhere } from "@/lib/queries/customers";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

function csvCell(value: unknown) {
  const text = value === null || value === undefined ? "" : String(value);
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

const COLUMNS = [
  "code",
  "fullName",
  "phone",
  "email",
  "whatsapp",
  "source",
  "status",
  "budgetMin",
  "budgetMax",
  "currency",
  "preferredArea",
  "propertyType",
  "agent",
  "notes",
  "createdAt",
];

export const GET = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const query = parseQuery(req, customerListQuery);

  const customers = await prisma.customer.findMany({
    where: customerWhere(user, query),
    orderBy: { createdAt: "desc" },
    take: 10000,
    include: {
      assignedAgent: { select: { name: true, email: true } },
    },
  });

  const lines = [COLUMNS.join(",")];
  for (const customer of customers) {
    lines.push(
      [
        customer.code,
        customer.fullName,
        customer.phone,
        customer.email,
        customer.whatsapp,
        customer.source,
        customer.status,
        customer.budgetMin,
        customer.budgetMax,
        customer.currency,
        customer.preferredArea,
        customer.propertyType,
        customer.assignedAgent?.name ?? "",
        customer.notes,
        customer.createdAt.toISOString(),
      ]
        .map(csvCell)
        .join(","),
    );
  }

  const stamp = new Date().toISOString().slice(0, 10);
  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "EXPORT",
    entityType: "Customer",
    description: `Exported ${customers.length} customers to CSV`,
    metadata: { count: customers.length, filters: query },
  });

  return new NextResponse(`\uFEFF${lines.join("\r\n")}`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="river-bank-customers-${stamp}.csv"`,
      "Cache-Control": "no-store",
    },
  });
});
