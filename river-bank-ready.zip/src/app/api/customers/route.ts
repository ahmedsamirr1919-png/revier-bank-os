import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, paginated, parseBody, parseQuery, requireUser } from "@/lib/api";
import { customerInputSchema, customerListQuery } from "@/lib/validation/customer";
import { customerOrderBy, customerListSelect, customerWhere } from "@/lib/queries/customers";
import { canDelete } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";
import { assertAssignableAgent, resolveAssignedAgentId } from "@/lib/access";
import { createWithCode } from "@/lib/codes";
import { normalizeNameAr, normalizeNameEn, phoneticKey } from "@/lib/search/names";
import { applyLeadScore } from "@/lib/leads";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const query = parseQuery(req, customerListQuery);

  const where = customerWhere(user, query);
  if (query.trash === "1") {
    if (!canDelete(user.role)) {
      const { ApiError } = await import("@/lib/api");
      throw new ApiError("forbidden", 403, "Only administrators can view deleted customers");
    }
    where.isDeleted = true;
  }

  const [total, items] = await Promise.all([
    prisma.customer.count({ where }),
    prisma.customer.findMany({
      where,
      orderBy: customerOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: customerListSelect,
    }),
  ]);

  return ok(paginated(items, total, query.page, query.pageSize));
});

export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const input = await parseBody(req, customerInputSchema);

  let assignedAgentId = resolveAssignedAgentId(user, input.assignedAgentId);
  if (assignedAgentId) {
    const agent = await assertAssignableAgent(user, assignedAgentId);
    assignedAgentId = agent.id;
  }

  const customer = await createWithCode("customer", (code) =>
    prisma.customer.create({
      data: {
        code,
        fullName: input.fullName,
        nameNormalizedAr: normalizeNameAr(input.fullName),
        nameNormalizedEn: normalizeNameEn(input.fullName),
        namePhoneticKey: phoneticKey(input.fullName),
        phone: input.phone,
        email: input.email ?? null,
        whatsapp: input.whatsapp ?? null,
        source: input.source,
        status: input.status ?? "NEW",
        budgetMin: input.budgetMin ?? null,
        budgetMax: input.budgetMax ?? null,
        currency: input.currency,
        preferredArea: input.preferredArea ?? null,
        propertyType: input.propertyType ?? null,
        purpose: input.purpose ?? null,
        assignedAgentId,
        createdById: user.id,
        notes: input.notes ?? null,
      },
      select: customerListSelect,
    }),
  );

  await applyLeadScore(customer);

  await Promise.all([
    prisma.customerActivity.create({
      data: {
        customerId: customer.id,
        userId: user.id,
        type: "NOTE",
        title: "Customer created",
        body: `Lead captured from ${input.source.toLowerCase().replace("_", " ")}.`,
      },
    }),
    logActivity({
      userId: user.id,
      userEmail: user.email,
      action: "CREATE",
      entityType: "Customer",
      entityId: customer.id,
      description: `Created customer ${customer.code} (${customer.fullName})`,
    }),
  ]);

  return ok(customer, 201);
});
