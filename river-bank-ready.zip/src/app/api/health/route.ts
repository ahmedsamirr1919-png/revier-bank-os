import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return NextResponse.json({ status: "ok", service: "river-bank-crm", time: new Date().toISOString() });
  } catch {
    return NextResponse.json({ status: "degraded", service: "river-bank-crm" }, { status: 503 });
  }
}
