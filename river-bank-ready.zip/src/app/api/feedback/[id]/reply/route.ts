import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, parseBody, requireUser } from "@/lib/api";
import { feedbackAccessWhere } from "@/lib/access";
import { feedbackReplySchema } from "@/lib/validation/feedback";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const POST = handle<Ctx>(async (req: NextRequest, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, feedbackReplySchema);

  const existing = await prisma.feedback.findFirst({
    where: feedbackAccessWhere(user, id),
    select: { id: true, status: true, rating: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Feedback not found");
  if (existing.status === "PENDING") {
    throw new ApiError("request_pending", 409, "Replies unlock once the customer responds");
  }

  const reply = await prisma.feedbackReply.create({
    data: { feedbackId: id, authorId: user.id, body: input.body },
    select: {
      id: true,
      body: true,
      createdAt: true,
      author: { select: { id: true, name: true, role: true } },
    },
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "REPLY",
    entityType: "Feedback",
    entityId: id,
    description: `Replied to ${existing.rating}-star feedback`,
  });

  return ok(reply, 201);
});
