import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, notFound, ok, parseBody, requireUser } from "@/lib/api";
import { feedbackAccessWhere } from "@/lib/access";
import { feedbackDetailSelect } from "@/lib/queries/feedback";
import { feedbackStatusSchema } from "@/lib/validation/feedback";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const GET = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id } = await params;

  const feedback = await prisma.feedback.findFirst({
    where: feedbackAccessWhere(user, id),
    select: feedbackDetailSelect,
  });

  if (!feedback) return notFound("Feedback not found");
  return ok(feedback);
});

export const PATCH = handle<Ctx>(async (req: NextRequest, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, feedbackStatusSchema);

  const existing = await prisma.feedback.findFirst({
    where: feedbackAccessWhere(user, id),
    select: { id: true, status: true, rating: true, customerId: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Feedback not found");
  if (existing.status === "PENDING") {
    throw new ApiError("request_pending", 409, "This request has not been answered yet");
  }
  if (existing.status === input.status) {
    return ok({ id, status: input.status, changed: false });
  }

  const resolved = input.status === "RESOLVED";
  const feedback = await prisma.feedback.update({
    where: { id },
    data: {
      status: input.status,
      resolvedAt: resolved ? new Date() : null,
      resolvedById: resolved ? user.id : null,
    },
    select: feedbackDetailSelect,
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: resolved ? "RESOLVE" : "STATUS_CHANGE",
    entityType: "Feedback",
    entityId: feedback.id,
    description: `Feedback ${existing.rating}-star rating marked ${input.status.toLowerCase()}`,
    metadata: { from: existing.status, to: input.status },
  });

  return ok(feedback);
});
