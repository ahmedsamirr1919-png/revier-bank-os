import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, paginated, parseBody, parseQuery, requireUser } from "@/lib/api";
import { feedbackInputSchema, feedbackListQuery } from "@/lib/validation/feedback";
import { feedbackListSelect, feedbackOrderBy, feedbackWhere } from "@/lib/queries/feedback";
import { getNegativeThreshold, notifyNegativeFeedback, resolveFeedbackTargets } from "@/lib/feedback";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const query = parseQuery(req, feedbackListQuery);
  const where = feedbackWhere(user, query);

  const [total, items] = await Promise.all([
    prisma.feedback.count({ where }),
    prisma.feedback.findMany({
      where,
      orderBy: feedbackOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: feedbackListSelect,
    }),
  ]);

  return ok(paginated(items, total, query.page, query.pageSize));
});

export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const input = await parseBody(req, feedbackInputSchema);
  const targets = await resolveFeedbackTargets(user, input);
  const threshold = await getNegativeThreshold();
  const isNegative = input.rating <= threshold;

  const feedback = await prisma.feedback.create({
    data: {
      token: `internal-${crypto.randomUUID()}`,
      source: "INTERNAL",
      rating: input.rating,
      categories: JSON.stringify(input.categories),
      comment: input.comment ?? null,
      customerId: targets.customerId,
      dealId: targets.dealId,
      propertyId: targets.propertyId,
      agentId: targets.agentId,
      submittedByName: input.submittedByName ?? targets.customerName ?? user.name,
      submittedById: user.id,
      isNegative,
      status: "NEW",
    },
    select: feedbackListSelect,
  });

  if (isNegative) {
    await notifyNegativeFeedback({
      feedbackId: feedback.id,
      rating: feedback.rating,
      customerName: feedback.submittedByName,
      agentId: feedback.agentId,
    });
  }

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "CREATE",
    entityType: "Feedback",
    entityId: feedback.id,
    description: `Received ${feedback.rating}-star feedback`,
    metadata: { isNegative, source: feedback.source },
  });

  return ok(feedback, 201);
});
