import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { feedbackRequestSchema } from "@/lib/validation/feedback";
import { feedbackListSelect } from "@/lib/queries/feedback";
import { feedbackScope } from "@/lib/rbac";
import {
  createFeedbackToken,
  DEFAULT_REQUEST_EXPIRY_DAYS,
  resolveFeedbackTargets,
} from "@/lib/feedback";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

/**
 * Creates a tokenized public feedback request. Requests are stored as PENDING
 * feedback rows with a zero rating; the public form fills in the real rating.
 * An open request for the same customer/deal is reused instead of duplicated.
 */
export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const input = await parseBody(req, feedbackRequestSchema);
  const targets = await resolveFeedbackTargets(user, input);

  const existing = await prisma.feedback.findFirst({
    where: {
      status: "PENDING",
      ...(targets.dealId
        ? { dealId: targets.dealId }
        : { customerId: targets.customerId, dealId: null }),
      OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
      ...feedbackScope(user),
    },
    orderBy: { createdAt: "desc" },
    select: feedbackListSelect,
  });

  if (existing) {
    return ok({ ...existing, reused: true });
  }

  const days = input.expiresInDays ?? DEFAULT_REQUEST_EXPIRY_DAYS;
  const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000);

  const request = await prisma.feedback.create({
    data: {
      token: createFeedbackToken(),
      source: "INTERNAL",
      rating: 0,
      categories: "[]",
      customerId: targets.customerId,
      dealId: targets.dealId,
      propertyId: targets.propertyId,
      agentId: targets.agentId,
      submittedByName: targets.customerName,
      isNegative: false,
      status: "PENDING",
      expiresAt,
    },
    select: feedbackListSelect,
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "CREATE",
    entityType: "FeedbackRequest",
    entityId: request.id,
    description: `Requested feedback${targets.customerName ? ` from ${targets.customerName}` : ""}`,
    metadata: { expiresAt },
  });

  return ok({ ...request, reused: false }, 201);
});
