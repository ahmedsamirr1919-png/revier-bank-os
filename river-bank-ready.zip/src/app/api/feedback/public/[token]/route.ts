import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { fail, handle, notFound, ok, parseBody } from "@/lib/api";
import { publicFeedbackSchema } from "@/lib/validation/feedback";
import { getNegativeThreshold, notifyNegativeFeedback } from "@/lib/feedback";
import { logActivity } from "@/lib/activity";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ token: string }> };

export const GET = handle<Ctx>(async (_req, { params }) => {
  const { token } = await params;

  const feedback = await prisma.feedback.findUnique({
    where: { token },
    select: {
      id: true,
      status: true,
      expiresAt: true,
      customer: { select: { fullName: true } },
      deal: { select: { title: true } },
      agent: { select: { name: true } },
    },
  });

  if (!feedback) return notFound("Feedback link not found");
  if (feedback.status !== "PENDING") {
    return fail("already_submitted", 410, "This feedback link has already been used");
  }
  if (feedback.expiresAt && feedback.expiresAt.getTime() < Date.now()) {
    return fail("expired", 410, "This feedback link has expired");
  }

  return ok({
    status: "ready",
    customerName: feedback.customer?.fullName ?? null,
    dealTitle: feedback.deal?.title ?? null,
    agentName: feedback.agent?.name ?? null,
    expiresAt: feedback.expiresAt,
  });
});

export const POST = handle<Ctx>(async (req: NextRequest, { params }) => {
  const { token } = await params;

  const limit = rateLimit(`public-feedback:${clientIp(req.headers)}`, 10, 10 * 60 * 1000);
  if (!limit.ok) {
    return fail("rate_limited", 429, "Too many submissions. Please try again later.", {
      retryAfterSeconds: limit.retryAfterSeconds,
    });
  }

  const input = await parseBody(req, publicFeedbackSchema);
  const existing = await prisma.feedback.findUnique({
    where: { token },
    select: { id: true, status: true, expiresAt: true, customerId: true, submittedByName: true },
  });

  if (!existing) return notFound("Feedback link not found");
  if (existing.status !== "PENDING") {
    return fail("already_submitted", 410, "This feedback link has already been used");
  }
  if (existing.expiresAt && existing.expiresAt.getTime() < Date.now()) {
    return fail("expired", 410, "This feedback link has expired");
  }

  const threshold = await getNegativeThreshold();
  const isNegative = input.rating <= threshold;
  const now = new Date();

  const updated = await prisma.feedback.updateMany({
    where: {
      id: existing.id,
      status: "PENDING",
      OR: [{ expiresAt: null }, { expiresAt: { gt: now } }],
    },
    data: {
      source: "PUBLIC",
      rating: input.rating,
      categories: JSON.stringify(input.categories),
      comment: input.comment ?? null,
      submittedByName: input.submittedByName ?? existing.submittedByName,
      isNegative,
      status: "NEW",
      expiresAt: null,
      updatedAt: now,
    },
  });

  if (updated.count === 0) {
    return fail("already_submitted", 410, "This feedback link is no longer available");
  }

  const feedback = await prisma.feedback.findUnique({
    where: { id: existing.id },
    select: { id: true, rating: true, agentId: true, submittedByName: true, customerId: true },
  });

  if (!feedback) return notFound("Feedback link not found");

  if (isNegative) {
    await notifyNegativeFeedback({
      feedbackId: feedback.id,
      rating: feedback.rating,
      customerName: feedback.submittedByName,
      agentId: feedback.agentId,
    });
  }

  if (feedback.customerId) {
    await prisma.customerActivity.create({
      data: {
        customerId: feedback.customerId,
        type: "FEEDBACK",
        title: "Public feedback received",
        body: input.comment ?? null,
        metadata: JSON.stringify({ feedbackId: feedback.id, rating: feedback.rating }),
        occurredAt: now,
      },
    });
  }

  await logActivity({
    userEmail: "public",
    action: "CREATE",
    entityType: "Feedback",
    entityId: feedback.id,
    description: `Public feedback received (${feedback.rating}-star)`,
    metadata: { isNegative, source: "PUBLIC" },
  });

  return ok({ ok: true });
});
