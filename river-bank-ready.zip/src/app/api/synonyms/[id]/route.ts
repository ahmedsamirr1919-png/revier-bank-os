import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, notFound, ok } from "@/lib/api";
import { auth } from "@/auth";
import { asRole, type SessionUser } from "@/lib/rbac";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");

  const { id } = await params;
  const existing = await prisma.synonym.findUnique({ where: { id } });
  if (!existing) return notFound("Synonym not found");
  await prisma.synonym.delete({ where: { id } });
  return ok({ id, deleted: true });
});
