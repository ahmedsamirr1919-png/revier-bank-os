import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody } from "@/lib/api";
import { z } from "zod";
import { auth } from "@/auth";
import { asRole, type SessionUser } from "@/lib/rbac";

const createSchema = z.object({
  term: z.string().trim().min(1).max(120),
  canonical: z.string().trim().min(1).max(120),
  module: z.string().trim().max(60).optional(),
});

export const dynamic = "force-dynamic";

export const GET = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");

  const moduleFilter = new URL(req.url).searchParams.get("module");
  const items = await prisma.synonym.findMany({
    where: moduleFilter ? { module: moduleFilter } : undefined,
    orderBy: { term: "asc" },
  });
  return ok(items);
});

export const POST = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user: SessionUser = { id: session.user.id, role: asRole(session.user.role), managerId: session.user.managerId ?? null };
  if (user.role !== "ADMIN") throw new Error("forbidden");

  const input = await parseBody(req, createSchema);
  const created = await prisma.synonym.create({
    data: { term: input.term, canonical: input.canonical, module: input.module },
  });
  return ok(created, 201);
});
