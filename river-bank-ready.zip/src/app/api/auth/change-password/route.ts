import { compare, hash } from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody, requireUser, ApiError } from "@/lib/api";
import { logActivity } from "@/lib/activity";

const schema = z
  .object({
    currentPassword: z.string().min(1),
    newPassword: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .max(72)
      .regex(/^(?=.*[A-Za-z])(?=.*\d)/, "Password must contain a letter and a number"),
  })
  .strict();

export const POST = handle(async (req) => {
  const user = await requireUser();
  const body = await parseBody(req, schema);

  const dbUser = await prisma.user.findUnique({ where: { id: user.id } });
  if (!dbUser) throw new ApiError("not_found", 404, "User not found");

  const valid = await compare(body.currentPassword, dbUser.passwordHash);
  if (!valid) throw new ApiError("invalid_password", 400, "Current password is incorrect");

  if (await compare(body.newPassword, dbUser.passwordHash)) {
    throw new ApiError("password_reused", 400, "New password must be different from the current one");
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash: await hash(body.newPassword, 12), mustChangePassword: false },
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "PASSWORD_CHANGE",
    entityType: "User",
    entityId: user.id,
    description: `${user.name} changed their password`,
  });

  return ok({ ok: true });
});
