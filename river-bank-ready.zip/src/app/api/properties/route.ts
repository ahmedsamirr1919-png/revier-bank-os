import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, paginated, parseBody, parseQuery, requireUser } from "@/lib/api";
import { propertyInputSchema, propertyListQuery } from "@/lib/validation/property";
import { propertyListSelect, propertyOrderBy, propertyWhere } from "@/lib/queries/properties";
import { canDelete } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";
import { createWithCode } from "@/lib/codes";

export const dynamic = "force-dynamic";

function normalizeImages(images: Array<{ url: string; alt?: string | null; isPrimary?: boolean }>) {
  const primaryIndex = Math.max(
    0,
    images.findIndex((image) => image.isPrimary),
  );
  return images.map((image, index) => ({
    url: image.url,
    alt: image.alt ?? null,
    isPrimary: index === primaryIndex,
    sortOrder: index,
  }));
}

export const GET = handle(async (req: NextRequest) => {
  await requireUser();
  const query = parseQuery(req, propertyListQuery);
  const where = propertyWhere(query);
  if (query.trash === "1") {
    const user = await requireUser();
    if (!canDelete(user.role)) {
      const { ApiError } = await import("@/lib/api");
      throw new ApiError("forbidden", 403, "Only administrators can view deleted properties");
    }
    where.isDeleted = true;
  }

  const [total, items] = await Promise.all([
    prisma.property.count({ where }),
    prisma.property.findMany({
      where,
      orderBy: propertyOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: propertyListSelect,
    }),
  ]);

  return ok(paginated(items, total, query.page, query.pageSize));
});

export const POST = handle(async (req: NextRequest) => {
  const user = await requireUser();
  const input = await parseBody(req, propertyInputSchema);

  const property = await createWithCode("property", (code) =>
    prisma.property.create({
      data: {
        code,
        title: input.title,
        type: input.type,
        price: input.price,
        area: input.area,
        location: input.location,
        city: input.city,
        bedrooms: input.bedrooms ?? null,
        bathrooms: input.bathrooms ?? null,
        status: input.status,
        purpose: input.purpose,
        description: input.description ?? null,
        ownerName: input.ownerName ?? null,
        ownerPhone: input.ownerPhone ?? null,
        ownerEmail: input.ownerEmail ?? null,
        ownerIdNumber: input.ownerIdNumber ?? null,
        ownerNotes: input.ownerNotes ?? null,
        tags: input.tags ? JSON.stringify(input.tags) : null,
        createdById: user.id,
        ...(input.images?.length
          ? { images: { create: normalizeImages(input.images) } }
          : {}),
      },
      select: propertyListSelect,
    }),
  );

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "CREATE",
    entityType: "Property",
    entityId: property.id,
    description: `Added property ${property.code} (${property.title})`,
  });

  return ok(property, 201);
});
