import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, parseBody, requireUser } from "@/lib/api";
import { propertyLinkSchema } from "@/lib/validation/property";
import { customerScope } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const POST = handle<Ctx>(async (req, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, propertyLinkSchema);

  const [property, customer] = await Promise.all([
    prisma.property.findFirst({
      where: { id, isDeleted: false },
      select: { id: true, code: true, title: true },
    }),
    prisma.customer.findFirst({
      where: { id: input.customerId, isDeleted: false, ...customerScope(user) },
      select: { id: true, fullName: true },
    }),
  ]);
  if (!property) throw new ApiError("not_found", 404, "Property not found");
  if (!customer) throw new ApiError("not_found", 404, "Customer not found");

  const link = await prisma.customerProperty.upsert({
    where: {
      customerId_propertyId_relation: {
        customerId: customer.id,
        propertyId: property.id,
        relation: input.relation,
      },
    },
    update: {},
    create: {
      customerId: customer.id,
      propertyId: property.id,
      relation: input.relation,
    },
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "UPDATE",
    entityType: "Property",
    entityId: property.id,
    description: `Linked ${customer.fullName} to ${property.code} as ${input.relation.toLowerCase()}`,
  });

  return ok(link, 201);
});
