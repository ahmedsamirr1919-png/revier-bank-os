import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, requireUser } from "@/lib/api";
import { customerScope } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string; linkId: string }> };

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id, linkId } = await params;

  const link = await prisma.customerProperty.findFirst({
    where: {
      id: linkId,
      propertyId: id,
      customer: { is: { isDeleted: false, ...customerScope(user) } },
    },
    include: {
      customer: { select: { fullName: true } },
      property: { select: { code: true } },
    },
  });
  if (!link) throw new ApiError("not_found", 404, "Link not found");

  await prisma.customerProperty.delete({ where: { id: linkId } });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "UPDATE",
    entityType: "Property",
    entityId: id,
    description: `Removed ${link.customer.fullName} from ${link.property.code}`,
  });

  return ok({ id: linkId, removed: true });
});
