import { prisma } from "@/lib/prisma";
import { ApiError, handle, ok, requireUser } from "@/lib/api";
import { canDelete } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export const POST = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  if (!canDelete(user.role)) {
    throw new ApiError("forbidden", 403, "Only administrators can restore properties");
  }
  const { id } = await params;

  const existing = await prisma.property.findUnique({
    where: { id },
    select: { id: true, code: true, title: true, isDeleted: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Property not found");

  if (existing.isDeleted) {
    await prisma.property.update({ where: { id }, data: { isDeleted: false, deletedAt: null } });
  }

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "RESTORE",
    entityType: "Property",
    entityId: id,
    description: `Restored property ${existing.code} (${existing.title})`,
  });

  return ok({ id, restored: true });
});
