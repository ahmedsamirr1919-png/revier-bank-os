import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handle, notFound, ok, parseBody, requireUser } from "@/lib/api";
import { propertyInputSchema } from "@/lib/validation/property";
import { canDelete } from "@/lib/rbac";
import { logActivity } from "@/lib/activity";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function normalizeImages(images: Array<{ url: string; alt?: string | null; isPrimary?: boolean }>) {
  const firstPrimary = images.findIndex((image) => image.isPrimary);
  const primaryIndex = firstPrimary === -1 ? 0 : firstPrimary;
  return images.map((image, index) => ({
    url: image.url,
    alt: image.alt ?? null,
    isPrimary: index === primaryIndex,
    sortOrder: index,
  }));
}

export const GET = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  const { id } = await params;

  const property = await prisma.property.findFirst({
    where: {
      id,
      ...(user.role === "ADMIN" ? {} : { isDeleted: false }),
    },
    include: {
      images: { orderBy: [{ isPrimary: "desc" }, { sortOrder: "asc" }] },
      createdBy: { select: { id: true, name: true, email: true } },
      interests: {
        orderBy: { createdAt: "desc" },
        include: {
          customer: {
            select: {
              id: true,
              code: true,
              fullName: true,
              phone: true,
              status: true,
              assignedAgentId: true,
            },
          },
        },
      },
      deals: {
        where: { isDeleted: false },
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          code: true,
          title: true,
          stage: true,
          value: true,
          currency: true,
          agent: { select: { id: true, name: true } },
        },
      },
      feedback: {
        orderBy: { createdAt: "desc" },
        take: 20,
        select: { id: true, rating: true, comment: true, status: true, createdAt: true },
      },
    },
  });

  if (!property) return notFound("Property not found");
  return ok(property);
});

export const PATCH = handle<Ctx>(async (req, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const input = await parseBody(req, propertyInputSchema);

  const existing = await prisma.property.findUnique({ where: { id }, select: { id: true, code: true, title: true, status: true } });
  if (!existing) throw new ApiError("not_found", 404, "Property not found");

  const images = input.images;
  const property = await prisma.property.update({
    where: { id },
    data: {
      title: input.title,
      type: input.type,
      price: input.price,
      area: input.area,
      location: input.location,
      city: input.city,
      bedrooms: input.bedrooms ?? null,
      bathrooms: input.bathrooms ?? null,
      status: input.status,
      purpose: input.purpose,
      description: input.description ?? null,
      ownerName: input.ownerName ?? null,
      ownerPhone: input.ownerPhone ?? null,
      ownerEmail: input.ownerEmail ?? null,
      ownerIdNumber: input.ownerIdNumber ?? null,
      ownerNotes: input.ownerNotes ?? null,
      tags: input.tags ? JSON.stringify(input.tags) : null,
      ...(images
        ? {
            images: {
              deleteMany: {},
              create: normalizeImages(images),
            },
          }
        : {}),
    },
    select: { id: true, code: true, title: true, status: true, price: true },
  });

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: existing.status !== property.status ? "STATUS_CHANGE" : "UPDATE",
    entityType: "Property",
    entityId: id,
    description:
      existing.status !== property.status
        ? `Changed property ${property.code} status: ${existing.status} → ${property.status}`
        : `Updated property ${property.code} (${property.title})`,
    metadata: { from: existing.status, to: property.status },
  });

  return ok(property);
});

export const DELETE = handle<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  if (!canDelete(user.role)) {
    throw new ApiError("forbidden", 403, "Only administrators can delete properties");
  }
  const { id } = await params;

  const existing = await prisma.property.findUnique({
    where: { id },
    select: { id: true, code: true, title: true, isDeleted: true },
  });
  if (!existing) throw new ApiError("not_found", 404, "Property not found");

  if (!existing.isDeleted) {
    await prisma.property.update({ where: { id }, data: { isDeleted: true, deletedAt: new Date() } });
  }

  await logActivity({
    userId: user.id,
    userEmail: user.email,
    action: "DELETE",
    entityType: "Property",
    entityId: id,
    description: `Deleted property ${existing.code} (${existing.title})`,
  });

  return ok({ id, deleted: true });
});
