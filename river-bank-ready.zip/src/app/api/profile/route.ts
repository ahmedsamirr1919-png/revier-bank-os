import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { handle, ok, parseBody } from "@/lib/api";
import { z } from "zod";
import { auth } from "@/auth";

const updateSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  email: z.string().trim().email().optional(),
  phone: z.string().trim().max(40).optional().nullable(),
  locale: z.enum(["en", "ar"]).optional(),
});

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      phone: true,
      locale: true,
      isActive: true,
      mustChangePassword: true,
      manager: { select: { name: true, email: true } },
      createdAt: true,
      lastLoginAt: true,
    },
  });
  if (!user) throw new Error("not_found");
  return ok(user);
});

export const PATCH = handle(async (req: NextRequest) => {
  const session = await auth();
  if (!session?.user?.id) throw new Error("unauthorized");
  const input = await parseBody(req, updateSchema);

  if (input.email) {
    const existing = await prisma.user.findFirst({
      where: { email: input.email, NOT: { id: session.user.id } },
      select: { id: true },
    });
    if (existing) throw new Error("email_taken");
  }

  const updated = await prisma.user.update({
    where: { id: session.user.id },
    data: {
      ...(input.name !== undefined ? { name: input.name } : {}),
      ...(input.email !== undefined ? { email: input.email } : {}),
      ...(input.phone !== undefined ? { phone: input.phone } : {}),
      ...(input.locale !== undefined ? { locale: input.locale } : {}),
    },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      phone: true,
      locale: true,
    },
  });

  return ok(updated);
});
