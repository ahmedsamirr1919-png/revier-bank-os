import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { handle, ApiError } from "@/lib/api";
import { asRole } from "@/lib/rbac";
import path from "node:path";
import fs from "node:fs/promises";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const session = await auth();
  if (!session?.user?.id) throw new ApiError("unauthorized", 401, "Authentication required");
  const role = asRole(session.user.role);
  if (role !== "ADMIN") throw new ApiError("forbidden", 403, "Only administrators can download backups");

  const dbPath = path.join(process.cwd(), "prisma", "dev.db");
  const buffer = await fs.readFile(dbPath);
  const filename = `river-bank-backup-${new Date().toISOString().slice(0, 10)}.db`;

  return new NextResponse(buffer, {
    status: 200,
    headers: {
      "Content-Type": "application/x-sqlite3",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
});
