import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { getI18n } from "@/lib/i18n/server";
import { ChangePasswordView } from "./change-password-view";
import { Logo } from "@/components/layout/logo";
import { LanguageToggle } from "@/components/layout/language-toggle";
import { ThemeToggle } from "@/components/layout/theme-toggle";

export const metadata = { title: "Change password" };

export default async function ChangePasswordPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");
  const { t } = await getI18n();

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <div className="flex items-center justify-between p-4">
        <Logo size={32} subtitle={t("app.tagline")} />
        <div className="flex items-center gap-1">
          <LanguageToggle />
          <ThemeToggle />
        </div>
      </div>
      <div className="flex flex-1 items-center justify-center px-5 pb-16">
        <ChangePasswordView email={session.user.email ?? ""} />
      </div>
    </div>
  );
}
