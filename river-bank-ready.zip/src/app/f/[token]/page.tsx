import type { Metadata } from "next";
import { AlertTriangle } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getI18n } from "@/lib/i18n/server";
import { Logo } from "@/components/layout/logo";
import { LanguageToggle } from "@/components/layout/language-toggle";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { PublicFeedbackForm } from "@/components/feedback/public-feedback-form";
import { Card, CardContent } from "@/components/ui/card";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Share your feedback",
};

export default async function PublicFeedbackPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const { t } = await getI18n();

  const feedback = await prisma.feedback.findUnique({
    where: { token },
    select: {
      status: true,
      expiresAt: true,
      customer: { select: { fullName: true } },
      deal: { select: { title: true } },
      agent: { select: { name: true } },
    },
  });

  const expired = Boolean(feedback?.expiresAt && feedback.expiresAt.getTime() < Date.now());
  const available = Boolean(feedback && feedback.status === "PENDING" && !expired);

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-background">
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_15%_10%,rgba(34,184,196,0.16),transparent_45%),radial-gradient(circle_at_85%_90%,rgba(14,116,144,0.14),transparent_50%)]"
        aria-hidden="true"
      />

      <header className="relative z-10 flex items-center justify-between gap-2 p-4 sm:px-8">
        <Logo size={34} subtitle={t("app.tagline")} />
        <div className="flex items-center gap-1">
          <LanguageToggle compact />
          <ThemeToggle />
        </div>
      </header>

      <main className="relative z-10 flex flex-1 items-center justify-center p-4 pb-10">
        {available && feedback ? (
          <PublicFeedbackForm
            token={token}
            customerName={feedback.customer?.fullName ?? null}
            agentName={feedback.agent?.name ?? null}
            dealTitle={feedback.deal?.title ?? null}
          />
        ) : (
          <Card className="w-full max-w-xl shadow-xl">
            <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
              <span className="flex size-12 items-center justify-center rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400">
                <AlertTriangle className="size-6" />
              </span>
              <h1 className="text-lg font-semibold">
                {expired ? t("feedback.expired") : t("feedback.invalidToken")}
              </h1>
              <p className="max-w-sm text-sm text-muted-foreground">{t("feedback.invalidTokenBody")}</p>
            </CardContent>
          </Card>
        )}
      </main>

      <footer className="relative z-10 pb-6 text-center text-xs text-muted-foreground">
        {t("feedback.poweredBy")}
      </footer>
    </div>
  );
}
