import { getI18n } from "@/lib/i18n/server";
import { LoginView } from "./login-view";

export const metadata = { title: "Sign in" };

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string; expired?: string; changed?: string }>;
}) {
  const params = await searchParams;
  const { t } = await getI18n();

  return (
    <LoginView
      callbackUrl={params.callbackUrl?.startsWith("/") ? params.callbackUrl : "/dashboard"}
      expired={params.expired === "1"}
      changed={params.changed === "1"}
      appName={t("app.name")}
      tagline={t("app.tagline")}
    />
  );
}
