"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { AlertCircle, CheckCircle2, Eye, EyeOff, Loader2, ShieldCheck, Waves } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { LanguageToggle } from "@/components/layout/language-toggle";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { useI18n } from "@/components/locale-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";

const DEMO = [
  { roleKey: "auth.admin", email: "admin@riverbank.com", password: "Admin@12345" },
];

export function LoginView({
  callbackUrl,
  expired,
  changed,
  appName,
  tagline,
}: {
  callbackUrl: string;
  expired: boolean;
  changed: boolean;
  appName: string;
  tagline: string;
}) {
  const router = useRouter();
  const { t } = useI18n();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setPending(true);
    setError(null);
    try {
      const result = await signIn("credentials", {
        email: email.trim().toLowerCase(),
        password,
        remember: remember ? "true" : "false",
        redirect: false,
      });

      const code = `${result?.error ?? ""} ${(result as { code?: string } | undefined)?.code ?? ""}`;
      if (!result || result.error) {
        if (code.includes("rate_limited")) setError(t("auth.rateLimited"));
        else if (code.includes("account_disabled")) setError(t("auth.invalid"));
        else setError(t("auth.invalid"));
        return;
      }

      router.replace(callbackUrl.startsWith("/") ? callbackUrl : "/dashboard");
      router.refresh();
    } catch {
      setError(t("common.serverError"));
    } finally {
      setPending(false);
    }
  };

  const fillDemo = (demo: (typeof DEMO)[number]) => {
    setEmail(demo.email);
    setPassword(demo.password);
    setError(null);
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      {/* Brand panel */}
      <div className="river-gradient relative hidden overflow-hidden p-10 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="river-lines absolute inset-0 opacity-70" aria-hidden="true" />
        <div className="relative">
          <div className="flex items-center gap-3">
            <Logo size={40} showText={false} />
            <div>
              <p className="text-lg font-semibold tracking-tight">{appName}</p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-white/50">{tagline}</p>
            </div>
          </div>
        </div>

        <div className="relative max-w-lg">
          <h1 className="text-balance text-3xl font-semibold leading-tight xl:text-4xl">{t("auth.heroTitle")}</h1>
          <p className="mt-3 text-sm leading-relaxed text-white/65">{t("auth.heroSubtitle")}</p>

          <ul className="mt-8 space-y-3">
            {[t("auth.feature1"), t("auth.feature2"), t("auth.feature3")].map((feature) => (
              <li key={feature} className="flex items-center gap-3 text-sm text-white/80">
                <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-white/10">
                  <Waves className="size-3.5 text-teal-300" />
                </span>
                {feature}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative flex items-center gap-2 text-[11px] text-white/45">
          <ShieldCheck className="size-3.5" />
          {t("auth.secure")}
          <span className="mx-2">·</span>© {new Date().getFullYear()} {t("auth.copyright")}
        </div>
      </div>

      {/* Form panel */}
      <div className="flex flex-col bg-background">
        <div className="flex items-center justify-between p-4">
          <div className="lg:hidden">
            <Logo size={32} subtitle={tagline} />
          </div>
          <div className="ms-auto flex items-center gap-1">
            <LanguageToggle />
            <ThemeToggle />
          </div>
        </div>

        <div className="flex flex-1 items-center justify-center px-5 pb-10">
          <div className="w-full max-w-sm">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold tracking-tight">{t("auth.welcome")}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{t("auth.subtitle")}</p>
            </div>

            {expired && (
              <div className="mb-4 flex items-start gap-2 rounded-lg border border-amber-300/60 bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
                <AlertCircle className="mt-0.5 size-3.5 shrink-0" />
                {t("auth.sessionExpired")}
              </div>
            )}
            {changed && (
              <div className="mb-4 flex items-start gap-2 rounded-lg border border-emerald-300/60 bg-emerald-50 px-3 py-2 text-xs text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                <CheckCircle2 className="mt-0.5 size-3.5 shrink-0" />
                {t("auth.changed")}
              </div>
            )}

            <form onSubmit={submit} className="space-y-4" noValidate>
              <div className="space-y-1.5">
                <Label htmlFor="email">{t("auth.email")}</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@riverbank.com"
                  dir="ltr"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password">{t("auth.password")}</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    required
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    className="pe-9"
                    dir="ltr"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    className="absolute end-2 top-1/2 -translate-y-1/2 rounded-sm p-1 text-muted-foreground hover:text-foreground"
                    aria-label={showPassword ? t("auth.hidePassword") : t("auth.showPassword")}
                  >
                    {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox
                  id="remember"
                  checked={remember}
                  onCheckedChange={(checked) => setRemember(checked === true)}
                />
                <Label htmlFor="remember" className="cursor-pointer text-xs font-normal text-muted-foreground">
                  {t("auth.remember")}
                </Label>
              </div>

              {error && (
                <p
                  role="alert"
                  className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-xs text-destructive"
                >
                  <AlertCircle className="mt-0.5 size-3.5 shrink-0" />
                  {error}
                </p>
              )}

              <Button type="submit" className="h-10 w-full" disabled={pending}>
                {pending && <Loader2 className="animate-spin" />}
                {pending ? t("auth.signingIn") : t("auth.signIn")}
              </Button>
            </form>

            <div className="mt-7">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                  {t("auth.demo")}
                </p>
                <span className="text-[10px] text-muted-foreground">{t("auth.demoHint")}</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {DEMO.map((demo) => (
                  <button
                    key={demo.email}
                    type="button"
                    onClick={() => fillDemo(demo)}
                    className={cn(
                      "rounded-lg border bg-card px-2 py-2 text-center transition hover:border-primary/40 hover:bg-accent",
                      email === demo.email && "border-primary/60 bg-accent",
                    )}
                  >
                    <span className="block text-[11px] font-medium">{t(demo.roleKey)}</span>
                    <span className="mt-0.5 block truncate text-[9px] text-muted-foreground" dir="ltr">
                      {demo.email.replace("@riverbank.com", "")}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
