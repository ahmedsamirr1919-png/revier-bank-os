import Link from "next/link";
import { ShieldX } from "lucide-react";
import { getI18n } from "@/lib/i18n/server";
import { Button } from "@/components/ui/button";

export const metadata = { title: "Forbidden" };

export default async function ForbiddenPage() {
  const { t } = await getI18n();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-6">
      <div className="flex max-w-md flex-col items-center text-center">
        <div className="mb-4 flex size-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
          <ShieldX className="size-7" />
        </div>
        <h1 className="text-xl font-semibold">403</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("common.forbidden")}</p>
        <Button asChild className="mt-5">
          <Link href="/dashboard">{t("nav.dashboard")}</Link>
        </Button>
      </div>
    </div>
  );
}
