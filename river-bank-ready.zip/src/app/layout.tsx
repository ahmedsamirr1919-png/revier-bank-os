import type { Metadata, Viewport } from "next";

import "./globals.css";
import { getI18n } from "@/lib/i18n/server";
import { Providers } from "@/components/providers";

export const metadata: Metadata = {
  title: {
    default: "River Bank CRM",
    template: "%s · River Bank CRM",
  },
  description:
    "River Bank real estate CRM — customers, properties, deals, tasks and customer feedback in one workspace.",
  applicationName: "River Bank CRM",
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f4f8f9" },
    { media: "(prefers-color-scheme: dark)", color: "#06171c" },
  ],
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { locale, dir } = await getI18n();

  return (
    <html lang={locale} dir={dir} suppressHydrationWarning>
      <body className="min-h-screen bg-background text-foreground antialiased">
        {/* Wraps the app with context providers (e.g., theme, i18n) and sets the initial locale */}
        <Providers initialLocale={locale}>{children}</Providers>
        <script
          dangerouslySetInnerHTML={{
            __html: `if('serviceWorker' in navigator){window.addEventListener('load',async()=>{try{const registration=await navigator.serviceWorker.register('/sw.js',{updateViaCache:'none'});await registration.update();}catch{}});}`,
          }}
        />
      </body>
    </html>
  );
}
