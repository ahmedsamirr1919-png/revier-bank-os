import { ActivityView } from "@/components/activity/activity-view";

export const metadata = { title: "Activity Log" };

export default function ActivityPage() {
  return <ActivityView />;
}
