import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { AppShell } from "@/components/layout/app-shell";
import { asRole } from "@/lib/rbac";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");

  const user = {
    name: session.user.name ?? "",
    email: session.user.email ?? "",
    role: asRole(session.user.role),
  };

  return <AppShell user={user}>{children}</AppShell>;
}
