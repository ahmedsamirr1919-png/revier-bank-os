import Link from "next/link";
import { notFound } from "next/navigation";
import {
  AlertTriangle,
  ArrowLeft,
  Building2,
  CalendarDays,
  Handshake,
  Mail,
  MessageSquareHeart,
  Phone,
  Star,
  User as UserIcon,
  type LucideIcon,
} from "lucide-react";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { feedbackAccessWhere } from "@/lib/access";
import { asRole, type SessionUser } from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { enumLabel } from "@/lib/i18n";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { Stars } from "@/components/shared/stars";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { CopyLinkButton } from "@/components/feedback/copy-link-button";
import { FeedbackDetailActions } from "@/components/feedback/feedback-detail-actions";
import { feedbackDetailSelect } from "@/lib/queries/feedback";
import { formatDate, parseJsonArray } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function FeedbackDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };

  const feedback = await prisma.feedback.findFirst({
    where: feedbackAccessWhere(user, id),
    select: feedbackDetailSelect,
  });

  if (!feedback) notFound();

  const { t, locale, messages } = await getI18n();
  const pending = feedback.status === "PENDING";
  const categories = parseJsonArray(feedback.categories);
  const displayName =
    feedback.customer?.fullName ?? feedback.submittedByName ?? t("feedback.anonymous");

  return (
    <div className="space-y-5">
      <PageHeader
        title={displayName}
        description={`${t("feedback.title")} · ${formatDate(feedback.createdAt, locale, true)}`}
      >
        <Button variant="ghost" size="sm" asChild>
          <Link href="/feedback">
            <ArrowLeft className="rtl:rotate-180" />
            {t("feedback.title")}
          </Link>
        </Button>
        {pending && <CopyLinkButton token={feedback.token} />}
      </PageHeader>

      <div className="flex flex-wrap items-center gap-2">
        <StatusBadge value={feedback.status} group="feedbackStatus" />
        <Badge variant="outline">{enumLabel(messages, "feedbackSource", feedback.source)}</Badge>
        {!pending && <Stars value={feedback.rating} size="sm" showValue />}
        {feedback.isNegative && (
          <Badge variant="destructive">
            <AlertTriangle />
            {t("feedback.negative")}
          </Badge>
        )}
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <MessageSquareHeart className="size-4 text-primary" />
                {pending ? t("feedback.requestPending") : t("feedback.title")}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {pending ? (
                <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4 text-sm">
                  <p className="font-medium">{t("feedback.requestPending")}</p>
                  <p className="mt-1 text-muted-foreground">{t("feedback.requestPendingHint")}</p>
                  {feedback.expiresAt && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      {t("feedback.expiresOn", { date: formatDate(feedback.expiresAt, locale) })}
                    </p>
                  )}
                </div>
              ) : (
                <>
                  <div className="flex flex-wrap items-center gap-3">
                    <Stars value={feedback.rating} size="lg" />
                    <span className="text-sm text-muted-foreground">
                      {t("feedback.stars", { count: feedback.rating })}
                    </span>
                  </div>
                  {categories.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {categories.map((category) => (
                        <Badge key={category} variant="muted">
                          {enumLabel(messages, "feedbackCategory", category)}
                        </Badge>
                      ))}
                    </div>
                  )}
                  <p className="whitespace-pre-line rounded-lg bg-muted/40 p-4 text-sm leading-relaxed">
                    {feedback.comment ?? t("common.noData")}
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("common.details")}</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 text-sm sm:grid-cols-2">
              <InfoRow icon={UserIcon} label={t("feedback.customer")}>
                {feedback.customer ? (
                  <Link href={`/customers/${feedback.customer.id}`} className="hover:underline">
                    {feedback.customer.fullName}
                  </Link>
                ) : (
                  feedback.submittedByName ?? t("feedback.anonymous")
                )}
              </InfoRow>
              <InfoRow icon={UserIcon} label={t("feedback.agent")}>
                {feedback.agent?.name ?? t("common.unassigned")}
              </InfoRow>
              <InfoRow icon={Handshake} label={t("feedback.deal")}>
                {feedback.deal ? (
                  <Link href={`/deals/${feedback.deal.id}`} className="hover:underline">
                    {feedback.deal.title}
                  </Link>
                ) : (
                  <span className="text-muted-foreground">{t("common.none")}</span>
                )}
              </InfoRow>
              <InfoRow icon={Building2} label={t("feedback.property")}>
                {feedback.property ? (
                  <Link href={`/properties/${feedback.property.id}`} className="hover:underline">
                    {feedback.property.title}
                  </Link>
                ) : (
                  <span className="text-muted-foreground">{t("common.none")}</span>
                )}
              </InfoRow>
              <InfoRow icon={CalendarDays} label={t("feedback.submittedAt")}>
                {formatDate(feedback.createdAt, locale, true)}
              </InfoRow>
              <InfoRow icon={Star} label={t("feedback.resolution")}>
                {feedback.resolvedAt ? (
                  <span>
                    {formatDate(feedback.resolvedAt, locale)}
                    {feedback.resolvedBy ? ` · ${feedback.resolvedBy.name}` : ""}
                  </span>
                ) : (
                  <span className="text-muted-foreground">{t("common.none")}</span>
                )}
              </InfoRow>
              <InfoRow icon={UserIcon} label={t("feedback.submittedBy")}>
                {feedback.submittedByName ?? feedback.customer?.fullName ?? t("feedback.anonymous")}
              </InfoRow>
              <div className="space-y-1.5">
                <p className="text-xs text-muted-foreground">{t("feedback.source")}</p>
                <Badge variant="outline">{enumLabel(messages, "feedbackSource", feedback.source)}</Badge>
              </div>
              {feedback.customer && (
                <div className="space-y-1.5 sm:col-span-2">
                  <p className="text-xs text-muted-foreground">{t("feedback.customer")}</p>
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                    <a href={`tel:${feedback.customer.phone}`} className="flex items-center gap-1.5 hover:text-foreground" dir="ltr">
                      <Phone className="size-3.5" />
                      {feedback.customer.phone}
                    </a>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("feedback.responses")}</CardTitle>
            </CardHeader>
            <CardContent>
              {feedback.replies.length === 0 ? (
                <EmptyState icon={MessageSquareHeart} title={t("feedback.noReplies")} className="py-8" />
              ) : (
                <ol className="space-y-3">
                  {feedback.replies.map((reply) => (
                    <li key={reply.id} className="rounded-lg border p-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-sm font-medium">{reply.author.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatDate(reply.createdAt, locale, true)}
                        </span>
                      </div>
                      <p className="mt-1.5 whitespace-pre-line text-sm text-muted-foreground">{reply.body}</p>
                    </li>
                  ))}
                </ol>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-5">
          <FeedbackDetailActions
            feedback={{
              id: feedback.id,
              token: feedback.token,
              status: feedback.status,
              rating: feedback.rating,
            }}
          />

          {feedback.customer && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{t("feedback.customer")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <Link
                  href={`/customers/${feedback.customer.id}`}
                  className="font-medium hover:underline"
                >
                  {feedback.customer.fullName}
                </Link>
                <p className="text-xs text-muted-foreground">{feedback.customer.code}</p>
                <div className="space-y-2 border-t pt-3 text-xs text-muted-foreground">
                  <a href={`tel:${feedback.customer.phone}`} className="flex items-center gap-2 hover:text-foreground" dir="ltr">
                    <Phone className="size-3.5" />
                    {feedback.customer.phone}
                  </a>
                  {feedback.customer.email && (
                    <a
                      href={`mailto:${feedback.customer.email}`}
                      className="flex items-center gap-2 break-all hover:text-foreground"
                    >
                      <Mail className="size-3.5 shrink-0" />
                      {feedback.customer.email}
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function InfoRow({
  icon: Icon,
  label,
  children,
}: {
  icon: LucideIcon;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="flex items-center gap-2 text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </span>
      <span className="text-end font-medium">{children}</span>
    </div>
  );
}
