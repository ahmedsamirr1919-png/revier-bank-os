import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, assignableAgentWhere, customerScope, dealScope, feedbackScope, type SessionUser } from "@/lib/rbac";
import { feedbackListQuery } from "@/lib/validation/feedback";
import { feedbackListSelect, feedbackOrderBy, feedbackWhere } from "@/lib/queries/feedback";
import { getNegativeThreshold } from "@/lib/feedback";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { FeedbackActions } from "@/components/feedback/feedback-actions";
import { FeedbackView } from "@/components/feedback/feedback-view";
import type {
  FeedbackAgentOption,
  FeedbackCustomerOption,
  FeedbackDealOption,
  FeedbackFilters,
  FeedbackListItem,
  FeedbackStats,
} from "@/components/feedback/types";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function FeedbackPage({ searchParams }: { searchParams: SearchParams }) {
  const session = await auth();
  const raw = await searchParams;
  const params = Object.fromEntries(
    Object.entries(raw)
      .filter(([, value]) => typeof value === "string")
      .map(([key, value]) => [key, value as string]),
  );

  const parsed = feedbackListQuery.safeParse(params);
  const query = parsed.success ? parsed.data : feedbackListQuery.parse({});
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };

  const where = feedbackWhere(user, query);
  const submittedWhere = { ...feedbackScope(user), status: { in: ["NEW", "RESOLVED"] } };

  const [
    total,
    items,
    agents,
    customers,
    deals,
    aggregate,
    submittedTotal,
    negative,
    resolved,
    pending,
    threshold,
  ] = await Promise.all([
    prisma.feedback.count({ where }),
    prisma.feedback.findMany({
      where,
      orderBy: feedbackOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: feedbackListSelect,
    }),
    prisma.user.findMany({
      where: assignableAgentWhere(user),
      orderBy: { name: "asc" },
      select: { id: true, name: true, email: true, role: true },
    }),
    prisma.customer.findMany({
      where: { ...customerScope(user), isDeleted: false },
      orderBy: { fullName: "asc" },
      take: 500,
      select: { id: true, code: true, fullName: true, assignedAgentId: true },
    }),
    prisma.deal.findMany({
      where: { ...dealScope(user), isDeleted: false },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: { id: true, code: true, title: true, customerId: true, propertyId: true, agentId: true },
    }),
    prisma.feedback.aggregate({ where: submittedWhere, _avg: { rating: true } }),
    prisma.feedback.count({ where: submittedWhere }),
    prisma.feedback.count({ where: { ...submittedWhere, isNegative: true } }),
    prisma.feedback.count({ where: { ...submittedWhere, status: "RESOLVED" } }),
    prisma.feedback.count({ where: { ...feedbackScope(user), status: "PENDING" } }),
    getNegativeThreshold(),
  ]);

  const { t } = await getI18n();
  const filters: FeedbackFilters = {
    q: query.q ?? "",
    status: query.status ?? "",
    rating: query.rating ? String(query.rating) : "",
    source: query.source ?? "",
    agentId: query.agentId ?? "",
    sort: query.sort,
  };
  const pages = Math.max(1, Math.ceil(total / query.pageSize));
  const stats: FeedbackStats = {
    average: aggregate._avg.rating ?? 0,
    total: submittedTotal,
    negative,
    resolved,
    pending,
    threshold,
  };

  return (
    <div>
      <PageHeader title={t("feedback.title")} description={t("feedback.subtitle")}>
        <FeedbackActions
          customers={customers as FeedbackCustomerOption[]}
          deals={deals as FeedbackDealOption[]}
          agents={agents as FeedbackAgentOption[]}
        />
      </PageHeader>

      <FeedbackView
        items={items as FeedbackListItem[]}
        total={total}
        page={query.page}
        pageSize={query.pageSize}
        pages={pages}
        filters={filters}
        agents={agents as FeedbackAgentOption[]}
        stats={stats}
      />
    </div>
  );
}
