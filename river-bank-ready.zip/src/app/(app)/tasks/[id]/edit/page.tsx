import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { taskAccessWhere } from "@/lib/access";
import {
  asRole,
  assignableAgentWhere,
  customerScope,
  dealScope,
  type SessionUser,
} from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { TaskForm } from "@/components/tasks/task-form";

export const dynamic = "force-dynamic";

export default async function EditTaskPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };

  const task = await prisma.task.findFirst({
    where: taskAccessWhere(user, id),
    select: {
      id: true,
      title: true,
      description: true,
      type: true,
      priority: true,
      status: true,
      dueAt: true,
      customerId: true,
      dealId: true,
      propertyId: true,
      assignedToId: true,
    },
  });
  if (!task) notFound();

  const [customers, deals, properties, agents, { t }] = await Promise.all([
    prisma.customer.findMany({
      where: { ...customerScope(user), isDeleted: false },
      orderBy: { fullName: "asc" },
      take: 500,
      select: { id: true, code: true, fullName: true, phone: true, status: true },
    }),
    prisma.deal.findMany({
      where: { ...dealScope(user), isDeleted: false },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: { id: true, code: true, title: true, stage: true },
    }),
    prisma.property.findMany({
      where: { isDeleted: false },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: { id: true, code: true, title: true, status: true },
    }),
    prisma.user.findMany({
      where: assignableAgentWhere(user),
      orderBy: [{ role: "asc" }, { name: "asc" }],
      select: { id: true, name: true, email: true, role: true },
    }),
    getI18n(),
  ]);

  return (
    <div>
      <PageHeader title={t("tasks.edit")} description={task.title} />
      <TaskForm
        mode="edit"
        task={task}
        customers={customers}
        deals={deals}
        properties={properties}
        agents={agents}
        canAssignAgent={role !== "AGENT"}
      />
    </div>
  );
}
