import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, taskScope, type SessionUser } from "@/lib/rbac";
import { taskListQuery } from "@/lib/validation/task";
import { taskListSelect, taskOrderBy, taskWhere } from "@/lib/queries/tasks";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { TaskActions } from "@/components/tasks/task-actions";
import { TasksView } from "@/components/tasks/tasks-view";
import type { TaskFilters, TaskListItem } from "@/components/tasks/types";
import { endOfDay, startOfDay } from "@/lib/utils";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function TasksPage({ searchParams }: { searchParams: SearchParams }) {
  const session = await auth();
  const raw = await searchParams;
  const params = Object.fromEntries(
    Object.entries(raw)
      .filter(([, value]) => typeof value === "string")
      .map(([key, value]) => [key, value as string]),
  );

  const parsed = taskListQuery.safeParse(params);
  const query = parsed.success ? parsed.data : taskListQuery.parse({});
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };

  const where = taskWhere(user, query);
  const scope = taskScope(user);
  const now = new Date();
  const dayStart = startOfDay(now);
  const dayEnd = endOfDay(now);

  const [total, items, pending, overdue, today, done] = await Promise.all([
    prisma.task.count({ where }),
    prisma.task.findMany({
      where,
      orderBy: taskOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: taskListSelect,
    }),
    prisma.task.count({ where: { ...scope, status: "PENDING" } }),
    prisma.task.count({ where: { ...scope, status: "PENDING", dueAt: { lt: now } } }),
    prisma.task.count({
      where: { ...scope, status: "PENDING", dueAt: { gte: dayStart, lte: dayEnd } },
    }),
    prisma.task.count({ where: { ...scope, status: "DONE" } }),
  ]);

  const { t } = await getI18n();
  const filters: TaskFilters = {
    q: query.q ?? "",
    status: query.status ?? "",
    type: query.type ?? "",
    priority: query.priority ?? "",
    sort: query.sort,
  };
  const pages = Math.max(1, Math.ceil(total / query.pageSize));

  return (
    <div>
      <PageHeader title={t("tasks.title")} description={t("tasks.subtitle")}>
        <TaskActions />
      </PageHeader>

      <TasksView
        items={items as TaskListItem[]}
        total={total}
        page={query.page}
        pageSize={query.pageSize}
        pages={pages}
        filters={filters}
        counts={{ pending, overdue, today, done }}
      />
    </div>
  );
}
