import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import {
  asRole,
  assignableAgentWhere,
  customerScope,
  dealScope,
  type SessionUser,
} from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { TaskForm } from "@/components/tasks/task-form";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function NewTaskPage({ searchParams }: { searchParams: SearchParams }) {
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };
  const raw = await searchParams;

  const [customers, deals, properties, agents, { t }] = await Promise.all([
    prisma.customer.findMany({
      where: { ...customerScope(user), isDeleted: false },
      orderBy: { fullName: "asc" },
      take: 500,
      select: { id: true, code: true, fullName: true, phone: true, status: true },
    }),
    prisma.deal.findMany({
      where: { ...dealScope(user), isDeleted: false },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: { id: true, code: true, title: true, stage: true },
    }),
    prisma.property.findMany({
      where: { isDeleted: false },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: { id: true, code: true, title: true, status: true },
    }),
    prisma.user.findMany({
      where: assignableAgentWhere(user),
      orderBy: [{ role: "asc" }, { name: "asc" }],
      select: { id: true, name: true, email: true, role: true },
    }),
    getI18n(),
  ]);

  return (
    <div>
      <PageHeader title={t("tasks.new")} description={t("tasks.subtitle")} />
      <TaskForm
        mode="create"
        customers={customers}
        deals={deals}
        properties={properties}
        agents={agents}
        canAssignAgent={role !== "AGENT"}
        defaults={{
          customerId: typeof raw.customerId === "string" ? raw.customerId : undefined,
          dealId: typeof raw.dealId === "string" ? raw.dealId : undefined,
          propertyId: typeof raw.propertyId === "string" ? raw.propertyId : undefined,
          dueAt: typeof raw.dueAt === "string" ? raw.dueAt : undefined,
        }}
      />
    </div>
  );
}
