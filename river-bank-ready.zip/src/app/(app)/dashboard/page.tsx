import { redirect } from "next/navigation";
import { AlertTriangle, Handshake, TrendingUp, Users, Wallet } from "lucide-react";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { getI18n } from "@/lib/i18n/server";
import { asRole, customerScope, dealScope, feedbackScope, taskScope, type SessionUser } from "@/lib/rbac";
import { formatCurrency } from "@/lib/utils";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/shared/status-badge";
import { Stars } from "@/components/shared/stars";

import { DEFAULT_STALE_DAYS, OPEN_DEAL_STAGES } from "@/lib/constants";
import { DashboardCharts } from "@/components/dashboard/dashboard-charts";
import { staleLeads } from "@/lib/leads";
import Link from "next/link";

export const metadata = { title: "Dashboard" };

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default async function DashboardPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");

  const user: SessionUser = {
    id: session.user.id,
    name: session.user.name,
    email: session.user.email,
    role: asRole(session.user.role),
    managerId: session.user.managerId ?? null,
  };

  const { t, locale } = await getI18n();
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const customerWhere = { ...customerScope(user), isDeleted: false };
  const dealWhere = { ...dealScope(user), isDeleted: false };

  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
  sixMonthsAgo.setDate(1);
  sixMonthsAgo.setHours(0, 0, 0, 0);

  const [
    totalCustomers,
    newLeads,
    dealsInProgress,
    closedSales,
    revenue,
    negativeFeedback,
    dealStageGroups,
    sourceGroups,
    closedDeals,
    upcomingTasks,
  ] = await Promise.all([
    prisma.customer.count({ where: customerWhere }),
    prisma.customer.count({ where: { ...customerWhere, createdAt: { gte: monthStart } } }),
    prisma.deal.count({ where: { ...dealWhere, stage: { in: OPEN_DEAL_STAGES } } }),
    prisma.deal.count({ where: { ...dealWhere, stage: "CLOSED_WON" } }),
    prisma.deal.aggregate({ where: { ...dealWhere, stage: "CLOSED_WON" }, _sum: { value: true } }),
    prisma.feedback.findMany({
      where: { ...feedbackScope(user), status: { not: "RESOLVED" }, isNegative: true },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true,
        rating: true,
        submittedByName: true,
        createdAt: true,
        customer: { select: { id: true, fullName: true } },
        agent: { select: { name: true } },
      },
    }),
    prisma.deal.groupBy({
      by: ["stage"],
      where: dealWhere,
      _count: { _all: true },
    }),
    prisma.customer.groupBy({
      by: ["source"],
      where: customerWhere,
      _count: { _all: true },
    }),
    prisma.deal.findMany({
      where: { ...dealWhere, stage: "CLOSED_WON", closedAt: { gte: sixMonthsAgo } },
      select: { closedAt: true, value: true, agent: { select: { name: true } } },
    }),
    prisma.task.findMany({
      where: { ...taskScope(user), status: "PENDING", dueAt: { gte: new Date() } },
      orderBy: { dueAt: "asc" },
      take: 5,
      select: { id: true, title: true, dueAt: true, priority: true },
    }),
  ]);

  const staleSetting = await prisma.setting.findUnique({ where: { key: "settings.staleLeadDays" } });
  const staleValue = Number(staleSetting?.value ?? 0);
  const staleDays = staleValue > 0 ? staleValue : DEFAULT_STALE_DAYS;
  const staleItems = await staleLeads(user, staleDays);

  // monthly sales aggregation
  const monthlyMap = new Map<string, number>();
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    monthlyMap.set(key, 0);
  }
  for (const deal of closedDeals) {
    if (!deal.closedAt) continue;
    const key = `${deal.closedAt.getFullYear()}-${String(deal.closedAt.getMonth() + 1).padStart(2, "0")}`;
    if (monthlyMap.has(key)) monthlyMap.set(key, (monthlyMap.get(key) ?? 0) + deal.value);
  }
  const monthly = [...monthlyMap.entries()].map(([key, revenue]) => {
    const [year, month] = key.split("-");
    return { month: `${MONTHS[Number(month) - 1]}`, revenue };
  });

  // agent leaderboard
  const agentMap = new Map<string, { name: string; revenue: number; deals: number }>();
  for (const deal of closedDeals) {
    const name = deal.agent?.name ?? "—";
    const entry = agentMap.get(name) ?? { name, revenue: 0, deals: 0 };
    entry.revenue += deal.value;
    entry.deals += 1;
    agentMap.set(name, entry);
  }
  const agents = [...agentMap.values()];

  // employee performance
  const employeeUsers =
    user.role === "ADMIN"
      ? await prisma.user.findMany({
          where: { role: { in: ["AGENT", "MANAGER"] }, isActive: true },
          orderBy: [{ role: "asc" }, { name: "asc" }],
          select: { id: true, name: true, email: true, role: true },
        })
      : user.role === "MANAGER"
        ? await prisma.user.findMany({
            where: { OR: [{ id: user.id }, { managerId: user.id }], isActive: true },
            orderBy: [{ role: "asc" }, { name: "asc" }],
            select: { id: true, name: true, email: true, role: true },
          })
        : await prisma.user.findMany({
            where: { id: user.id },
            select: { id: true, name: true, email: true, role: true },
          });

  const employeeIds = employeeUsers.map((employee) => employee.id);
  const employeeCustomerCounts =
    employeeIds.length > 0
      ? await prisma.customer.groupBy({
          by: ["assignedAgentId"],
          where: { isDeleted: false, assignedAgentId: { in: employeeIds } },
          _count: { _all: true },
        })
      : [];
  const employeeDealGroups =
    employeeIds.length > 0
      ? await prisma.deal.groupBy({
          by: ["agentId", "stage"],
          where: { isDeleted: false, agentId: { in: employeeIds } },
          _count: { _all: true },
          _sum: { value: true },
        })
      : [];

  const employeePerfMap = new Map(
    employeeIds.map((id) => [id, { customers: 0, openDeals: 0, closedDeals: 0, revenue: 0, totalDeals: 0 }]),
  );
  for (const group of employeeCustomerCounts) {
    if (!group.assignedAgentId) continue;
    const entry = employeePerfMap.get(group.assignedAgentId);
    if (entry) entry.customers = group._count._all;
  }
  for (const group of employeeDealGroups) {
    const entry = employeePerfMap.get(group.agentId);
    if (!entry) continue;
    const count = group._count._all;
    entry.totalDeals += count;
    if (group.stage === "CLOSED_WON") {
      entry.closedDeals += count;
      entry.revenue += group._sum.value ?? 0;
    } else if (group.stage !== "CLOSED_LOST") {
      entry.openDeals += count;
    }
  }
  const employeePerformance = employeeUsers
    .map((employee) => {
      const stats = employeePerfMap.get(employee.id)!;
      return {
        ...employee,
        ...stats,
        conversion: stats.totalDeals > 0 ? Math.round((stats.closedDeals / stats.totalDeals) * 100) : 0,
      };
    })
    .sort((a, b) => b.revenue - a.revenue);

  const dealStages = dealStageGroups.map((group) => ({
    stage: group.stage,
    count: group._count._all,
  }));

  const sources = sourceGroups.map((group) => ({
    source: group.source,
    count: group._count._all,
  }));

  return (
    <div>
      <PageHeader
        title={t("dashboard.title")}
        description={t("dashboard.welcome", { name: session.user.name ?? "" })}
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard label={t("dashboard.totalCustomers")} value={String(totalCustomers)} icon={Users} />
        <StatCard label={t("dashboard.newLeads")} value={String(newLeads)} icon={TrendingUp} tone="teal" />
        <StatCard label={t("dashboard.dealsInProgress")} value={String(dealsInProgress)} icon={Handshake} tone="amber" />
        <StatCard label={t("dashboard.closedSales")} value={String(closedSales)} icon={Handshake} tone="emerald" />
        <StatCard
          label={t("dashboard.revenue")}
          value={formatCurrency(revenue._sum.value ?? 0, locale, true)}
          icon={Wallet}
          tone="primary"
        />
      </div>

      {negativeFeedback.length > 0 && (
        <Card className="mt-5 border-rose-500/30">
          <CardHeader className="flex-row items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2 text-base text-rose-600 dark:text-rose-400">
              <AlertTriangle className="size-4" />
              {t("dashboard.negativeFeedback")}
            </CardTitle>
            <Link href="/feedback?negative=1" className="text-xs text-primary hover:underline">
              {t("common.viewAll")}
            </Link>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {negativeFeedback.map((item) => (
                <li key={item.id} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2 text-sm">
                  <div className="min-w-0">
                    <Link href={`/feedback/${item.id}`} className="font-medium hover:underline">
                      {item.customer?.fullName ?? item.submittedByName ?? t("feedback.anonymous")}
                    </Link>
                    <p className="truncate text-xs text-muted-foreground">
                      {item.agent?.name ?? t("common.unassigned")} · {new Date(item.createdAt).toLocaleDateString(locale === "ar" ? "ar-AE" : "en-GB")}
                    </p>
                  </div>
                  <Stars value={item.rating} size="sm" />
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {staleItems.length > 0 && (
        <Card className="mt-5">
          <CardHeader className="flex-row items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="size-4 text-amber-500" />
              {t("leads.stale")}
            </CardTitle>
            <Link href="/customers" className="text-xs text-primary hover:underline">
              {t("common.viewAll")}
            </Link>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {staleItems.slice(0, 5).map((lead) => (
                <li key={lead.id} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2 text-sm">
                  <div className="min-w-0">
                    <Link href={`/customers/${lead.id}`} className="font-medium hover:underline">
                      {lead.fullName}
                    </Link>
                    <p className="truncate text-xs text-muted-foreground">
                      {lead.code} · {lead.assignedAgent?.name ?? t("common.unassigned")} ·{" "}
                      {t("leads.staleDays", { count: lead.daysSinceActivity })}
                    </p>
                  </div>
                  <StatusBadge value={lead.status} />
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      <DashboardCharts
        dealStages={dealStages}
        sources={sources}
        monthly={monthly}
        agents={agents}
      />

      {employeePerformance.length > 0 && (
        <Card className="mt-5">
          <CardHeader>
            <CardTitle className="text-base">{t("dashboard.employeePerformance")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("users.name")}</TableHead>
                    <TableHead className="text-end">{t("customers.title")}</TableHead>
                    <TableHead className="text-end">{t("dashboard.dealsInProgress")}</TableHead>
                    <TableHead className="text-end">{t("dashboard.closedSales")}</TableHead>
                    <TableHead className="text-end">{t("dashboard.revenue")}</TableHead>
                    <TableHead className="text-end">{t("dashboard.conversion")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {employeePerformance.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell>
                        <div className="font-medium">{employee.name}</div>
                        <div className="text-xs text-muted-foreground">{employee.role}</div>
                      </TableCell>
                      <TableCell className="text-end">{employee.customers}</TableCell>
                      <TableCell className="text-end">{employee.openDeals}</TableCell>
                      <TableCell className="text-end">{employee.closedDeals}</TableCell>
                      <TableCell className="text-end" dir="ltr">
                        {formatCurrency(employee.revenue, locale, true)}
                      </TableCell>
                      <TableCell className="text-end">{employee.conversion}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {upcomingTasks.length > 0 && (
        <Card className="mt-5">
          <CardHeader>
            <CardTitle className="text-base">{t("dashboard.upcomingTasks")}</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {upcomingTasks.map((task) => (
                <li key={task.id} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2 text-sm">
                  <Link href={`/tasks/${task.id}`} className="font-medium hover:underline">
                    {task.title}
                  </Link>
                  <span className="text-xs text-muted-foreground">
                    {new Date(task.dueAt).toLocaleDateString(locale === "ar" ? "ar-AE" : "en-GB")}
                  </span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
