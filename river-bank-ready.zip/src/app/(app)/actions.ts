"use server";

import { auth, signOut } from "@/auth";
import { logActivity } from "@/lib/activity";

export async function signOutAction() {
  const session = await auth();
  if (session?.user?.id) {
    await logActivity({
      userId: session.user.id,
      userEmail: session.user.email,
      action: "LOGOUT",
      entityType: "User",
      entityId: session.user.id,
      description: `${session.user.name ?? session.user.email} signed out`,
    });
  }
  await signOut({ redirectTo: "/login" });
}
