import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { PropertyForm } from "@/components/properties/property-form";

export const dynamic = "force-dynamic";

export default async function NewPropertyPage() {
  const { t } = await getI18n();

  return (
    <div>
      <PageHeader title={t("properties.new")} description={t("properties.subtitle")} />
      <PropertyForm mode="create" />
    </div>
  );
}
