import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { PropertyForm } from "@/components/properties/property-form";

export const dynamic = "force-dynamic";

export default async function EditPropertyPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const property = await prisma.property.findFirst({
    where: { id, isDeleted: false },
    select: {
      id: true,
      title: true,
      type: true,
      price: true,
      area: true,
      location: true,
      city: true,
      bedrooms: true,
      bathrooms: true,
      status: true,
      description: true,
      ownerName: true,
      ownerPhone: true,
      ownerEmail: true,
      ownerIdNumber: true,
      ownerNotes: true,
      tags: true,
      images: {
        orderBy: [{ isPrimary: "desc" }, { sortOrder: "asc" }],
        select: { id: true, url: true, alt: true, isPrimary: true, sortOrder: true },
      },
    },
  });
  if (!property) notFound();

  const { t } = await getI18n();

  return (
    <div>
      <PageHeader title={t("properties.edit")} description={`${property.title} · ${property.city}`} />
      <PropertyForm mode="edit" property={property} />
    </div>
  );
}
