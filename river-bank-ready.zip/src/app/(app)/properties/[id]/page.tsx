import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  Bath,
  BedDouble,
  Building2,
  CalendarDays,
  CircleDollarSign,
  Handshake,
  IdCard,
  Mail,
  MapPin,
  MessageSquareHeart,
  Phone,
  Ruler,
  StickyNote,
  User as UserIcon,
  Users,
} from "lucide-react";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, canDelete } from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { enumLabel } from "@/lib/i18n";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { Stars } from "@/components/shared/stars";
import { EmptyState } from "@/components/shared/empty-state";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PropertyGallery } from "@/components/properties/property-gallery";
import { PropertyDetailActions } from "@/components/properties/property-detail-actions";
import { PropertyLinkRemove } from "@/components/properties/property-link-remove";
import { formatCurrency, formatDate, formatNumber } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function PropertyDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  const role = asRole(session?.user?.role);

  const property = await prisma.property.findFirst({
    where: { id, ...(role === "ADMIN" ? {} : { isDeleted: false }) },
    include: {
      images: { orderBy: [{ isPrimary: "desc" }, { sortOrder: "asc" }] },
      createdBy: { select: { id: true, name: true, email: true } },
      interests: {
        orderBy: { createdAt: "desc" },
        include: {
          customer: {
            select: {
              id: true,
              code: true,
              fullName: true,
              phone: true,
              status: true,
              assignedAgentId: true,
            },
          },
        },
      },
      deals: {
        where: { isDeleted: false },
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          code: true,
          title: true,
          stage: true,
          value: true,
          currency: true,
          agent: { select: { id: true, name: true } },
        },
      },
      feedback: {
        orderBy: { createdAt: "desc" },
        take: 20,
        select: { id: true, rating: true, comment: true, status: true, createdAt: true },
      },
    },
  });

  if (!property) notFound();

  const [{ t, locale, messages }] = await Promise.all([getI18n()]);

  const propertyTags = property.tags ? (JSON.parse(property.tags) as string[]) : [];

  const averageRating = property.feedback.length
    ? property.feedback.reduce((sum, item) => sum + item.rating, 0) / property.feedback.length
    : 0;

  return (
    <div className="space-y-5">
      <PageHeader
        title={property.title}
        description={`${property.code} · ${t("properties.listed")} ${formatDate(property.createdAt, locale)}`}
      >
        <PropertyDetailActions
          property={{ id: property.id, title: property.title }}
          linkedCustomerIds={property.interests.map((interest) => interest.customer.id)}
          canDelete={canDelete(role)}
          isDeleted={property.isDeleted}
        />
      </PageHeader>

      <div className="flex flex-wrap items-center gap-2 text-sm">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/properties">
            <ArrowLeft className="rtl:rotate-180" />
            {t("properties.title")}
          </Link>
        </Button>
        <StatusBadge value={property.status} group="propertyStatus" />
        <span className="text-muted-foreground">{enumLabel(messages, "propertyType", property.type)}</span>
        {property.isDeleted && (
          <span className="rounded bg-destructive/10 px-2 py-0.5 text-xs font-medium text-destructive">
            {t("customers.trash")}
          </span>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <SummaryCard
          icon={CircleDollarSign}
          label={t("properties.price")}
          value={formatCurrency(property.price, locale)}
        />
        <SummaryCard
          icon={Ruler}
          label={t("properties.area")}
          value={`${formatNumber(property.area, locale)} ${t("properties.sqm")}`}
        />
        <SummaryCard
          icon={Users}
          label={t("properties.linkedCustomers")}
          value={String(property.interests.length)}
        />
        <SummaryCard
          icon={Handshake}
          label={t("customers.deals")}
          value={String(property.deals.length)}
        />
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <Card>
            <CardContent className="pt-1">
              <PropertyGallery images={property.images} title={property.title} />
            </CardContent>
          </Card>

          {property.description && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{t("properties.description")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                  {property.description}
                </p>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("properties.linkedCustomers")}</CardTitle>
            </CardHeader>
            <CardContent>
              {property.interests.length === 0 ? (
                <EmptyState icon={Users} title={t("properties.noLinks")} className="py-8" />
              ) : (
                <div className="rounded-lg border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t("customers.fullName")}</TableHead>
                        <TableHead>{t("properties.relation")}</TableHead>
                        <TableHead className="hidden sm:table-cell">{t("customers.status")}</TableHead>
                        <TableHead className="hidden md:table-cell">{t("customers.phone")}</TableHead>
                        <TableHead className="w-10" />
                        <TableHead className="w-10" />
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {property.interests.map((interest) => (
                        <TableRow key={interest.id}>
                          <TableCell>
                            <Link
                              href={`/customers/${interest.customer.id}`}
                              className="font-medium hover:underline"
                            >
                              {interest.customer.fullName}
                            </Link>
                            <span className="block text-xs text-muted-foreground">
                              {interest.customer.code}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className="text-sm text-muted-foreground">
                              {interest.relation === "PURCHASED"
                                ? t("properties.purchased")
                                : t("properties.interested")}
                            </span>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell">
                            <StatusBadge value={interest.customer.status} />
                          </TableCell>
                          <TableCell className="hidden md:table-cell" dir="ltr">
                            {interest.customer.phone}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="icon-sm" asChild title={t("properties.createDeal")}>
                              <Link href={`/deals/new?customerId=${interest.customer.id}&propertyId=${property.id}`}>
                                <Handshake />
                              </Link>
                            </Button>
                          </TableCell>
                          <TableCell className="text-end">
                            <PropertyLinkRemove
                              propertyId={property.id}
                              linkId={interest.id}
                              customerName={interest.customer.fullName}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("customers.deals")}</CardTitle>
            </CardHeader>
            <CardContent>
              {property.deals.length === 0 ? (
                <EmptyState icon={Handshake} title={t("deals.noDeals")} className="py-8" />
              ) : (
                <div className="rounded-lg border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t("deals.titleField")}</TableHead>
                        <TableHead>{t("deals.stage")}</TableHead>
                        <TableHead>{t("deals.value")}</TableHead>
                        <TableHead className="hidden sm:table-cell">{t("deals.agent")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {property.deals.map((deal) => (
                        <TableRow key={deal.id}>
                          <TableCell>
                            <Link href={`/deals/${deal.id}`} className="font-medium hover:underline">
                              {deal.title}
                            </Link>
                            <span className="block text-xs text-muted-foreground">{deal.code}</span>
                          </TableCell>
                          <TableCell>
                            <StatusBadge value={deal.stage} group="dealStage" />
                          </TableCell>
                          <TableCell dir="ltr">{formatCurrency(deal.value, locale)}</TableCell>
                          <TableCell className="hidden sm:table-cell text-muted-foreground">
                            {deal.agent.name}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("properties.details")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <InfoRow icon={Building2} label={t("properties.type")}>
                {enumLabel(messages, "propertyType", property.type)}
              </InfoRow>
              <InfoRow icon={Building2} label={t("properties.purpose")}>
                {enumLabel(messages, "propertyPurpose", property.purpose)}
              </InfoRow>
              <InfoRow icon={MapPin} label={t("properties.location")}>
                {property.location}, {property.city}
              </InfoRow>
              <InfoRow icon={BedDouble} label={t("properties.bedrooms")}>
                {property.bedrooms ?? "—"}
              </InfoRow>
              <InfoRow icon={Bath} label={t("properties.bathrooms")}>
                {property.bathrooms ?? "—"}
              </InfoRow>
              <InfoRow icon={Ruler} label={t("properties.area")}>
                {formatNumber(property.area, locale)} {t("properties.sqm")}
              </InfoRow>
              <InfoRow icon={CalendarDays} label={t("properties.listed")}>
                {formatDate(property.createdAt, locale)}
              </InfoRow>
              {property.createdBy && (
                <InfoRow icon={UserIcon} label={t("customers.createdBy")}>
                  {property.createdBy.name}
                </InfoRow>
              )}
              {propertyTags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 border-t pt-3">
                  {propertyTags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary"
                    >
                      {enumLabel(messages, "propertyTag", tag)}
                    </span>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("properties.owner")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <InfoRow icon={UserIcon} label={t("properties.ownerName")}>
                {property.ownerName ?? "—"}
              </InfoRow>
              <InfoRow icon={Phone} label={t("properties.ownerPhone")}>
                {property.ownerPhone ? (
                  <a href={`tel:${property.ownerPhone}`} dir="ltr" className="hover:underline">
                    {property.ownerPhone}
                  </a>
                ) : (
                  "—"
                )}
              </InfoRow>
              <InfoRow icon={Mail} label={t("properties.ownerEmail")}>
                {property.ownerEmail ? (
                  <a href={`mailto:${property.ownerEmail}`} dir="ltr" className="hover:underline">
                    {property.ownerEmail}
                  </a>
                ) : (
                  "—"
                )}
              </InfoRow>
              <InfoRow icon={IdCard} label={t("properties.ownerIdNumber")}>
                <span dir="ltr">{property.ownerIdNumber ?? "—"}</span>
              </InfoRow>
              {property.ownerNotes && (
                <div className="border-t pt-3">
                  <p className="mb-1 flex items-center gap-2 text-muted-foreground">
                    <StickyNote className="size-3.5" />
                    {t("properties.ownerNotes")}
                  </p>
                  <p className="whitespace-pre-line font-normal">{property.ownerNotes}</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("customers.feedback")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {property.feedback.length === 0 ? (
                <p className="text-sm text-muted-foreground">{t("customers.noFeedback")}</p>
              ) : (
                <>
                  <div className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
                    <span className="text-sm text-muted-foreground">{t("feedback.average")}</span>
                    <span className="flex items-center gap-2 font-semibold">
                      {averageRating.toFixed(1)}
                      <Stars value={averageRating} size="sm" />
                    </span>
                  </div>
                  <ul className="space-y-2">
                    {property.feedback.slice(0, 5).map((item) => (
                      <li key={item.id} className="rounded-lg border p-3">
                        <div className="flex items-center justify-between gap-2">
                          <Stars value={item.rating} size="sm" />
                          <span className="text-xs text-muted-foreground">
                            {formatDate(item.createdAt, locale)}
                          </span>
                        </div>
                        {item.comment && (
                          <p className="mt-1.5 line-clamp-2 text-xs text-muted-foreground">{item.comment}</p>
                        )}
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center gap-3 py-4">
              <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <MessageSquareHeart className="size-4" />
              </span>
              <div className="text-sm">
                <p className="font-medium">{t("properties.availability")}</p>
                <StatusBadge value={property.status} group="propertyStatus" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Users;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <Card className="py-4">
      <CardContent className="flex items-center gap-3">
        <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="size-4" />
        </span>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="truncate text-sm font-semibold" dir="auto">
            {value}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function InfoRow({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof MapPin;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="flex items-center gap-2 text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </span>
      <span className="text-end font-medium">{children}</span>
    </div>
  );
}
