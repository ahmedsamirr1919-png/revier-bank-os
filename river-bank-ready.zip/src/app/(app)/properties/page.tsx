import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, canDelete } from "@/lib/rbac";
import { propertyListQuery } from "@/lib/validation/property";
import { propertyListSelect, propertyOrderBy, propertyWhere } from "@/lib/queries/properties";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { PropertyActions } from "@/components/properties/property-actions";
import { PropertiesView } from "@/components/properties/properties-view";
import type { PropertyFilters, PropertyListItem } from "@/components/properties/types";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function PropertiesPage({ searchParams }: { searchParams: SearchParams }) {
  const session = await auth();
  const raw = await searchParams;
  const params = Object.fromEntries(
    Object.entries(raw)
      .filter(([, value]) => typeof value === "string")
      .map(([key, value]) => [key, value as string]),
  );

  const parsed = propertyListQuery.safeParse(params);
  const query = parsed.success ? parsed.data : propertyListQuery.parse({});
  const role = asRole(session?.user?.role);
  const trash = query.trash === "1" && canDelete(role);

  const where = propertyWhere(query);
  where.isDeleted = trash;

  const [total, items] = await Promise.all([
    prisma.property.count({ where }),
    prisma.property.findMany({
      where,
      orderBy: propertyOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: propertyListSelect,
    }),
  ]);

  const { t } = await getI18n();
  const filters: PropertyFilters = {
    q: query.q ?? "",
    type: query.type ?? "",
    tag: query.tag ?? "",
    purpose: query.purpose ?? "",
    status: query.status ?? "",
    sort: query.sort,
    trash: trash ? "1" : "0",
  };
  const pages = Math.max(1, Math.ceil(total / query.pageSize));

  return (
    <div>
      <PageHeader title={t("properties.title")} description={t("properties.subtitle")}>
        <PropertyActions canDelete={canDelete(role)} trash={trash} />
      </PageHeader>

      <PropertiesView
        items={items as PropertyListItem[]}
        total={total}
        page={query.page}
        pageSize={query.pageSize}
        pages={pages}
        filters={filters}
        canDelete={canDelete(role)}
      />
    </div>
  );
}
