import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  Building2,
  CalendarDays,
  CircleDollarSign,
  GitBranch,
  Handshake,
  ListTodo,
  Mail,
  Phone,
  TrendingUp,
  User as UserIcon,
  type LucideIcon,
} from "lucide-react";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { dealAccessWhere } from "@/lib/access";
import { asRole, canDelete, type SessionUser } from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { enumLabel } from "@/lib/i18n";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/empty-state";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { DealDetailActions } from "@/components/deals/deal-detail-actions";
import { DealPayments } from "@/components/deals/deal-payments";
import { formatCurrency, formatDate } from "@/lib/utils";
import { DEAL_STAGE_COLORS } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function DealDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };
  const admin = canDelete(role);

  const deal = await prisma.deal.findFirst({
    where: dealAccessWhere(user, id, { allowDeleted: admin }),
    include: {
      customer: {
        select: {
          id: true,
          code: true,
          fullName: true,
          phone: true,
          email: true,
          status: true,
          assignedAgentId: true,
        },
      },
      property: {
        select: { id: true, code: true, title: true, status: true, price: true, location: true, city: true },
      },
      agent: { select: { id: true, name: true, email: true } },
      stageHistory: { orderBy: { createdAt: "desc" }, take: 50 },
      tasks: {
        orderBy: { dueAt: "asc" },
        take: 20,
        select: {
          id: true,
          title: true,
          type: true,
          priority: true,
          status: true,
          dueAt: true,
          assignedTo: { select: { id: true, name: true } },
        },
      },
    },
  });

  if (!deal) notFound();

  const { t, locale, messages } = await getI18n();

  return (
    <div className="space-y-5">
      <PageHeader
        title={deal.title}
        description={`${deal.code} · ${t("deals.detail")} · ${formatDate(deal.createdAt, locale)}`}
      >
        <DealDetailActions
          deal={{ id: deal.id, stage: deal.stage }}
          canRestore={admin}
          isDeleted={deal.isDeleted}
        />
      </PageHeader>

      <div className="flex flex-wrap items-center gap-2 text-sm">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/deals">
            <ArrowLeft className="rtl:rotate-180" />
            {t("deals.title")}
          </Link>
        </Button>
        <StatusBadge value={deal.stage} group="dealStage" />
        <span className="text-muted-foreground">{deal.agent.name}</span>
        {deal.isDeleted && (
          <span className="rounded bg-destructive/10 px-2 py-0.5 text-xs font-medium text-destructive">
            {t("customers.trash")}
          </span>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <SummaryCard
          icon={CircleDollarSign}
          label={t("deals.value")}
          value={formatCurrency(deal.value, locale)}
        />
        <SummaryCard
          icon={TrendingUp}
          label={t("deals.commissionAmount")}
          value={formatCurrency(deal.commissionAmount, locale)}
        />
        <SummaryCard
          icon={GitBranch}
          label={t("deals.probability")}
          value={`${deal.probability}%`}
        />
        <SummaryCard
          icon={CalendarDays}
          label={t("deals.expectedClose")}
          value={formatDate(deal.expectedCloseDate, locale)}
        />
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("deals.details")}</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 text-sm sm:grid-cols-2">
              <InfoRow icon={UserIcon} label={t("deals.customer")}>
                <Link href={`/customers/${deal.customer.id}`} className="hover:underline">
                  {deal.customer.fullName}
                </Link>
              </InfoRow>
              <InfoRow icon={Building2} label={t("deals.property")}>
                {deal.property ? (
                  <Link href={`/properties/${deal.property.id}`} className="hover:underline">
                    {deal.property.title}
                  </Link>
                ) : (
                  <span className="text-muted-foreground">{t("deals.noProperty")}</span>
                )}
              </InfoRow>
              <InfoRow icon={UserIcon} label={t("deals.agent")}>
                {deal.agent.name}
              </InfoRow>
              <InfoRow icon={CalendarDays} label={t("deals.expectedClose")}>
                {formatDate(deal.expectedCloseDate, locale)}
              </InfoRow>
              <InfoRow icon={CalendarDays} label={t("deals.closedAt")}>
                {formatDate(deal.closedAt, locale)}
              </InfoRow>
              <InfoRow icon={TrendingUp} label={t("deals.probability")}>
                {deal.probability}%
              </InfoRow>
              {deal.lostReason && (
                <div className="sm:col-span-2">
                  <p className="text-xs text-muted-foreground">{t("deals.lostReason")}</p>
                  <p className="mt-1 rounded-lg bg-destructive/5 p-3 text-sm text-destructive">
                    {deal.lostReason}
                  </p>
                </div>
              )}
              {deal.notes && (
                <div className="sm:col-span-2">
                  <p className="text-xs text-muted-foreground">{t("deals.notes")}</p>
                  <p className="mt-1 whitespace-pre-line rounded-lg bg-muted/50 p-3 text-sm">
                    {deal.notes}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("deals.stageHistory")}</CardTitle>
            </CardHeader>
            <CardContent>
              {deal.stageHistory.length === 0 ? (
                <EmptyState icon={GitBranch} title={t("common.noData")} className="py-8" />
              ) : (
                <ol className="relative space-y-4 border-s ps-5">
                  {deal.stageHistory.map((entry) => (
                    <li key={entry.id} className="relative">
                      <span
                        className="absolute -start-[1.55rem] top-1.5 size-2.5 rounded-full ring-4 ring-background"
                        style={{ backgroundColor: DEAL_STAGE_COLORS[entry.toStage] ?? "#64748b" }}
                      />
                      <div className="flex flex-wrap items-center gap-2 text-sm">
                        {entry.fromStage && (
                          <>
                            <span className="text-muted-foreground">
                              {enumLabel(messages, "dealStage", entry.fromStage)}
                            </span>
                            <span className="text-muted-foreground">→</span>
                          </>
                        )}
                        <StatusBadge value={entry.toStage} group="dealStage" />
                      </div>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {formatDate(entry.createdAt, locale, true)}
                        {entry.changedByName ? ` · ${entry.changedByName}` : ""}
                      </p>
                      {entry.note && <p className="mt-1 text-xs text-muted-foreground">{entry.note}</p>}
                    </li>
                  ))}
                </ol>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="text-base">{t("customers.tasks")}</CardTitle>
              <Button variant="outline" size="sm" asChild>
                <Link
                  href={`/tasks/new?dealId=${deal.id}&customerId=${deal.customerId}&propertyId=${deal.propertyId ?? ""}`}
                >
                  <ListTodo />
                  {t("tasks.new")}
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              {deal.tasks.length === 0 ? (
                <EmptyState icon={ListTodo} title={t("tasks.noTasks")} className="py-8" />
              ) : (
                <ul className="space-y-2">
                  {deal.tasks.map((task) => (
                    <li
                      key={task.id}
                      className="flex flex-col gap-2 rounded-lg border p-3 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0">
                        <Link href={`/tasks/${task.id}/edit`} className="text-sm font-medium hover:underline">
                          {task.title}
                        </Link>
                        <p className="text-xs text-muted-foreground">
                          {enumLabel(messages, "taskType", task.type)} ·{" "}
                          {formatDate(task.dueAt, locale, true)} · {task.assignedTo.name}
                        </p>
                      </div>
                      <StatusBadge value={task.status} group="taskStatus" className="shrink-0" />
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("deals.financials")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-center justify-between gap-3">
                <span className="text-muted-foreground">{t("deals.value")}</span>
                <span className="font-semibold" dir="ltr">
                  {formatCurrency(deal.value, locale)}
                </span>
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="text-muted-foreground">{t("deals.commissionRate")}</span>
                <span className="font-medium" dir="ltr">
                  {deal.commissionRate}%
                </span>
              </div>
              <div className="flex items-center justify-between gap-3 border-t pt-3">
                <span className="text-muted-foreground">{t("deals.commissionAmount")}</span>
                <span className="font-semibold text-primary" dir="ltr">
                  {formatCurrency(deal.commissionAmount, locale)}
                </span>
              </div>
              <div className="space-y-1.5 border-t pt-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{t("deals.progress")}</span>
                  <span>{deal.probability}%</span>
                </div>
                <Progress value={deal.probability} />
              </div>
            </CardContent>
          </Card>

          <DealPayments dealId={deal.id} />

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("deals.customer")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <Link href={`/customers/${deal.customer.id}`} className="font-medium hover:underline">
                {deal.customer.fullName}
              </Link>
              <p className="text-xs text-muted-foreground">{deal.customer.code}</p>
              <StatusBadge value={deal.customer.status} />
              <div className="space-y-2 border-t pt-3 text-xs">
                <a
                  href={`tel:${deal.customer.phone}`}
                  className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
                  dir="ltr"
                >
                  <Phone className="size-3.5" />
                  {deal.customer.phone}
                </a>
                {deal.customer.email && (
                  <a
                    href={`mailto:${deal.customer.email}`}
                    className="flex items-center gap-2 break-all text-muted-foreground hover:text-foreground"
                  >
                    <Mail className="size-3.5 shrink-0" />
                    {deal.customer.email}
                  </a>
                )}
              </div>
            </CardContent>
          </Card>

          {deal.property && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{t("deals.property")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <Link href={`/properties/${deal.property.id}`} className="font-medium hover:underline">
                  {deal.property.title}
                </Link>
                <p className="text-xs text-muted-foreground">{deal.property.code}</p>
                <p className="text-xs text-muted-foreground">
                  {deal.property.location}, {deal.property.city}
                </p>
                <div className="flex items-center justify-between border-t pt-2">
                  <StatusBadge value={deal.property.status} group="propertyStatus" />
                  <span className="text-sm font-semibold" dir="ltr">
                    {formatCurrency(deal.property.price, locale)}
                  </span>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardContent className="flex items-center gap-3 py-4">
              <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Handshake className="size-4" />
              </span>
              <div className="text-sm">
                <p className="font-medium">{t("deals.stage")}</p>
                <StatusBadge value={deal.stage} group="dealStage" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <Card className="py-4">
      <CardContent className="flex items-center gap-3">
        <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="size-4" />
        </span>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="truncate text-sm font-semibold" dir="auto">
            {value}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function InfoRow({
  icon: Icon,
  label,
  children,
}: {
  icon: LucideIcon;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="flex items-center gap-2 text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </span>
      <span className="text-end font-medium">{children}</span>
    </div>
  );
}
