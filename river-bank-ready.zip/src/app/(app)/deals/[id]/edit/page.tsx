import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { dealAccessWhere } from "@/lib/access";
import { asRole, assignableAgentWhere, customerScope, type SessionUser } from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { DealForm } from "@/components/deals/deal-form";

export const dynamic = "force-dynamic";

export default async function EditDealPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };

  const deal = await prisma.deal.findFirst({
    where: dealAccessWhere(user, id),
    select: {
      id: true,
      title: true,
      customerId: true,
      propertyId: true,
      agentId: true,
      value: true,
      currency: true,
      commissionRate: true,
      probability: true,
      expectedCloseDate: true,
      stage: true,
      lostReason: true,
      notes: true,
    },
  });
  if (!deal) notFound();

  const [customers, properties, agents, { t }] = await Promise.all([
    prisma.customer.findMany({
      where: { ...customerScope(user), isDeleted: false },
      orderBy: { fullName: "asc" },
      take: 500,
      select: { id: true, code: true, fullName: true, phone: true, status: true, assignedAgentId: true },
    }),
    prisma.property.findMany({
      where: { isDeleted: false },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: { id: true, code: true, title: true, price: true, status: true },
    }),
    prisma.user.findMany({
      where: assignableAgentWhere(user),
      orderBy: [{ role: "asc" }, { name: "asc" }],
      select: { id: true, name: true, email: true, role: true },
    }),
    getI18n(),
  ]);

  return (
    <div>
      <PageHeader title={t("deals.edit")} description={`${deal.title}`} />
      <DealForm
        mode="edit"
        deal={deal}
        customers={customers}
        properties={properties}
        agents={agents}
        canAssignAgent={role !== "AGENT"}
      />
    </div>
  );
}
