import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, assignableAgentWhere, customerScope, type SessionUser } from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { DealForm } from "@/components/deals/deal-form";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function NewDealPage({ searchParams }: { searchParams: SearchParams }) {
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };
  const raw = await searchParams;
  const initialCustomerId = typeof raw.customerId === "string" ? raw.customerId : undefined;
const initialPropertyId = typeof raw.propertyId === "string" ? raw.propertyId : undefined;

  const [customers, properties, agents, { t }] = await Promise.all([
    prisma.customer.findMany({
      where: { ...customerScope(user), isDeleted: false },
      orderBy: { fullName: "asc" },
      take: 500,
      select: { id: true, code: true, fullName: true, phone: true, status: true, assignedAgentId: true },
    }),
    prisma.property.findMany({
      where: { isDeleted: false },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: { id: true, code: true, title: true, price: true, status: true },
    }),
    prisma.user.findMany({
      where: assignableAgentWhere(user),
      orderBy: [{ role: "asc" }, { name: "asc" }],
      select: { id: true, name: true, email: true, role: true },
    }),
    getI18n(),
  ]);

  return (
    <div>
      <PageHeader title={t("deals.new")} description={t("deals.subtitle")} />
      <DealForm
        mode="create"
        customers={customers}
        properties={properties}
        agents={agents}
        canAssignAgent={role !== "AGENT"}
        initialCustomerId={initialCustomerId}
        initialPropertyId={initialPropertyId}
      />
    </div>
  );
}
