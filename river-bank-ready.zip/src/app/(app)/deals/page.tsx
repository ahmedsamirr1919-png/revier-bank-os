import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, assignableAgentWhere, canDelete, type SessionUser } from "@/lib/rbac";
import { dealListQuery } from "@/lib/validation/deal";
import { dealListSelect, dealOrderBy, dealWhere } from "@/lib/queries/deals";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { DealActions } from "@/components/deals/deal-actions";
import { DealsView } from "@/components/deals/deals-view";
import type { AgentOption, DealFilters, DealListItem } from "@/components/deals/types";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function DealsPage({ searchParams }: { searchParams: SearchParams }) {
  const session = await auth();
  const raw = await searchParams;
  const params = Object.fromEntries(
    Object.entries(raw)
      .filter(([, value]) => typeof value === "string")
      .map(([key, value]) => [key, value as string]),
  );

  const parsed = dealListQuery.safeParse(params);
  const query = parsed.success ? parsed.data : dealListQuery.parse({});
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };
  const admin = canDelete(role);
  const trash = query.trash === "1" && admin;

  const where = dealWhere(user, query, trash);

  const [total, items, agents] = await Promise.all([
    prisma.deal.count({ where }),
    prisma.deal.findMany({
      where,
      orderBy: dealOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: dealListSelect,
    }),
    prisma.user.findMany({
      where: assignableAgentWhere(user),
      orderBy: [{ role: "asc" }, { name: "asc" }],
      select: { id: true, name: true, email: true, role: true },
    }),
  ]);

  const { t } = await getI18n();
  const filters: DealFilters = {
    q: query.q ?? "",
    stage: query.stage ?? "",
    agentId: query.agentId ?? "",
    sort: query.sort,
    trash: trash ? "1" : "0",
  };
  const pages = Math.max(1, Math.ceil(total / query.pageSize));

  return (
    <div>
      <PageHeader title={t("deals.title")} description={t("deals.subtitle")}>
        <DealActions canRestore={admin} trash={trash} />
      </PageHeader>

      <DealsView
        items={items as DealListItem[]}
        total={total}
        page={query.page}
        pageSize={query.pageSize}
        pages={pages}
        filters={filters}
        agents={agents as AgentOption[]}
        canRestore={admin}
      />
    </div>
  );
}
