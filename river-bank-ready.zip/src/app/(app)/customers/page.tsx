import { prisma } from "@/lib/prisma";
import { auth } from "@/auth";
import { asRole, canAssignLeads, canDelete, assignableAgentWhere, type SessionUser } from "@/lib/rbac";
import { customerListQuery } from "@/lib/validation/customer";
import { customerWhere, customerOrderBy, customerListSelect } from "@/lib/queries/customers";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { CustomerActions } from "@/components/customers/customer-actions";
import { CustomersView } from "@/components/customers/customers-view";
import type { CustomerListItem } from "@/components/customers/types";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function CustomersPage({ searchParams }: { searchParams: SearchParams }) {
  const session = await auth();
  const raw = await searchParams;
  const params = Object.fromEntries(
    Object.entries(raw)
      .filter(([, value]) => typeof value === "string")
      .map(([key, value]) => [key, value as string]),
  );

  const parsed = customerListQuery.safeParse(params);
  const query = parsed.success ? parsed.data : customerListQuery.parse({});

  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };

  const trash = query.trash === "1" && canDelete(role);
  const where = customerWhere(user, query);
  where.isDeleted = trash;

  const [total, items, agents] = await Promise.all([
    prisma.customer.count({ where }),
    prisma.customer.findMany({
      where,
      orderBy: customerOrderBy(query.sort),
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
      select: customerListSelect,
    }),
    prisma.user.findMany({
      where: assignableAgentWhere(user),
      orderBy: { name: "asc" },
      select: { id: true, name: true, email: true, role: true },
    }),
  ]);

  const { t } = await getI18n();
  const filters = {
    q: query.q ?? "",
    status: query.status ?? "",
    source: query.source ?? "",
    purpose: query.purpose ?? "",
    agentId: query.agentId ?? "",
    sort: query.sort,
    trash: trash ? "1" : "0",
  };
  const pages = Math.max(1, Math.ceil(total / query.pageSize));

  return (
    <div>
      <PageHeader title={t("customers.title")} description={t("customers.subtitle")}>
        <CustomerActions filters={filters} canDelete={canDelete(role)} trash={trash} />
      </PageHeader>

      <CustomersView
        items={items as CustomerListItem[]}
        agents={agents}
        total={total}
        page={query.page}
        pageSize={query.pageSize}
        pages={pages}
        filters={filters}
        canAssign={canAssignLeads(role)}
        canDelete={canDelete(role)}
        isAdmin={role === "ADMIN"}
      />
    </div>
  );
}
