import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, assignableAgentWhere, canAssignLeads, type SessionUser } from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { CustomerForm } from "@/components/customers/customer-form";

export const dynamic = "force-dynamic";

export default async function NewCustomerPage() {
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };
  const agents = await prisma.user.findMany({
    where: assignableAgentWhere(user),
    orderBy: { name: "asc" },
    select: { id: true, name: true, email: true, role: true },
  });
  const { t } = await getI18n();

  return (
    <div>
      <PageHeader title={t("customers.new")} description={t("customers.subtitle")} />
      <CustomerForm mode="create" agents={agents} canAssign={canAssignLeads(role)} />
    </div>
  );
}
