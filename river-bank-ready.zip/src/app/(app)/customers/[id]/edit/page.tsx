import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, assignableAgentWhere, canAssignLeads, type SessionUser } from "@/lib/rbac";
import { customerAccessWhere } from "@/lib/access";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { CustomerForm } from "@/components/customers/customer-form";

export const dynamic = "force-dynamic";

export default async function EditCustomerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };

  const customer = await prisma.customer.findFirst({
    where: customerAccessWhere(user, id),
    select: {
      id: true,
      fullName: true,
      phone: true,
      email: true,
      whatsapp: true,
      source: true,
      status: true,
      budgetMin: true,
      budgetMax: true,
      preferredArea: true,
      propertyType: true,
      assignedAgentId: true,
      notes: true,
    },
  });
  if (!customer) notFound();

  const agents = await prisma.user.findMany({
    where: assignableAgentWhere(user),
    orderBy: { name: "asc" },
    select: { id: true, name: true, email: true, role: true },
  });
  const { t } = await getI18n();

  return (
    <div>
      <PageHeader title={t("customers.edit")} description={customer.fullName} />
      <CustomerForm
        mode="edit"
        customer={customer}
        agents={agents}
        canAssign={canAssignLeads(role)}
      />
    </div>
  );
}
