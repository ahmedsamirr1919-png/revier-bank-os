import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  Building2,
  CalendarDays,
  CircleDollarSign,
  Gauge,
  Handshake,
  Mail,
  MapPin,
  MessageSquareHeart,
  Phone,
  TrendingUp,
  User as UserIcon,
  Wallet,
} from "lucide-react";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { customerAccessWhere } from "@/lib/access";
import {
  asRole,
  assignableAgentWhere,
  canAssignLeads,
  canDelete,
  type SessionUser,
} from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { enumLabel } from "@/lib/i18n";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { Stars } from "@/components/shared/stars";
import { EmptyState } from "@/components/shared/empty-state";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CustomerDetailActions } from "@/components/customers/customer-detail-actions";
import { CustomerTimeline } from "@/components/customers/customer-timeline";
import { formatCurrency, formatDate, initials } from "@/lib/utils";
import { PIPELINE_ORDER, LEAD_SCORE_STYLES } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };

  const customer = await prisma.customer.findFirst({
    where: customerAccessWhere(user, id),
    include: {
      assignedAgent: { select: { id: true, name: true, email: true } },
      createdBy: { select: { id: true, name: true, email: true } },
      activities: {
        orderBy: { occurredAt: "desc" },
        take: 100,
        include: { user: { select: { id: true, name: true } } },
      },
      deals: {
        where: { isDeleted: false },
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          code: true,
          title: true,
          stage: true,
          value: true,
          currency: true,
          expectedCloseDate: true,
        },
      },
      interests: {
        orderBy: { createdAt: "desc" },
        include: {
          property: {
            select: {
              id: true,
              code: true,
              title: true,
              price: true,
              status: true,
              location: true,
              type: true,
            },
          },
        },
      },
      feedback: {
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          rating: true,
          comment: true,
          status: true,
          source: true,
          createdAt: true,
          isNegative: true,
        },
      },
    },
  });

  if (!customer) notFound();

  const [agents, { t, locale, messages }] = await Promise.all([
    prisma.user.findMany({
      where: assignableAgentWhere(user),
      orderBy: { name: "asc" },
      select: { id: true, name: true, email: true, role: true },
    }),
    getI18n(),
  ]);

  const budget =
    customer.budgetMin && customer.budgetMax
      ? `${formatCurrency(customer.budgetMin, locale, true)} – ${formatCurrency(customer.budgetMax, locale, true)}`
      : customer.budgetMax
        ? formatCurrency(customer.budgetMax, locale, true)
        : customer.budgetMin
          ? formatCurrency(customer.budgetMin, locale, true)
          : "—";

  const averageRating = customer.feedback.length
    ? customer.feedback.reduce((sum, item) => sum + item.rating, 0) / customer.feedback.length
    : 0;

  const stageIndex = PIPELINE_ORDER.indexOf(customer.status as (typeof PIPELINE_ORDER)[number]);
  const isLost = customer.status === "CLOSED_LOST";

  return (
    <div className="space-y-5">
      <PageHeader
        title={customer.fullName}
        description={`${customer.code} · ${t("customers.created")} ${formatDate(customer.createdAt, locale)}`}
      >
        <CustomerDetailActions
          customer={{
            id: customer.id,
            fullName: customer.fullName,
            phone: customer.phone,
            whatsapp: customer.whatsapp,
            assignedAgentId: customer.assignedAgentId,
          }}
          agents={agents}
          canAssign={canAssignLeads(role) && !customer.isDeleted}
          canDelete={canDelete(role)}
          isDeleted={customer.isDeleted}
        />
      </PageHeader>

      <div className="flex items-center gap-2 text-sm">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/customers">
            <ArrowLeft className="rtl:rotate-180" />
            {t("customers.title")}
          </Link>
        </Button>
        <StatusBadge value={customer.status} />
        <span className="text-muted-foreground">{enumLabel(messages, "source", customer.source)}</span>
        {customer.isDeleted && (
          <span className="rounded bg-destructive/10 px-2 py-0.5 text-xs font-medium text-destructive">
            {t("customers.trash")}
          </span>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <SummaryCard icon={Wallet} label={t("customers.budget")} value={budget} />
        <SummaryCard
          icon={Handshake}
          label={t("customers.deals")}
          value={String(customer.deals.length)}
        />
        <SummaryCard
          icon={Building2}
          label={t("customers.linkedProperties")}
          value={String(customer.interests.length)}
        />
        <SummaryCard
          icon={MessageSquareHeart}
          label={t("feedback.average")}
          value={
            customer.feedback.length ? (
              <span className="flex items-center gap-2">
                {averageRating.toFixed(1)}
                <Stars value={averageRating} size="sm" />
              </span>
            ) : (
              "—"
            )
          }
        />
      </div>

      <Card>
        <CardContent className="py-0">
          <div className="flex min-w-max items-center gap-1 overflow-x-auto py-4">
            {PIPELINE_ORDER.map((stage, index) => {
              const done = !isLost && index <= stageIndex;
              const isCurrent = index === stageIndex;
              return (
                <div key={stage} className="flex items-center">
                  <div className="flex flex-col items-center gap-1.5">
                    <span
                      className={[
                        "flex size-7 items-center justify-center rounded-full border text-xs font-semibold",
                        isCurrent
                          ? isLost
                            ? "border-destructive bg-destructive text-white"
                            : "border-primary bg-primary text-primary-foreground"
                          : done
                            ? "border-primary/40 bg-primary/10 text-primary"
                            : "border-muted bg-muted text-muted-foreground",
                      ].join(" ")}
                    >
                      {index + 1}
                    </span>
                    <span
                      className={[
                        "whitespace-nowrap text-[11px]",
                        isCurrent ? "font-semibold" : "text-muted-foreground",
                      ].join(" ")}
                    >
                      {enumLabel(messages, "customerStatus", stage)}
                    </span>
                  </div>
                  {index < PIPELINE_ORDER.length - 1 && (
                    <span
                      className={[
                        "mx-1.5 mb-5 h-px w-8 sm:w-14",
                        done && index < stageIndex ? "bg-primary/50" : "bg-border",
                      ].join(" ")}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardContent className="pt-1">
              <Tabs defaultValue="timeline">
                <TabsList className="w-full justify-start overflow-x-auto sm:w-auto">
                  <TabsTrigger value="timeline">{t("customers.timeline")}</TabsTrigger>
                  <TabsTrigger value="deals">{t("customers.deals")}</TabsTrigger>
                  <TabsTrigger value="properties">{t("customers.linkedProperties")}</TabsTrigger>
                  <TabsTrigger value="feedback">{t("customers.feedback")}</TabsTrigger>
                </TabsList>

                <TabsContent value="timeline">
                  <CustomerTimeline
                    customerId={customer.id}
                    items={customer.activities.map((activity) => ({
                      id: activity.id,
                      type: activity.type,
                      title: activity.title,
                      body: activity.body,
                      outcome: activity.outcome,
                      occurredAt: activity.occurredAt,
                      user: activity.user,
                    }))}
                  />
                </TabsContent>

                <TabsContent value="deals">
                  {customer.deals.length === 0 ? (
                    <EmptyState icon={Handshake} title={t("customers.noDeals")} />
                  ) : (
                    <div className="rounded-lg border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>{t("deals.titleField")}</TableHead>
                            <TableHead>{t("deals.stage")}</TableHead>
                            <TableHead>{t("deals.value")}</TableHead>
                            <TableHead className="hidden sm:table-cell">{t("deals.expectedClose")}</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {customer.deals.map((deal) => (
                            <TableRow key={deal.id}>
                              <TableCell>
                                <Link href={`/deals/${deal.id}`} className="font-medium hover:underline">
                                  {deal.title}
                                </Link>
                                <span className="block text-xs text-muted-foreground">{deal.code}</span>
                              </TableCell>
                              <TableCell>
                                <StatusBadge value={deal.stage} group="dealStage" />
                              </TableCell>
                              <TableCell dir="ltr">{formatCurrency(deal.value, locale)}</TableCell>
                              <TableCell className="hidden sm:table-cell text-muted-foreground">
                                {formatDate(deal.expectedCloseDate, locale)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="properties">
                  {customer.interests.length === 0 ? (
                    <EmptyState icon={Building2} title={t("customers.noProperties")} />
                  ) : (
                    <div className="grid gap-3 sm:grid-cols-2">
                      {customer.interests.map((interest) => (
                        <Link
                          key={interest.id}
                          href={`/properties/${interest.property.id}`}
                          className="rounded-lg border p-4 transition-colors hover:bg-muted/40"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <p className="font-medium">{interest.property.title}</p>
                            <StatusBadge value={interest.property.status} group="propertyStatus" />
                          </div>
                          <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                            <MapPin className="size-3" />
                            {interest.property.location}
                          </p>
                          <div className="mt-3 flex items-center justify-between text-sm">
                            <span dir="ltr">{formatCurrency(interest.property.price, locale, true)}</span>
                            <span className="text-xs text-muted-foreground">
                              {enumLabel(messages, "propertyType", interest.property.type)}
                            </span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="feedback">
                  {customer.feedback.length === 0 ? (
                    <EmptyState icon={MessageSquareHeart} title={t("customers.noFeedback")} />
                  ) : (
                    <ul className="space-y-3">
                      {customer.feedback.map((item) => (
                        <li key={item.id} className="rounded-lg border p-4">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <Stars value={item.rating} size="sm" />
                            <div className="flex items-center gap-2">
                              <StatusBadge value={item.status} group="feedbackStatus" />
                              <span className="text-xs text-muted-foreground">
                                {formatDate(item.createdAt, locale)}
                              </span>
                            </div>
                          </div>
                          {item.comment && <p className="mt-2 text-sm text-muted-foreground">{item.comment}</p>}
                        </li>
                      ))}
                    </ul>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("customers.info")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <InfoRow icon={Phone} label={t("customers.phone")}>
                <a href={`tel:${customer.phone}`} dir="ltr" className="hover:underline">
                  {customer.phone}
                </a>
              </InfoRow>
              <InfoRow icon={Mail} label={t("customers.email")}>
                {customer.email ? (
                  <a href={`mailto:${customer.email}`} dir="ltr" className="hover:underline">
                    {customer.email}
                  </a>
                ) : (
                  "—"
                )}
              </InfoRow>
              <InfoRow icon={MapPin} label={t("customers.preferredArea")}>
                {customer.preferredArea ?? "—"}
              </InfoRow>
              <InfoRow icon={Building2} label={t("customers.propertyType")}>
                {customer.propertyType
                  ? enumLabel(messages, "propertyType", customer.propertyType)
                  : "—"}
              </InfoRow>
              <InfoRow icon={Building2} label={t("customers.purpose")}>
                {customer.purpose ? enumLabel(messages, "propertyPurpose", customer.purpose) : "—"}
              </InfoRow>
              <InfoRow icon={Wallet} label={t("customers.budget")}>
                <span dir="ltr">{budget}</span>
              </InfoRow>
              <InfoRow icon={UserIcon} label={t("customers.agent")}>
                {customer.assignedAgent ? (
                  customer.assignedAgent.name
                ) : (
                  <span className="text-muted-foreground">{t("common.unassigned")}</span>
                )}
              </InfoRow>
              <InfoRow icon={TrendingUp} label={t("leads.score")}>
                {customer.scoreStatus ? (
                  <span
                    className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${LEAD_SCORE_STYLES[customer.scoreStatus] ?? LEAD_SCORE_STYLES.COLD}`}
                  >
                    {customer.score} · {enumLabel(messages, "leadScore", customer.scoreStatus)}
                  </span>
                ) : (
                  "—"
                )}
              </InfoRow>
              <InfoRow icon={CalendarDays} label={t("customers.created")}>
                {formatDate(customer.createdAt, locale)}
              </InfoRow>
              {customer.createdBy && (
                <InfoRow icon={UserIcon} label={t("customers.createdBy")}>
                  {customer.createdBy.name}
                </InfoRow>
              )}
            </CardContent>
          </Card>

          {customer.notes && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{t("customers.notes")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-line text-sm text-muted-foreground">{customer.notes}</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function SummaryCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Wallet;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <Card className="py-4">
      <CardContent className="flex items-center gap-3">
        <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="size-4" />
        </span>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="truncate text-sm font-semibold" dir="auto">
            {value}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function InfoRow({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof Phone;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="flex items-center gap-2 text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </span>
      <span className="text-end font-medium">{children}</span>
    </div>
  );
}
