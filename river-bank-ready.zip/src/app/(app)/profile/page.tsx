import { ProfileView } from "@/components/profile/profile-view";

export const metadata = { title: "My profile" };

export default function ProfilePage() {
  return <ProfileView />;
}
