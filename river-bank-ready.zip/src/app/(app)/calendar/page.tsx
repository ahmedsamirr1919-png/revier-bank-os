import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { asRole, taskScope, type SessionUser } from "@/lib/rbac";
import { getI18n } from "@/lib/i18n/server";
import { PageHeader } from "@/components/shared/page-header";
import { CalendarView } from "@/components/calendar/calendar-view";
import type { TaskListItem } from "@/components/tasks/types";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function monthRange(value: unknown) {
  const fallback = new Date();
  const raw = typeof value === "string" ? value : "";
  const match = /^(\d{4})-(\d{2})$/.exec(raw);
  const base = match
    ? new Date(Number(match[1]), Number(match[2]) - 1, 1)
    : new Date(fallback.getFullYear(), fallback.getMonth(), 1);
  if (Number.isNaN(base.getTime())) return monthRange(undefined);

  // The grid runs Monday → Sunday and may spill into adjacent months.
  const start = new Date(base);
  const offset = (start.getDay() + 6) % 7;
  start.setDate(start.getDate() - offset);
  start.setHours(0, 0, 0, 0);

  const end = new Date(base.getFullYear(), base.getMonth() + 1, 0);
  end.setDate(end.getDate() + (7 - ((end.getDay() + 6) % 7) - 1));
  end.setHours(23, 59, 59, 999);

  const month = `${base.getFullYear()}-${String(base.getMonth() + 1).padStart(2, "0")}`;
  return { base, start, end, month };
}

export default async function CalendarPage({ searchParams }: { searchParams: SearchParams }) {
  const session = await auth();
  const role = asRole(session?.user?.role);
  const user: SessionUser = {
    id: session?.user?.id ?? "",
    role,
    managerId: session?.user?.managerId ?? null,
  };
  const raw = await searchParams;
  const { start, end, month } = monthRange(raw.month);

  const [tasks, { t }] = await Promise.all([
    prisma.task.findMany({
      where: { ...taskScope(user), dueAt: { gte: start, lte: end } },
      orderBy: [{ dueAt: "asc" }],
      select: {
        id: true,
        title: true,
        description: true,
        type: true,
        priority: true,
        status: true,
        dueAt: true,
        completedAt: true,
        createdAt: true,
        customerId: true,
        dealId: true,
        propertyId: true,
        assignedToId: true,
        customer: { select: { id: true, code: true, fullName: true } },
        deal: { select: { id: true, code: true, title: true } },
        property: { select: { id: true, code: true, title: true } },
        assignedTo: { select: { id: true, name: true } },
      },
    }),
    getI18n(),
  ]);

  return (
    <div>
      <PageHeader title={t("calendar.title")} description={t("calendar.subtitle")} />
      <CalendarView month={month} tasks={tasks as TaskListItem[]} />
    </div>
  );
}
