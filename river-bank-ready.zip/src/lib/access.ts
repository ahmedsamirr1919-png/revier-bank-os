import "server-only";
import type { Prisma } from "@prisma/client";
import { ApiError } from "./api";
import {
  assignableAgentWhere,
  customerScope,
  dealScope,
  feedbackScope,
  taskScope,
  type SessionUser,
} from "./rbac";

/** Customers a user may read/write, including soft-deleted records for admins. */
export function customerAccessWhere(user: SessionUser, id: string): Prisma.CustomerWhereInput {
  return {
    id,
    ...(user.role === "ADMIN" ? {} : { isDeleted: false }),
    ...customerScope(user),
  };
}

/** Deals a user may read/write, including soft-deleted records for admins. */
export function dealAccessWhere(
  user: SessionUser,
  id: string,
  options: { allowDeleted?: boolean } = {},
): Prisma.DealWhereInput {
  return {
    id,
    ...(options.allowDeleted || user.role === "ADMIN" ? {} : { isDeleted: false }),
    ...dealScope(user),
  };
}

/** Tasks a user may read/write within their team scope. */
export function taskAccessWhere(user: SessionUser, id: string): Prisma.TaskWhereInput {
  return { id, ...taskScope(user) };
}

/** Feedback a user may read/write within their team scope. */
export function feedbackAccessWhere(user: SessionUser, id: string): Prisma.FeedbackWhereInput {
  return { id, ...feedbackScope(user) };
}

export async function assertCustomerAccess(
  user: SessionUser,
  id: string,
  options: { allowDeleted?: boolean } = {},
) {
  const { prisma } = await import("./prisma");
  const customer = await prisma.customer.findFirst({
    where: {
      id,
      ...(options.allowDeleted || user.role === "ADMIN" ? {} : { isDeleted: false }),
      ...customerScope(user),
    },
    select: { id: true, assignedAgentId: true, status: true, fullName: true },
  });
  if (!customer) throw new ApiError("not_found", 404, "Customer not found");
  return customer;
}

/**
 * Verifies that a user can assign work to the given agent. Admins may assign to
 * any active agent or manager; managers may assign to themselves and direct
 * reports. Agent ids outside that scope are rejected.
 */
export async function assertAssignableAgent(user: SessionUser, agentId: string) {
  const { prisma } = await import("./prisma");
  const agent = await prisma.user.findFirst({
    where: { id: agentId, ...assignableAgentWhere(user) },
    select: { id: true, name: true, email: true, role: true },
  });
  if (!agent) throw new ApiError("invalid_agent", 422, "You cannot assign records to this user");
  return agent;
}

/** Agents may only ever own records assigned to themselves. */
export function resolveAssignedAgentId(user: SessionUser, requested: string | null | undefined) {
  if (user.role === "AGENT") return user.id;
  return requested ?? null;
}

/** Resolve the assignee for a task or deal: agents own their records, others default to self. */
export function resolveAssigneeId(user: SessionUser, requested: string | null | undefined) {
  if (user.role === "AGENT") return user.id;
  return requested || user.id;
}
