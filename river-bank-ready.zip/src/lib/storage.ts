import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const bucket = process.env.SUPABASE_STORAGE_BUCKET ?? "river-bank";

export function getStorageClient() {
  if (!supabaseUrl || !supabaseServiceKey) {
    throw new Error("Supabase storage is not configured");
  }
  return createClient(supabaseUrl, supabaseServiceKey, {
    auth: { persistSession: false },
  });
}

export async function uploadFile(path: string, file: Buffer | Blob, contentType?: string) {
  const client = getStorageClient();
  const { data, error } = await client.storage.from(bucket).upload(path, file, {
    contentType,
    upsert: true,
  });
  if (error) throw error;
  return data;
}

export function getPublicUrl(path: string) {
  const client = getStorageClient();
  const { data } = client.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}

export async function deleteFile(path: string) {
  const client = getStorageClient();
  const { error } = await client.storage.from(bucket).remove([path]);
  if (error) throw error;
}
