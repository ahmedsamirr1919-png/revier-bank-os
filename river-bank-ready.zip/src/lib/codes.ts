import "server-only";
import { prisma } from "./prisma";

export type CodeEntity = "customer" | "property" | "deal";

const PREFIXES: Record<CodeEntity, string> = {
  customer: "RB-C",
  property: "RB-P",
  deal: "RB-D",
};

function toNumber(code: string | null | undefined, prefix: string) {
  if (!code?.startsWith(`${prefix}-`)) return 0;
  const parsed = Number.parseInt(code.slice(prefix.length + 1), 10);
  return Number.isFinite(parsed) ? parsed : 0;
}

/**
 * Generates the next sequential human-readable code (RB-C-0001).
 * SQLite has no sequences, so we read the highest existing code. Retries in the
 * caller handle the rare race between two concurrent creates.
 */
export async function nextCode(entity: CodeEntity): Promise<string> {
  const prefix = PREFIXES[entity];

  const latest =
    entity === "customer"
      ? await prisma.customer.findFirst({
          where: { code: { startsWith: `${prefix}-` } },
          orderBy: { code: "desc" },
          select: { code: true },
        })
      : entity === "property"
        ? await prisma.property.findFirst({
            where: { code: { startsWith: `${prefix}-` } },
            orderBy: { code: "desc" },
            select: { code: true },
          })
        : await prisma.deal.findFirst({
            where: { code: { startsWith: `${prefix}-` } },
            orderBy: { code: "desc" },
            select: { code: true },
          });

  return `${prefix}-${String(toNumber(latest?.code, prefix) + 1).padStart(4, "0")}`;
}

export async function createWithCode<T extends { code: string }>(
  entity: CodeEntity,
  create: (code: string) => Promise<T>,
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const code = await nextCode(entity);
    try {
      return await create(code);
    } catch (error) {
      lastError = error;
      const code = (error as { code?: string }).code;
      if (code !== "P2002") throw error;
    }
  }
  throw lastError;
}
