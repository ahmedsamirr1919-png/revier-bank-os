// Transliteration + phonetic helpers for Arabic/Latin names.

const ARABIC_TO_LATIN: Record<string, string> = {
  "ا": "a", "أ": "a", "إ": "i", "آ": "a", "ب": "b", "ت": "t", "ث": "th",
  "ج": "j", "ح": "h", "خ": "kh", "د": "d", "ذ": "dh", "ر": "r", "ز": "z",
  "س": "s", "ش": "sh", "ص": "s", "ض": "d", "ط": "t", "ظ": "z", "ع": "a",
  "غ": "gh", "ف": "f", "ق": "q", "ك": "k", "ل": "l", "م": "m", "ن": "n",
  "ه": "h", "و": "w", "ي": "y", "ى": "y", "ة": "h", "ئ": "y", "ؤ": "w",
  "ء": "", "ـ": "",
};

const NAME_VARIANTS: Record<string, string[]> = {
  mohamed: ["mohamed", "muhammad", "mohammed", "mohammad", "mohamad", "mohamed", "muhammed"],
  ahmed: ["ahmed", "ahmad", "ahmet"],
  mahmoud: ["mahmoud", "mahmud", "mahmood"],
  abdullah: ["abdullah", "abdallah", "abdulla", "abdellah"],
  fatima: ["fatima", "fatimah", "fatma"],
  aisha: ["aisha", "aishah", "aysha", "aishe"],
  hassan: ["hassan", "hasan", "hussein", "husain"],
  ali: ["ali", "aly"],
  omar: ["omar", "umar"],
  khalid: ["khalid", "khaled"],
  yousef: ["yousef", "yusuf", "yousef", "youssef", "yusif"],
  ibrahim: ["ibrahim", "abraham", "ebraheem"],
  ismail: ["ismail", "ismael", "ismail"],
  salim: ["salim", "saleem", "salem"],
  nasser: ["nasser", "nasir", "nacer"],
  saeed: ["saeed", "saeid", "saeed"],
  abdulrahman: ["abdulrahman", "abdulrahman", "abd al rahman", "abdurrahman"],
};

export function transliterateArabicToLatin(input: string): string {
  if (!input) return "";
  return input
    .split("")
    .map((ch) => (ch in ARABIC_TO_LATIN ? ARABIC_TO_LATIN[ch] : ch))
    .join("");
}

import { normalizeArabic } from "./normalize";

export function normalizeNameAr(input: string): string {
  return normalizeArabic(input);
}

export function normalizeNameEn(input: string): string {
  return (input ?? "").toLowerCase().trim().replace(/\s+/g, " ");
}

export function canonicalNameVariant(input: string): string {
  const key = normalizeNameEn(input);
  for (const [canonical, variants] of Object.entries(NAME_VARIANTS)) {
    if (variants.includes(key)) return canonical;
  }
  return key;
}

export function nameVariants(input: string): string[] {
  const key = canonicalNameVariant(input);
  return NAME_VARIANTS[key] ?? [key];
}

export function phoneticKey(input: string): string {
  let text = normalizeNameEn(input);
  // Transliterate if Arabic
  if (/[؀-ۿ]/.test(text)) {
    text = normalizeNameEn(transliterateArabicToLatin(text));
  }
  // Remove vowels
  text = text.replace(/[aeiou]/g, "");
  // Collapse similar consonants
  text = text
    .replace(/ph/g, "f")
    .replace(/ck/g, "k")
    .replace(/q/g, "k")
    .replace(/w/g, "v")
    .replace(/z/g, "s");
  // Remove repeated chars
  text = text.replace(/(.)\1+/g, "$1");
  return text;
}

export function crossScriptMatch(a: string, b: string): boolean {
  if (!a || !b) return false;
  const aPh = phoneticKey(a);
  const bPh = phoneticKey(b);
  if (aPh && aPh === bPh) return true;
  const aCanon = canonicalNameVariant(a);
  const bCanon = canonicalNameVariant(b);
  if (aCanon && aCanon === bCanon) return true;
  // Transliterated Arabic
  const aLat = /[؀-ۿ]/.test(a) ? normalizeNameEn(transliterateArabicToLatin(a)) : normalizeNameEn(a);
  const bLat = /[؀-ۿ]/.test(b) ? normalizeNameEn(transliterateArabicToLatin(b)) : normalizeNameEn(b);
  if (aLat === bLat) return true;
  return false;
}
