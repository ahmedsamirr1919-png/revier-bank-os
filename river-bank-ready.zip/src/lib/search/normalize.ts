export function normalizeArabic(input: string): string {
  if (!input) return "";
  let text = input;
  // Remove tashkeel (diacritics)
  text = text.replace(/[\u064B-\u065F\u0670]/g, "");
  // Remove tatweel
  text = text.replace(/\u0640/g, "");
  // Normalize alef variants
  text = text.replace(/[\u0622\u0623\u0625]/g, "\u0627");
  // Normalize ya / alef maqsura
  text = text.replace(/\u0649/g, "\u064A");
  // Normalize ta marbouta / ha
  text = text.replace(/\u0629/g, "\u0647");
  // Convert Arabic-Indic and Persian digits to Latin
  const arabicDigits = "٠١٢٣٤٥٦٧٨٩";
  const persianDigits = "۰۱۲۳۴۵۶۷۸۹";
  text = text.replace(/[٠-٩]/g, (d) => String(arabicDigits.indexOf(d)));
  text = text.replace(/[۰-۹]/g, (d) => String(persianDigits.indexOf(d)));
  return text.trim();
}

export function normalizeEnglish(input: string): string {
  return (input ?? "").toLowerCase().trim().replace(/\s+/g, " ");
}

export function normalizeText(input: string): string {
  const arabic = normalizeArabic(input);
  return normalizeEnglish(arabic).replace(/\s+/g, " ");
}

export function normalizePhone(input: string): string {
  if (!input) return "";
  // Strip everything except digits
  let digits = input.replace(/\D/g, "");
  // Remove common country-code prefixes
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.startsWith("971")) digits = digits.slice(3); // UAE
  if (digits.startsWith("20")) digits = digits.slice(2); // Egypt
  if (digits.startsWith("966")) digits = digits.slice(3); // KSA
  // Remove leading zero
  if (digits.startsWith("0")) digits = digits.slice(1);
  return digits;
}

export function buildSearchBody(parts: Array<string | null | undefined>): string {
  return parts
    .filter(Boolean)
    .map((part) => normalizeText(String(part)))
    .join(" ");
}
