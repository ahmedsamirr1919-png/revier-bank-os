import "server-only";
import { prisma } from "./prisma";
import { ApiError } from "./api";
import { assertAssignableAgent, assertCustomerAccess, dealAccessWhere, resolveAssigneeId } from "./access";
import type { SessionUser } from "./rbac";

type TaskLinks = {
  customerId?: string | null;
  dealId?: string | null;
  propertyId?: string | null;
  assignedToId?: string | null;
};

/** Validate linked records and resolve/verify the task assignee. */
export async function validateTaskLinks(user: SessionUser, input: TaskLinks) {
  if (input.customerId) await assertCustomerAccess(user, input.customerId);
  if (input.dealId) {
    const deal = await prisma.deal.findFirst({
      where: { ...dealAccessWhere(user, input.dealId), isDeleted: false },
      select: { id: true },
    });
    if (!deal) throw new ApiError("invalid_deal", 422, "Deal not found");
  }
  if (input.propertyId) {
    const property = await prisma.property.findFirst({
      where: { id: input.propertyId, isDeleted: false },
      select: { id: true },
    });
    if (!property) throw new ApiError("invalid_property", 422, "Property not found");
  }
  return assertAssignableAgent(user, resolveAssigneeId(user, input.assignedToId));
}
