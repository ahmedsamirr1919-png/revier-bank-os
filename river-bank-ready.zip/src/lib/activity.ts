import "server-only";
import { headers } from "next/headers";
import { prisma } from "./prisma";

export type ActivityAction =
  | "CREATE"
  | "UPDATE"
  | "DELETE"
  | "RESTORE"
  | "LOGIN"
  | "LOGOUT"
  | "LOGIN_FAILED"
  | "ASSIGN"
  | "STATUS_CHANGE"
  | "EXPORT"
  | "IMPORT"
  | "REPLY"
  | "RESOLVE"
  | "PASSWORD_CHANGE";

type LogInput = {
  userId?: string | null;
  userEmail?: string | null;
  action: ActivityAction;
  entityType: string;
  entityId?: string | null;
  description: string;
  metadata?: Record<string, unknown> | null;
  ip?: string | null;
  userAgent?: string | null;
};

/**
 * Writes to the append-only audit trail. Never throws: an audit failure must
 * never roll back the business operation that triggered it.
 */
export async function logActivity(input: LogInput): Promise<void> {
  try {
    let ip = input.ip ?? null;
    let userAgent = input.userAgent ?? null;
    if (!ip || !userAgent) {
      try {
        const h = await headers();
        ip ??= h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? h.get("x-real-ip") ?? null;
        userAgent ??= h.get("user-agent") ?? null;
      } catch {
        /* not in a request scope */
      }
    }

    await prisma.activityLog.create({
      data: {
        userId: input.userId ?? null,
        userEmail: input.userEmail ?? null,
        action: input.action,
        entityType: input.entityType,
        entityId: input.entityId ?? null,
        description: input.description,
        metadata: input.metadata ? JSON.stringify(input.metadata) : null,
        ip,
        userAgent,
      },
    });
  } catch (error) {
    console.error("[activity-log] failed", error);
  }
}

export async function notify(input: {
  userId: string;
  type: string;
  title: string;
  body?: string | null;
  link?: string | null;
}) {
  try {
    await prisma.notification.create({
      data: {
        userId: input.userId,
        type: input.type,
        title: input.title,
        body: input.body ?? null,
        link: input.link ?? null,
      },
    });
  } catch (error) {
    console.error("[notify] failed", error);
  }
}
