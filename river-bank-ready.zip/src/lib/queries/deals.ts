import type { Prisma } from "@prisma/client";
import type { z } from "zod";
import { dealScope, type SessionUser } from "@/lib/rbac";
import type { dealListQuery } from "@/lib/validation/deal";

type DealFilters = z.infer<typeof dealListQuery>;

export const TERMINAL_DEAL_STAGES = ["CLOSED_WON", "CLOSED_LOST"];

export function commissionFor(value: number, rate: number) {
  return Math.round((value * rate) / 100);
}

export function dealWhere(
  user: SessionUser,
  filters: Partial<DealFilters>,
  trash = false,
): Prisma.DealWhereInput {
  const where: Prisma.DealWhereInput = {
    isDeleted: trash,
    ...dealScope(user),
  };

  if (filters.q) {
    where.AND = [
      {
        OR: [
          { title: { contains: filters.q } },
          { code: { contains: filters.q } },
          { customer: { is: { fullName: { contains: filters.q } } } },
        ],
      },
    ];
  }
  if (filters.stage) where.stage = filters.stage;
  if (filters.agentId) where.agentId = filters.agentId;
  if (filters.customerId) where.customerId = filters.customerId;
  if (filters.propertyId) where.propertyId = filters.propertyId;
  return where;
}

export function dealOrderBy(sort: DealFilters["sort"]): Prisma.DealOrderByWithRelationInput {
  switch (sort) {
    case "oldest":
      return { createdAt: "asc" };
    case "value_asc":
      return { value: "asc" };
    case "value_desc":
      return { value: "desc" };
    case "expected":
      return { expectedCloseDate: "asc" };
    default:
      return { createdAt: "desc" };
  }
}

export const dealListSelect = {
  id: true,
  code: true,
  title: true,
  value: true,
  currency: true,
  stage: true,
  probability: true,
  expectedCloseDate: true,
  closedAt: true,
  isDeleted: true,
  createdAt: true,
  customer: { select: { id: true, code: true, fullName: true, phone: true } },
  property: { select: { id: true, code: true, title: true } },
  agent: { select: { id: true, name: true } },
  _count: { select: { tasks: true, stageHistory: true } },
} satisfies Prisma.DealSelect;
