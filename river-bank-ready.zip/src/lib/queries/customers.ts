import type { Prisma } from "@prisma/client";
import type { z } from "zod";
import type { customerListQuery } from "@/lib/validation/customer";
import { customerScope, type SessionUser } from "@/lib/rbac";

type CustomerFilters = z.infer<typeof customerListQuery>;

export function customerWhere(user: SessionUser, filters: Partial<CustomerFilters>): Prisma.CustomerWhereInput {
  const where: Prisma.CustomerWhereInput = { ...customerScope(user), isDeleted: false };

  if (filters.q) {
    where.AND = [
      {
        OR: [
          { fullName: { contains: filters.q } },
          { phone: { contains: filters.q } },
          { email: { contains: filters.q } },
          { code: { contains: filters.q } },
        ],
      },
    ];
  }
  if (filters.status) where.status = filters.status;
  if (filters.source) where.source = filters.source;
  if (filters.propertyType) where.propertyType = filters.propertyType;
  if (filters.purpose) where.purpose = filters.purpose;
  if (filters.agentId === "unassigned") where.assignedAgentId = null;
  else if (filters.agentId) where.assignedAgentId = filters.agentId;

  if (filters.from || filters.to) {
    const createdAt: Prisma.DateTimeFilter = {};
    if (filters.from) createdAt.gte = new Date(filters.from);
    if (filters.to) {
      const to = new Date(filters.to);
      to.setHours(23, 59, 59, 999);
      createdAt.lte = to;
    }
    where.createdAt = createdAt;
  }

  return where;
}

export function customerOrderBy(sort: CustomerFilters["sort"]): Prisma.CustomerOrderByWithRelationInput {
  switch (sort) {
    case "oldest":
      return { createdAt: "asc" };
    case "name":
      return { fullName: "asc" };
    case "budget":
      return { budgetMax: "desc" };
    default:
      return { createdAt: "desc" };
  }
}

export const customerListSelect = {
  id: true,
  code: true,
  fullName: true,
  phone: true,
  email: true,
  whatsapp: true,
  source: true,
  status: true,
  budgetMin: true,
  budgetMax: true,
  currency: true,
  preferredArea: true,
  propertyType: true,
  purpose: true,
  assignedAgentId: true,
  isDeleted: true,
  score: true,
  scoreStatus: true,
  createdAt: true,
  assignedAgent: { select: { id: true, name: true, email: true } },
  _count: { select: { deals: true, activities: true } },
} satisfies Prisma.CustomerSelect;
