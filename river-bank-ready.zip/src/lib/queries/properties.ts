import type { Prisma } from "@prisma/client";
import type { z } from "zod";
import type { propertyListQuery } from "@/lib/validation/property";

type PropertyFilters = z.infer<typeof propertyListQuery>;

export function propertyWhere(filters: Partial<PropertyFilters>): Prisma.PropertyWhereInput {
  const where: Prisma.PropertyWhereInput = { isDeleted: false };

  if (filters.q) {
    where.AND = [
      {
        OR: [
          { title: { contains: filters.q } },
          { code: { contains: filters.q } },
          { location: { contains: filters.q } },
          { city: { contains: filters.q } },
          { ownerName: { contains: filters.q } },
          { ownerPhone: { contains: filters.q } },
          { ownerEmail: { contains: filters.q } },
          { tags: { contains: filters.q } },
        ],
      },
    ];
  }
  if (filters.type) where.type = filters.type;
  if (filters.purpose) where.purpose = filters.purpose;
  if (filters.tag) where.tags = { contains: filters.tag };
  if (filters.status) where.status = filters.status;
  if (filters.city) where.city = filters.city;
  if (filters.minPrice !== undefined || filters.maxPrice !== undefined) {
    const price: Prisma.IntFilter = {};
    if (filters.minPrice !== undefined) price.gte = filters.minPrice;
    if (filters.maxPrice !== undefined) price.lte = filters.maxPrice;
    where.price = price;
  }
  return where;
}

export function propertyOrderBy(
  sort: PropertyFilters["sort"],
): Prisma.PropertyOrderByWithRelationInput {
  switch (sort) {
    case "oldest":
      return { createdAt: "asc" };
    case "price_asc":
      return { price: "asc" };
    case "price_desc":
      return { price: "desc" };
    case "area":
      return { area: "desc" };
    default:
      return { createdAt: "desc" };
  }
}

export const propertyListSelect = {
  id: true,
  code: true,
  title: true,
  type: true,
  price: true,
  area: true,
  location: true,
  city: true,
  bedrooms: true,
  bathrooms: true,
  status: true,
  ownerName: true,
  ownerPhone: true,
  tags: true,
  purpose: true,
  isDeleted: true,
  createdAt: true,
  images: {
    orderBy: [{ isPrimary: "desc" }, { sortOrder: "asc" }],
    take: 1,
    select: { id: true, url: true, alt: true },
  },
  _count: { select: { interests: true, deals: true } },
} satisfies Prisma.PropertySelect;
