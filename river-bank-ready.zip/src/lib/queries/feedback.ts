import type { Prisma } from "@prisma/client";
import type { z } from "zod";
import { feedbackScope, type SessionUser } from "@/lib/rbac";
import type { feedbackListQuery } from "@/lib/validation/feedback";

type FeedbackFilters = z.infer<typeof feedbackListQuery>;

/**
 * Builds the filtered feedback query. Pending rows are outreach requests that
 * have not been answered yet, so they are hidden unless explicitly requested.
 */
export function feedbackWhere(user: SessionUser, filters: Partial<FeedbackFilters>): Prisma.FeedbackWhereInput {
  const where: Prisma.FeedbackWhereInput = { ...feedbackScope(user) };
  const and: Prisma.FeedbackWhereInput[] = [];

  if (filters.status) {
    where.status = filters.status;
  } else {
    where.status = { in: ["NEW", "RESOLVED"] };
  }

  if (filters.q) {
    and.push({
      OR: [
        { comment: { contains: filters.q } },
        { submittedByName: { contains: filters.q } },
        { customer: { is: { fullName: { contains: filters.q } } } },
        { deal: { is: { title: { contains: filters.q } } } },
        { agent: { is: { name: { contains: filters.q } } } },
      ],
    });
  }

  if (filters.rating) where.rating = filters.rating;
  if (filters.source) where.source = filters.source;
  if (filters.agentId) where.agentId = filters.agentId;
  if (filters.negative === "1") where.isNegative = true;
  if (filters.negative === "0") where.isNegative = false;

  if (filters.from || filters.to) {
    where.createdAt = {};
    if (filters.from) where.createdAt.gte = filters.from;
    if (filters.to) where.createdAt.lte = filters.to;
  }

  if (and.length > 0) where.AND = and;
  return where;
}

export function feedbackOrderBy(
  sort: FeedbackFilters["sort"],
): Prisma.FeedbackOrderByWithRelationInput[] {
  switch (sort) {
    case "oldest":
      return [{ createdAt: "asc" }];
    case "rating_desc":
      return [{ rating: "desc" }, { createdAt: "desc" }];
    case "rating_asc":
      return [{ rating: "asc" }, { createdAt: "desc" }];
    default:
      return [{ createdAt: "desc" }];
  }
}

export const feedbackListSelect = {
  id: true,
  token: true,
  source: true,
  rating: true,
  categories: true,
  comment: true,
  customerId: true,
  dealId: true,
  propertyId: true,
  agentId: true,
  submittedByName: true,
  submittedById: true,
  isNegative: true,
  status: true,
  expiresAt: true,
  resolvedAt: true,
  createdAt: true,
  customer: { select: { id: true, code: true, fullName: true, phone: true, email: true } },
  deal: { select: { id: true, code: true, title: true } },
  property: { select: { id: true, code: true, title: true } },
  agent: { select: { id: true, name: true } },
  resolvedBy: { select: { id: true, name: true } },
  _count: { select: { replies: true } },
} satisfies Prisma.FeedbackSelect;

export const feedbackDetailSelect = {
  ...feedbackListSelect,
  submittedById: true,
  replies: {
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      body: true,
      createdAt: true,
      author: { select: { id: true, name: true, role: true } },
    },
  },
} satisfies Prisma.FeedbackSelect;
