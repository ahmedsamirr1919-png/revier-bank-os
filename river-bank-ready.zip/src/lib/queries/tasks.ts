import type { Prisma } from "@prisma/client";
import type { z } from "zod";
import { taskScope, type SessionUser } from "@/lib/rbac";
import type { taskListQuery } from "@/lib/validation/task";

type TaskFilters = z.infer<typeof taskListQuery>;

export function taskWhere(user: SessionUser, filters: Partial<TaskFilters>): Prisma.TaskWhereInput {
  const where: Prisma.TaskWhereInput = { ...taskScope(user) };

  if (filters.q) {
    where.AND = [
      {
        OR: [
          { title: { contains: filters.q } },
          { description: { contains: filters.q } },
          { customer: { is: { fullName: { contains: filters.q } } } },
        ],
      },
    ];
  }
  if (filters.status) where.status = filters.status;
  if (filters.type) where.type = filters.type;
  if (filters.priority) where.priority = filters.priority;
  if (filters.customerId) where.customerId = filters.customerId;
  if (filters.dealId) where.dealId = filters.dealId;
  if (filters.from || filters.to) {
    where.dueAt = {};
    if (filters.from) where.dueAt.gte = filters.from;
    if (filters.to) where.dueAt.lte = filters.to;
  }
  return where;
}

export function taskOrderBy(sort: TaskFilters["sort"]): Prisma.TaskOrderByWithRelationInput[] {
  switch (sort) {
    case "due_desc":
      return [{ dueAt: "desc" }];
    case "newest":
      return [{ createdAt: "desc" }];
    default:
      return [{ dueAt: "asc" }, { priority: "desc" }];
  }
}

export const taskListSelect = {
  id: true,
  title: true,
  description: true,
  type: true,
  priority: true,
  status: true,
  dueAt: true,
  completedAt: true,
  createdAt: true,
  customerId: true,
  dealId: true,
  propertyId: true,
  assignedToId: true,
  customer: { select: { id: true, code: true, fullName: true } },
  deal: { select: { id: true, code: true, title: true } },
  property: { select: { id: true, code: true, title: true } },
  assignedTo: { select: { id: true, name: true } },
} satisfies Prisma.TaskSelect;
