import type { Prisma } from "@prisma/client";

export const ROLES = ["ADMIN", "MANAGER", "AGENT"] as const;
export type Role = (typeof ROLES)[number];

export function isRole(value: unknown): value is Role {
  return typeof value === "string" && (ROLES as readonly string[]).includes(value);
}

export function asRole(value: unknown): Role {
  return isRole(value) ? value : "AGENT";
}

export type SessionUser = {
  id: string;
  name?: string | null;
  email?: string | null;
  role: Role;
  managerId?: string | null;
};

export const isAdmin = (user: SessionUser) => user.role === "ADMIN";
export const isManager = (user: SessionUser) => user.role === "MANAGER";
export const isAgent = (user: SessionUser) => user.role === "AGENT";

export function canManageUsers(role: Role) {
  return role === "ADMIN";
}

export function canViewAudit(role: Role) {
  return role === "ADMIN" || role === "MANAGER";
}

export function canAssignLeads(role: Role) {
  return role === "ADMIN" || role === "MANAGER";
}

export function canDelete(role: Role) {
  return role === "ADMIN";
}

export function canManageSettings(role: Role) {
  return role === "ADMIN";
}

/**
 * Managers see their own records, records of agents that report to them, and
 * unassigned leads (so they can distribute them). Agents only see their own.
 * Admins see everything.
 */
export function customerScope(user: SessionUser): Prisma.CustomerWhereInput {
  if (user.role === "ADMIN") return {};
  if (user.role === "MANAGER") {
    return {
      OR: [
        { assignedAgentId: user.id },
        { assignedAgent: { is: { managerId: user.id } } },
        { assignedAgentId: null },
      ],
    };
  }
  // Agents see customers assigned to them or created by them; never
  // customers owned by managers/admins.
  return {
    OR: [{ assignedAgentId: user.id }, { createdById: user.id }],
  };
}

export function dealScope(user: SessionUser): Prisma.DealWhereInput {
  if (user.role === "ADMIN") return {};
  if (user.role === "MANAGER") {
    return { OR: [{ agentId: user.id }, { agent: { is: { managerId: user.id } } }] };
  }
  return { agentId: user.id };
}

export function taskScope(user: SessionUser): Prisma.TaskWhereInput {
  if (user.role === "ADMIN") return {};
  if (user.role === "MANAGER") {
    return { OR: [{ assignedToId: user.id }, { assignedTo: { is: { managerId: user.id } } }] };
  }
  return { assignedToId: user.id };
}

export function propertyScope(_user: SessionUser): Prisma.PropertyWhereInput {
  // Inventory is shared across the company; any authenticated user may browse it.
  return {};
}

export function feedbackScope(user: SessionUser): Prisma.FeedbackWhereInput {
  if (user.role === "ADMIN") return {};
  if (user.role === "MANAGER") {
    return {
      OR: [
        { agentId: user.id },
        { agent: { is: { managerId: user.id } } },
        { agentId: null },
      ],
    };
  }
  return { agentId: user.id };
}

export function userScope(user: SessionUser): Prisma.UserWhereInput {
  if (user.role === "ADMIN") return {};
  if (user.role === "MANAGER") {
    return { OR: [{ id: user.id }, { managerId: user.id }] };
  }
  return { id: user.id };
}

export function activityScope(user: SessionUser): Prisma.ActivityLogWhereInput {
  if (user.role === "ADMIN") return {};
  if (user.role === "MANAGER") {
    return { OR: [{ userId: user.id }, { user: { is: { managerId: user.id } } }] };
  }
  return { userId: user.id };
}

/** Agents a user is allowed to assign leads to. */
export function assignableAgentWhere(user: SessionUser): Prisma.UserWhereInput {
  if (user.role === "ADMIN") return { role: { in: ["AGENT", "MANAGER"] }, isActive: true };
  return { OR: [{ id: user.id }, { managerId: user.id }], isActive: true };
}
