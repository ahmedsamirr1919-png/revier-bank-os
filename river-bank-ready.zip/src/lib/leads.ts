import { prisma } from "./prisma";
import { OPEN_CUSTOMER_STATUSES } from "./constants";
import { assignableAgentWhere, customerScope } from "./rbac";
import type { SessionUser } from "./rbac";

export const LEAD_SCORES = ["HOT", "WARM", "COLD"] as const;
export type LeadScore = (typeof LEAD_SCORES)[number];

/** Points awarded per lead source. Referrals convert best, social the weakest. */
export const LEAD_SOURCE_WEIGHTS: Record<string, number> = {
  WEBSITE: 10,
  REFERRAL: 20,
  ADS: 15,
  WALK_IN: 10,
  SOCIAL: 5,
  OTHER: 5,
};

/** Base points per pipeline status. */
export const STATUS_LEAD_SCORES: Record<string, number> = {
  NEW: 0,
  CONTACTED: 10,
  INTERESTED: 30,
  SITE_VISIT: 40,
  NEGOTIATION: 60,
  CLOSED_WON: 90,
  CLOSED_LOST: 0,
};

export const HOT_LEAD_SCORE = 70;
export const WARM_LEAD_SCORE = 40;

export type ComputedLeadScore = { score: number; scoreStatus: LeadScore };

export type LeadScoreInput = {
  source?: string | null;
  status?: string | null;
  budgetMax?: number | null;
  propertyType?: string | null;
  activityCount?: number;
};

/**
 * Heuristic lead scoring: source weight + pipeline status + budget bracket +
 * property interest + logged activity touches. Recomputed whenever a customer
 * is created or updated.
 */
export function computeLeadScore(input: LeadScoreInput): ComputedLeadScore {
  let score = LEAD_SOURCE_WEIGHTS[input.source ?? "OTHER"] ?? 5;
  score += STATUS_LEAD_SCORES[input.status ?? "NEW"] ?? 0;
  if (input.budgetMax) {
    score += input.budgetMax >= 2000000 ? 10 : input.budgetMax >= 1000000 ? 5 : 0;
  }
  const propertyType = input.propertyType;
  if (propertyType) {
    score += propertyType === "VILLA" ? 8 : propertyType === "APARTMENT" || propertyType === "COMMERCIAL" ? 5 : 3;
  }
  score += Math.min(input.activityCount ?? 0, 3) * 5;

  const scoreStatus: LeadScore = score >= HOT_LEAD_SCORE ? "HOT" : score >= WARM_LEAD_SCORE ? "WARM" : "COLD";
  return { score, scoreStatus };
}

export type ScoredCustomer = {
  id: string;
  source: string;
  status: string;
  budgetMax: number | null;
  propertyType: string | null;
  _count?: { activities: number };
};

/** Recompute and persist the lead score for a customer record. */
export async function applyLeadScore(customer: ScoredCustomer): Promise<ComputedLeadScore> {
  const computed = computeLeadScore({
    source: customer.source,
    status: customer.status,
    budgetMax: customer.budgetMax,
    propertyType: customer.propertyType,
    activityCount: customer._count?.activities ?? 0,
  });
  await prisma.customer.update({
    where: { id: customer.id },
    data: { score: computed.score, scoreStatus: computed.scoreStatus },
  });
  return computed;
}

export type LeadPipelineStats = {
  total: number;
  byStatus: Record<string, number>;
  unassignedOpen: number;
  hot: number;
  warm: number;
  cold: number;
};

export async function leadPipelineStats(user: SessionUser): Promise<LeadPipelineStats> {
  const customers = await prisma.customer.findMany({
    where: { ...customerScope(user), isDeleted: false },
    select: { status: true, scoreStatus: true, assignedAgentId: true },
  });

  const byStatus: Record<string, number> = {};
  let unassignedOpen = 0;
  let hot = 0;
  let warm = 0;
  let cold = 0;

  for (const customer of customers) {
    byStatus[customer.status] = (byStatus[customer.status] ?? 0) + 1;
    if ((OPEN_CUSTOMER_STATUSES as readonly string[]).includes(customer.status)) {
      if (!customer.assignedAgentId) unassignedOpen += 1;
    }
    if (customer.scoreStatus === "HOT") hot += 1;
    else if (customer.scoreStatus === "WARM") warm += 1;
    else if (customer.scoreStatus === "COLD") cold += 1;
  }

  return { total: customers.length, byStatus, unassignedOpen, hot, warm, cold };
}

export type StaleLead = {
  id: string;
  code: string;
  fullName: string;
  phone: string;
  email: string | null;
  status: string;
  score: number;
  scoreStatus: string;
  assignedAgentId: string | null;
  assignedAgent: { id: string; name: string } | null;
  createdAt: Date;
  lastActivityAt: Date | null;
  daysSinceActivity: number;
};

/**
 * Open leads that have not been touched (logged activity) within the stale
 * window. Used for staleness alerts and follow-up task creation.
 */
export async function staleLeads(user: SessionUser, days: number): Promise<StaleLead[]> {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const customers = await prisma.customer.findMany({
    where: {
      ...customerScope(user),
      isDeleted: false,
      status: { in: [...OPEN_CUSTOMER_STATUSES] },
    },
    select: {
      id: true,
      code: true,
      fullName: true,
      phone: true,
      email: true,
      status: true,
      score: true,
      scoreStatus: true,
      assignedAgentId: true,
      createdAt: true,
      assignedAgent: { select: { id: true, name: true } },
      activities: { orderBy: { occurredAt: "desc" }, take: 1, select: { occurredAt: true } },
    },
  });

  const stale: StaleLead[] = [];
  const now = Date.now();
  for (const customer of customers) {
    const lastActivityAt = customer.activities[0]?.occurredAt ?? null;
    const lastTouch = lastActivityAt ?? customer.createdAt;
    if (lastTouch >= since) continue;
    stale.push({
      id: customer.id,
      code: customer.code,
      fullName: customer.fullName,
      phone: customer.phone,
      email: customer.email,
      status: customer.status,
      score: customer.score,
      scoreStatus: customer.scoreStatus,
      assignedAgentId: customer.assignedAgentId,
      assignedAgent: customer.assignedAgent,
      createdAt: customer.createdAt,
      lastActivityAt,
      daysSinceActivity: Math.floor((now - lastTouch.getTime()) / (24 * 60 * 60 * 1000)),
    });
  }

  return stale.sort((a, b) => b.daysSinceActivity - a.daysSinceActivity);
}

export type AutoAssignResult = {
  assignments: Array<{ customerId: string; agentId: string }>;
  unassignedFound: number;
};

/**
 * Distributes unassigned open leads to the least busy eligible agent. Sales
 * managers and admins only.
 */
export async function autoAssignUnassigned(user: SessionUser): Promise<AutoAssignResult> {
  const openStatuses = [...OPEN_CUSTOMER_STATUSES];
  const unassigned = await prisma.customer.findMany({
    where: {
      ...customerScope(user),
      isDeleted: false,
      assignedAgentId: null,
      status: { in: openStatuses },
    },
    select: { id: true, code: true, fullName: true, status: true },
  });

  if (unassigned.length === 0) return { assignments: [], unassignedFound: 0 };

  const agents = await prisma.user.findMany({
    where: { ...assignableAgentWhere(user), isActive: true },
    select: {
      id: true,
      name: true,
      assignedCustomers: {
        where: { isDeleted: false, status: { notIn: ["CLOSED_WON", "CLOSED_LOST"] } },
        select: { id: true },
      },
    },
  });

  const agentsWithLoad = agents.map((agent) => ({
    agent,
    load: agent.assignedCustomers.length,
  }));
  agentsWithLoad.sort((a, b) => a.load - b.load || a.agent.name.localeCompare(b.agent.name));

  const assignments: Array<{ customerId: string; agentId: string }> = [];
  let pool = [...unassigned];

  while (pool.length > 0 && agentsWithLoad.length > 0) {
    const target = agentsWithLoad[0];
    const customer = pool.shift();
    if (!customer) break;
    await prisma.customer.update({
      where: { id: customer.id },
      data: { assignedAgentId: target.agent.id },
    });
    assignments.push({ customerId: customer.id, agentId: target.agent.id });
    await prisma.customerActivity.create({
      data: {
        customerId: customer.id,
        userId: user.id,
        type: "ASSIGNMENT",
        title: "Lead auto-assigned",
        body: `Auto-assigned to ${target.agent.name} by automation.`,
      },
    });
    target.load += 1;
    // Re-sort so the least busy agent keeps receiving the next lead.
    agentsWithLoad.sort((a, b) => a.load - b.load || a.agent.name.localeCompare(b.agent.name));
  }

  return { assignments, unassignedFound: unassigned.length };
}
