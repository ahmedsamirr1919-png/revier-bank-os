import { CSRF_COOKIE } from "./utils";

export class ApiClientError extends Error {
  status: number;
  code: string;
  details?: unknown;

  constructor(message: string, status: number, code: string, details?: unknown) {
    super(message);
    this.name = "ApiClientError";
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

function readCookie(name: string) {
  if (typeof document === "undefined") return null;
  const match = document.cookie.split("; ").find((row) => row.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.split("=").slice(1).join("=")) : null;
}

type ApiFetchOptions = {
  method?: "GET" | "POST" | "PATCH" | "PUT" | "DELETE";
  body?: unknown;
  signal?: AbortSignal;
};

export async function apiFetch<T>(url: string, options: ApiFetchOptions = {}): Promise<T> {
  const method = options.method ?? "GET";
  const headers: Record<string, string> = { Accept: "application/json" };

  if (options.body !== undefined) headers["Content-Type"] = "application/json";

  const csrf = readCookie(CSRF_COOKIE);
  if (csrf && method !== "GET") headers["x-csrf-token"] = csrf;

  const response = await fetch(url, {
    method,
    headers,
    credentials: "same-origin",
    cache: "no-store",
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
    signal: options.signal,
  });

  const payload = await response.json().catch(() => null);

  if (!response.ok) {
    throw new ApiClientError(
      (payload && typeof payload.message === "string" && payload.message) || "Request failed",
      response.status,
      (payload && typeof payload.error === "string" && payload.error) || "request_failed",
      payload?.details,
    );
  }

  return payload as T;
}

export const api = {
  get: <T>(url: string, signal?: AbortSignal) => apiFetch<T>(url, { signal }),
  post: <T>(url: string, body?: unknown) => apiFetch<T>(url, { method: "POST", body }),
  patch: <T>(url: string, body?: unknown) => apiFetch<T>(url, { method: "PATCH", body }),
  put: <T>(url: string, body?: unknown) => apiFetch<T>(url, { method: "PUT", body }),
  delete: <T>(url: string) => apiFetch<T>(url, { method: "DELETE" }),
};

export function fieldErrors(error: unknown): Record<string, string[]> | null {
  if (error instanceof ApiClientError) {
    const details = error.details as { fieldErrors?: Record<string, string[]> } | undefined;
    return details?.fieldErrors ?? null;
  }
  return null;
}
