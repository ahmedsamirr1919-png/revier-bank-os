import "server-only";
import { NextResponse, type NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import type { z, ZodTypeAny } from "zod";
import { auth } from "@/auth";
import { REMEMBER_SESSION_MS, SHORT_SESSION_MS } from "@/auth.config";
import { asRole, type Role } from "./rbac";
import { clamp } from "./utils";

export class ApiError extends Error {
  status: number;
  code: string;
  details?: unknown;

  constructor(code: string, status: number, message: string, details?: unknown) {
    super(message);
    this.name = "ApiError";
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

export type SessionUser = {
  id: string;
  name: string;
  email: string;
  role: Role;
  managerId: string | null;
  mustChangePassword: boolean;
  locale: string;
};

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

export function fail(code: string, status: number, message: string, details?: unknown) {
  return NextResponse.json({ error: code, message, details }, { status });
}

export async function requireUser(): Promise<SessionUser> {
  const session = await auth();
  const user = session?.user;
  if (!session || !user?.id) throw new ApiError("unauthorized", 401, "Authentication required");

  if (typeof session.authAt === "number") {
    const limit = session.remember ? REMEMBER_SESSION_MS : SHORT_SESSION_MS;
    if (Date.now() - session.authAt > limit) {
      throw new ApiError("session_expired", 401, "Session expired");
    }
  }

  return {
    id: user.id,
    name: user.name ?? "",
    email: user.email ?? "",
    role: asRole(user.role),
    managerId: user.managerId ?? null,
    mustChangePassword: Boolean(user.mustChangePassword),
    locale: user.locale ?? "en",
  };
}

export function requireRole(user: SessionUser, roles: Role[]) {
  if (!roles.includes(user.role)) {
    throw new ApiError("forbidden", 403, "You do not have permission to perform this action");
  }
  return user;
}

export async function parseBody<S extends ZodTypeAny>(req: NextRequest, schema: S): Promise<z.infer<S>> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    throw new ApiError("invalid_json", 400, "Request body must be valid JSON");
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    throw new ApiError("validation_error", 422, "Please check the highlighted fields", {
      fieldErrors: parsed.error.flatten().fieldErrors,
      formErrors: parsed.error.flatten().formErrors,
    });
  }
  return parsed.data;
}

export function parseQuery<S extends ZodTypeAny>(req: NextRequest, schema: S): z.infer<S> {
  const raw = Object.fromEntries(req.nextUrl.searchParams.entries());
  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    throw new ApiError("validation_error", 422, "Invalid query parameters", {
      fieldErrors: parsed.error.flatten().fieldErrors,
    });
  }
  return parsed.data;
}

export function pagination(req: NextRequest) {
  const page = Math.max(1, Number(req.nextUrl.searchParams.get("page") ?? 1) || 1);
  const pageSize = clamp(Number(req.nextUrl.searchParams.get("pageSize") ?? 10) || 10, 1, 100);
  return { page, pageSize, skip: (page - 1) * pageSize, take: pageSize };
}

export function paginated<T>(items: T[], total: number, page: number, pageSize: number) {
  return {
    items,
    total,
    page,
    pageSize,
    pages: Math.max(1, Math.ceil(total / pageSize)),
  };
}

function assertSameOrigin(req: NextRequest) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return;
  const origin = req.headers.get("origin");
  if (!origin) return;
  try {
    if (new URL(origin).host !== req.headers.get("host")) {
      throw new ApiError("origin_mismatch", 403, "Cross-origin request blocked");
    }
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError("origin_mismatch", 403, "Invalid origin header");
  }
}

type Handler<C> = (req: NextRequest, ctx: C) => Promise<NextResponse> | NextResponse;

export function handle<C = unknown>(fn: Handler<C>): Handler<C> {
  return async (req, ctx) => {
    try {
      assertSameOrigin(req);
      return await fn(req, ctx);
    } catch (error) {
      if (error instanceof ApiError) {
        return fail(error.code, error.status, error.message, error.details);
      }
      if (error instanceof Prisma.PrismaClientKnownRequestError) {
        if (error.code === "P2002") {
          return fail("duplicate", 409, "A record with this value already exists");
        }
        if (error.code === "P2025") {
          return fail("not_found", 404, "Record not found");
        }
        if (error.code === "P2003") {
          return fail("invalid_reference", 400, "This record is referenced by other data and cannot be changed");
        }
      }
      console.error("[api] unhandled error", error);
      return fail("server_error", 500, "Something went wrong on the server");
    }
  };
}

export function notFound(message = "Not found") {
  return fail("not_found", 404, message);
}
