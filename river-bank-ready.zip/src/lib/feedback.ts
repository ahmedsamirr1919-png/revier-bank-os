import "server-only";
import { randomBytes } from "node:crypto";
import { ApiError } from "./api";
import { prisma } from "./prisma";
import { notify } from "./activity";
import { assertAssignableAgent, assertCustomerAccess, dealAccessWhere } from "./access";
import type { SessionUser } from "./rbac";

export const DEFAULT_NEGATIVE_THRESHOLD = 2;
export const DEFAULT_REQUEST_EXPIRY_DAYS = 14;

export function createFeedbackToken() {
  return randomBytes(24).toString("hex");
}

export function feedbackPublicPath(token: string) {
  return `/f/${token}`;
}

/** Negative ratings are configured in Settings (`feedback.negativeThreshold`). */
export async function getNegativeThreshold(): Promise<number> {
  const setting = await prisma.setting.findUnique({
    where: { key: "feedback.negativeThreshold" },
    select: { value: true },
  });
  const parsed = Number(setting?.value);
  return Number.isInteger(parsed) && parsed >= 1 && parsed <= 5 ? parsed : DEFAULT_NEGATIVE_THRESHOLD;
}

export type FeedbackTargets = {
  customerId: string | null;
  dealId: string | null;
  propertyId: string | null;
  agentId: string;
  customerName: string | null;
};

/**
 * Resolves and validates every record a feedback entry points at, while keeping
 * ownership rules intact. When a deal is supplied its customer, property and
 * agent are used as defaults so the entry can never drift from the deal.
 */
export async function resolveFeedbackTargets(
  user: SessionUser,
  input: {
    customerId?: string | null;
    dealId?: string | null;
    propertyId?: string | null;
    agentId?: string | null;
  },
): Promise<FeedbackTargets> {
  let customerId = input.customerId ?? null;
  let dealId = input.dealId ?? null;
  let propertyId = input.propertyId ?? null;
  let derivedAgentId: string | null = null;
  let customerName: string | null = null;
  let dealCustomerId: string | null = null;

  if (dealId) {
    const deal = await prisma.deal.findFirst({
      where: dealAccessWhere(user, dealId),
      select: { id: true, customerId: true, propertyId: true, agentId: true },
    });
    if (!deal) throw new ApiError("not_found", 404, "Deal not found");
    dealCustomerId = deal.customerId;
    customerId ??= deal.customerId;
    propertyId ??= deal.propertyId;
    derivedAgentId = deal.agentId;
  }

  if (customerId) {
    const customer = await assertCustomerAccess(user, customerId);
    customerName = customer.fullName;
    if (dealCustomerId && dealCustomerId !== customerId) {
      throw new ApiError("invalid_reference", 422, "The selected deal belongs to another customer");
    }
    derivedAgentId ??= customer.assignedAgentId;
  }

  if (propertyId) {
    const property = await prisma.property.findFirst({
      where: { id: propertyId, isDeleted: false },
      select: { id: true },
    });
    if (!property) throw new ApiError("not_found", 404, "Property not found");
  }

  let agentId = input.agentId ?? derivedAgentId ?? user.id;
  if (input.agentId) {
    const agent = await assertAssignableAgent(user, input.agentId);
    agentId = agent.id;
  }
  if (user.role === "AGENT") agentId = user.id;

  return { customerId, dealId, propertyId, agentId, customerName };
}

/** Fan out an alert to the rated agent, their manager and every active admin. */
export async function notifyNegativeFeedback(input: {
  feedbackId: string;
  rating: number;
  customerName?: string | null;
  agentId?: string | null;
}) {
  const recipients = new Set<string>();

  if (input.agentId) {
    recipients.add(input.agentId);
    const agent = await prisma.user.findUnique({
      where: { id: input.agentId },
      select: { managerId: true },
    });
    if (agent?.managerId) recipients.add(agent.managerId);
  }

  const admins = await prisma.user.findMany({
    where: { role: "ADMIN", isActive: true },
    select: { id: true },
  });
  for (const admin of admins) recipients.add(admin.id);

  const body = input.customerName
    ? `A ${input.rating}-star rating was submitted by ${input.customerName}.`
    : `A ${input.rating}-star rating was submitted.`;

  await Promise.all(
    [...recipients].map((userId) =>
      notify({
        userId,
        type: "FEEDBACK_NEGATIVE",
        title: "Negative feedback received",
        body,
        link: `/feedback/${input.feedbackId}`,
      }),
    ),
  );
}
