import type { Role } from "./rbac";

// Every enum-like list must mirror prisma/schema.prisma comments.
export const CUSTOMER_SOURCES = ["WEBSITE", "REFERRAL", "ADS", "WALK_IN", "SOCIAL", "OTHER"] as const;
export type CustomerSource = (typeof CUSTOMER_SOURCES)[number];

export const CUSTOMER_STATUSES = [
  "NEW",
  "CONTACTED",
  "INTERESTED",
  "SITE_VISIT",
  "NEGOTIATION",
  "CLOSED_WON",
  "CLOSED_LOST",
] as const;
export type CustomerStatus = (typeof CUSTOMER_STATUSES)[number];

export const OPEN_CUSTOMER_STATUSES: CustomerStatus[] = [
  "NEW",
  "CONTACTED",
  "INTERESTED",
  "SITE_VISIT",
  "NEGOTIATION",
];

export const PROPERTY_TYPES = ["APARTMENT", "VILLA", "LAND", "COMMERCIAL"] as const;
export type PropertyType = (typeof PROPERTY_TYPES)[number];

export const PROPERTY_TAGS = ["STUDIO", "BASEMENT", "MALL", "ROOF"] as const;
export type PropertyTag = (typeof PROPERTY_TAGS)[number];

export const PROPERTY_STATUSES = ["AVAILABLE", "RESERVED", "SOLD"] as const;
export type PropertyStatus = (typeof PROPERTY_STATUSES)[number];

export const PROPERTY_PURPOSES = ["RENT", "SALE"] as const;
export type PropertyPurpose = (typeof PROPERTY_PURPOSES)[number];

export const DEAL_STAGES = [
  "PROSPECTING",
  "NEGOTIATION",
  "UNDER_CONTRACT",
  "CLOSED_WON",
  "CLOSED_LOST",
  "ON_HOLD",
] as const;
export type DealStage = (typeof DEAL_STAGES)[number];

export const OPEN_DEAL_STAGES: DealStage[] = ["PROSPECTING", "NEGOTIATION", "UNDER_CONTRACT", "ON_HOLD"];

export const TASK_TYPES = ["CALL_BACK", "MEETING", "SITE_VISIT", "FOLLOW_UP", "OTHER"] as const;
export type TaskType = (typeof TASK_TYPES)[number];

export const TASK_PRIORITIES = ["LOW", "MEDIUM", "HIGH"] as const;
export type TaskPriority = (typeof TASK_PRIORITIES)[number];

export const TASK_STATUSES = ["PENDING", "DONE", "CANCELLED"] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const FEEDBACK_CATEGORIES = ["service", "price", "property", "agent_behavior"] as const;
export type FeedbackCategory = (typeof FEEDBACK_CATEGORIES)[number];

export const FEEDBACK_STATUSES = ["PENDING", "NEW", "RESOLVED"] as const;
export type FeedbackStatus = (typeof FEEDBACK_STATUSES)[number];

export const FEEDBACK_SOURCES = ["INTERNAL", "PUBLIC"] as const;
export type FeedbackSource = (typeof FEEDBACK_SOURCES)[number];

export const LEAD_SCORES = ["HOT", "WARM", "COLD"] as const;
export type LeadScore = (typeof LEAD_SCORES)[number];

export const DEFAULT_STALE_DAYS = 14;

export const ACTIVITY_TYPES = [
  "CALL",
  "NOTE",
  "MEETING",
  "EMAIL",
  "SITE_VISIT",
  "STATUS_CHANGE",
  "ASSIGNMENT",
  "FEEDBACK",
] as const;

export const USER_ROLES: Role[] = ["ADMIN", "MANAGER", "AGENT"];

export const PIPELINE_ORDER: CustomerStatus[] = [
  "NEW",
  "CONTACTED",
  "INTERESTED",
  "SITE_VISIT",
  "NEGOTIATION",
  "CLOSED_WON",
  "CLOSED_LOST",
];

export const PAGE_SIZE = 10;
export const PAGE_SIZE_OPTIONS = [10, 25, 50];

export const STATUS_STYLES: Record<string, string> = {
  NEW: "bg-sky-100 text-sky-800 dark:bg-sky-500/15 dark:text-sky-300",
  CONTACTED: "bg-blue-100 text-blue-800 dark:bg-blue-500/15 dark:text-blue-300",
  INTERESTED: "bg-indigo-100 text-indigo-800 dark:bg-indigo-500/15 dark:text-indigo-300",
  SITE_VISIT: "bg-violet-100 text-violet-800 dark:bg-violet-500/15 dark:text-violet-300",
  NEGOTIATION: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
  CLOSED_WON: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  CLOSED_LOST: "bg-rose-100 text-rose-800 dark:bg-rose-500/15 dark:text-rose-300",
  PROSPECTING: "bg-sky-100 text-sky-800 dark:bg-sky-500/15 dark:text-sky-300",
  UNDER_CONTRACT: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
  ON_HOLD: "bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300",
  AVAILABLE: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  RESERVED: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
  SOLD: "bg-slate-200 text-slate-700 dark:bg-slate-500/20 dark:text-slate-300",
  PENDING: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
  DONE: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  CANCELLED: "bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-400",
  RESOLVED: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  LOW: "bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300",
  MEDIUM: "bg-sky-100 text-sky-800 dark:bg-sky-500/15 dark:text-sky-300",
  HIGH: "bg-rose-100 text-rose-800 dark:bg-rose-500/15 dark:text-rose-300",
};

export const DEAL_STAGE_COLORS: Record<string, string> = {
  PROSPECTING: "#0ea5e9",
  NEGOTIATION: "#f59e0b",
  UNDER_CONTRACT: "#8b5cf6",
  CLOSED_WON: "#10b981",
  CLOSED_LOST: "#f43f5e",
  ON_HOLD: "#64748b",
};

export const CHART_COLORS = ["#0f766e", "#0ea5e9", "#6366f1", "#f59e0b", "#10b981", "#f43f5e", "#8b5cf6"];

export const LEAD_SCORE_STYLES: Record<string, string> = {
  HOT: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
  WARM: "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
  COLD: "bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300",
};
