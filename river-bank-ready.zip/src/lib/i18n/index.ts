import en from "../../../messages/en.json";
import ar from "../../../messages/ar.json";
import type { Locale } from "../utils";

export type Messages = typeof en;

export const dictionaries: Record<Locale, Messages> = {
  en,
  ar: ar as unknown as Messages,
};

export function translate(
  messages: Messages,
  key: string,
  vars?: Record<string, string | number>,
): string {
  const raw = key.split(".").reduce<unknown>((acc, part) => {
    if (acc && typeof acc === "object" && part in (acc as Record<string, unknown>)) {
      return (acc as Record<string, unknown>)[part];
    }
    return undefined;
  }, messages);

  let value = typeof raw === "string" ? raw : key.split(".").pop()?.replace(/_/g, " ") ?? key;
  if (vars) {
    value = value.replace(/\{(\w+)\}/g, (match, name: string) =>
      Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : match,
    );
  }
  return value;
}

export function enumLabel(messages: Messages, group: string, value: string | null | undefined) {
  if (!value) return "—";
  const raw = (messages.enums as unknown as Record<string, Record<string, string>>)[group]?.[value];
  return raw ?? value.replace(/_/g, " ").toLowerCase();
}
