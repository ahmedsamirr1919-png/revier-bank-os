import "server-only";
import { cookies } from "next/headers";
import { LOCALE_COOKIE, isLocale, type Locale } from "../utils";
import { dictionaries, translate, type Messages } from "./index";

export type Translator = (key: string, vars?: Record<string, string | number>) => string;

export async function getLocale(): Promise<Locale> {
  const store = await cookies();
  const value = store.get(LOCALE_COOKIE)?.value;
  return isLocale(value) ? value : "en";
}

export async function getI18n(): Promise<{
  locale: Locale;
  dir: "ltr" | "rtl";
  messages: Messages;
  t: Translator;
}> {
  const locale = await getLocale();
  const messages = dictionaries[locale];
  return {
    locale,
    dir: locale === "ar" ? "rtl" : "ltr",
    messages,
    t: (key, vars) => translate(messages, key, vars),
  };
}
