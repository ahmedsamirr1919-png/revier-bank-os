import { z } from "zod";
import { TASK_PRIORITIES, TASK_STATUSES, TASK_TYPES } from "@/lib/constants";
import { idSchema, optionalDate, optionalText } from "./common";

export const taskInputSchema = z.object({
  title: z.string().trim().min(2, "Task title is required").max(160),
  description: optionalText(2000),
  type: z.enum(TASK_TYPES).default("CALL_BACK"),
  priority: z.enum(TASK_PRIORITIES).default("MEDIUM"),
  status: z.enum(TASK_STATUSES).default("PENDING"),
  dueAt: z.coerce.date({ message: "Due date is required" }),
  customerId: optionalText(60),
  dealId: optionalText(60),
  propertyId: optionalText(60),
  assignedToId: optionalText(60),
}).strict();

export const taskStatusSchema = z.object({
  status: z.enum(TASK_STATUSES),
}).strict();

export const taskListQuery = z.object({
  q: z.string().trim().max(120).optional(),
  status: z.enum(TASK_STATUSES).optional(),
  type: z.enum(TASK_TYPES).optional(),
  priority: z.enum(TASK_PRIORITIES).optional(),
  customerId: z.string().max(60).optional(),
  dealId: z.string().max(60).optional(),
  from: optionalDate,
  to: optionalDate,
  sort: z.enum(["due_asc", "due_desc", "newest"]).default("due_asc"),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
}).strict();

export type TaskInput = z.infer<typeof taskInputSchema>;
