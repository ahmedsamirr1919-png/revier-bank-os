import { z } from "zod";

/** Trimmed optional text: "" becomes null. */
export const optionalText = (max = 500): z.ZodType<string | null | undefined> =>
  z.preprocess(
    (value) => (typeof value === "string" && value.trim() === "" ? null : value),
    z.string().trim().max(max).nullable().optional(),
  ) as unknown as z.ZodType<string | null | undefined>;

export const optionalEmail: z.ZodType<string | null | undefined> = z.preprocess(
  (value) => (typeof value === "string" && value.trim() === "" ? null : value),
  z
    .string()
    .trim()
    .email("Enter a valid email address")
    .max(160)
    .transform((value) => value.toLowerCase())
    .nullable()
    .optional(),
) as unknown as z.ZodType<string | null | undefined>;

export const optionalInt: z.ZodType<number | null | undefined> = z.preprocess(
  (value) => {
    if (value === "" || value === null || value === undefined) return null;
    if (typeof value === "string") return Number(value.replace(/[^\d.-]/g, ""));
    return value;
  },
  z.number().int().nonnegative().nullable().optional(),
) as unknown as z.ZodType<number | null | undefined>;

export const optionalDate: z.ZodType<Date | null | undefined> = z.preprocess(
  (value) => (value === "" || value === null || value === undefined ? null : value),
  z.coerce.date().nullable().optional(),
) as unknown as z.ZodType<Date | null | undefined>;

export const optionalEnum = <T extends readonly [string, ...string[]]>(values: T) =>
  z.preprocess(
    (value) => (value === "" || value === null ? null : value),
    z.enum(values as unknown as [string, ...string[]]).nullable().optional(),
  ) as unknown as z.ZodType<T[number] | null | undefined>;

export const idSchema = z.string().min(1).max(60);
