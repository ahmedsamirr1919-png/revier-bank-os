import { z } from "zod";
import {
  CUSTOMER_SOURCES,
  CUSTOMER_STATUSES,
  PROPERTY_PURPOSES,
  PROPERTY_TYPES,
} from "@/lib/constants";
import { optionalEmail, optionalEnum, optionalInt, optionalText } from "./common";

export const customerInputSchema = z
  .object({
    fullName: z.string().trim().min(2, "Full name is required").max(120),
    phone: z.string().trim().min(5, "Phone is required").max(30),
    email: optionalEmail,
    whatsapp: optionalText(30),
    source: z.enum(CUSTOMER_SOURCES).default("WEBSITE"),
    status: z.enum(CUSTOMER_STATUSES).optional(),
    budgetMin: optionalInt,
    budgetMax: optionalInt,
    currency: z.string().trim().max(3).default("EGP"),
    preferredArea: optionalText(120),
    propertyType: optionalEnum(PROPERTY_TYPES),
    purpose: optionalEnum(PROPERTY_PURPOSES),
    assignedAgentId: optionalText(60),
    notes: optionalText(3000),
  }).strict()
  .refine((data) => !data.budgetMin || !data.budgetMax || data.budgetMax >= data.budgetMin, {
    message: "Maximum budget must be greater than the minimum",
    path: ["budgetMax"],
  });

export const customerUpdateSchema = customerInputSchema;

export const customerListQuery = z.object({
  q: z.string().trim().max(120).optional(),
  status: z.enum(CUSTOMER_STATUSES).optional(),
  source: z.enum(CUSTOMER_SOURCES).optional(),
  agentId: z.string().max(60).optional(),
  propertyType: z.enum(PROPERTY_TYPES).optional(),
  purpose: z.enum(PROPERTY_PURPOSES).optional(),
  from: z.string().max(30).optional(),
  to: z.string().max(30).optional(),
  sort: z.enum(["newest", "oldest", "name", "budget"]).default("newest"),
  trash: z.enum(["0", "1"]).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(10),
}).strict();

export const customerActivitySchema = z.object({
  type: z.enum(["CALL", "NOTE", "MEETING", "EMAIL", "SITE_VISIT"]),
  title: z.string().trim().min(2).max(160),
  body: optionalText(3000),
  outcome: optionalText(300),
  occurredAt: z.coerce.date().optional(),
}).strict();

export const assignSchema = z.object({
  assignedAgentId: z.string().trim().min(1).nullable(),
  note: optionalText(300),
}).strict();

export const importSchema = z.object({
  rows: z.array(z.record(z.string(), z.string())).min(1).max(1000),
}).strict();

