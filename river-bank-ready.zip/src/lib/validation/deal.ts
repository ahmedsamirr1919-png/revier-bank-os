import { z } from "zod";
import { DEAL_STAGES } from "@/lib/constants";
import { idSchema, optionalDate, optionalEnum, optionalText } from "./common";

export const dealInputSchema = z.object({
  title: z.string().trim().min(2, "Deal title is required").max(160),
  customerId: idSchema,
  propertyId: optionalText(60),
  agentId: optionalText(60),
  value: z.coerce.number().int().positive("Deal value must be greater than zero"),
  currency: z.string().trim().max(3).default("EGP"),
  commissionRate: z.coerce.number().min(0).max(100).default(2.5),
  probability: z.coerce.number().int().min(0).max(100).optional(),
  expectedCloseDate: optionalDate,
  stage: z.enum(DEAL_STAGES).default("PROSPECTING"),
  lostReason: optionalText(500),
  notes: optionalText(3000),
}).strict();

export const dealStageSchema = z.object({
  stage: z.enum(DEAL_STAGES),
  lostReason: optionalText(500),
  note: optionalText(300),
}).strict();

export const dealListQuery = z.object({
  q: z.string().trim().max(120).optional(),
  stage: z.enum(DEAL_STAGES).optional(),
  agentId: z.string().max(60).optional(),
  customerId: z.string().max(60).optional(),
  propertyId: z.string().max(60).optional(),
  sort: z.enum(["newest", "oldest", "value_asc", "value_desc", "expected"]).default("newest"),
  trash: z.enum(["0", "1"]).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(50),
}).strict();

export type DealInput = z.infer<typeof dealInputSchema>;
export type DealStageInput = z.infer<typeof dealStageSchema>;
