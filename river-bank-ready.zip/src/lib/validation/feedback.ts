import { z } from "zod";
import { FEEDBACK_CATEGORIES, FEEDBACK_SOURCES, FEEDBACK_STATUSES } from "@/lib/constants";
import { optionalDate, optionalText } from "./common";

const categoriesSchema = z
  .array(z.enum(FEEDBACK_CATEGORIES))
  .max(FEEDBACK_CATEGORIES.length)
  .default([]);

const ratingSchema = z.coerce.number().int().min(1).max(5);
const optionalRating = z.preprocess(
  (value) => (value === "" || value === null || value === undefined ? undefined : Number(value)),
  ratingSchema.optional(),
);

export const feedbackListQuery = z.object({
  q: z.string().trim().max(120).optional(),
  status: z.enum(FEEDBACK_STATUSES).optional(),
  rating: optionalRating,
  source: z.enum(FEEDBACK_SOURCES).optional(),
  agentId: z.string().max(60).optional(),
  negative: z.enum(["0", "1"]).optional(),
  from: optionalDate,
  to: optionalDate,
  sort: z.enum(["newest", "oldest", "rating_desc", "rating_asc"]).default("newest"),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(10),
}).strict();

export const feedbackInputSchema = z
  .object({
    rating: ratingSchema,
    categories: categoriesSchema,
    comment: optionalText(2000),
    customerId: optionalText(60),
    dealId: optionalText(60),
    propertyId: optionalText(60),
    agentId: optionalText(60),
    submittedByName: optionalText(160),
  }).strict()
  .refine((value) => value.rating > 2 || (value.comment?.trim().length ?? 0) >= 3, {
    message: "Please tell us what went wrong",
    path: ["comment"],
  });

export const feedbackRequestSchema = z
  .object({
    customerId: optionalText(60),
    dealId: optionalText(60),
    propertyId: optionalText(60),
    agentId: optionalText(60),
    expiresInDays: z.coerce.number().int().min(1).max(90).default(14),
  }).strict()
  .refine((value) => Boolean(value.customerId || value.dealId), {
    message: "Choose a customer or deal",
    path: ["customerId"],
  });

export const feedbackStatusSchema = z.object({
  status: z.enum(["NEW", "RESOLVED"]),
}).strict();

export const feedbackReplySchema = z.object({
  body: z.string().trim().min(2, "Write a reply").max(2000),
}).strict();

export const publicFeedbackSchema = z
  .object({
    rating: ratingSchema,
    categories: categoriesSchema,
    comment: optionalText(2000),
    submittedByName: optionalText(120),
  }).strict()
  .refine((value) => value.rating > 2 || (value.comment?.trim().length ?? 0) >= 3, {
    message: "Please tell us what went wrong",
    path: ["comment"],
  });

export type FeedbackInput = z.infer<typeof feedbackInputSchema>;
export type FeedbackRequestInput = z.infer<typeof feedbackRequestSchema>;
export type FeedbackListFilters = z.infer<typeof feedbackListQuery>;
