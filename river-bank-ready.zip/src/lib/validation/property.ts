import { z } from "zod";
import { PROPERTY_PURPOSES, PROPERTY_STATUSES, PROPERTY_TAGS, PROPERTY_TYPES } from "@/lib/constants";
import { optionalEmail, optionalInt, optionalText } from "./common";

const propertyImageSchema = z.object({
  url: z.string().trim().url("Enter a valid image URL").max(600),
  alt: optionalText(160),
  isPrimary: z.boolean().optional(),
}).strict();

export const propertyInputSchema = z
  .object({
    title: z.string().trim().min(3, "Title is required").max(160),
    type: z.enum(PROPERTY_TYPES),
    price: z.coerce.number().int().positive("Price must be greater than zero"),
    area: z.coerce.number().positive("Area must be greater than zero"),
    location: z.string().trim().min(2, "Location is required").max(160),
    city: z.string().trim().min(2).max(80),
    bedrooms: optionalInt,
    bathrooms: optionalInt,
    status: z.enum(PROPERTY_STATUSES).default("AVAILABLE"),
    purpose: z.enum(PROPERTY_PURPOSES).default("SALE"),
    description: optionalText(3000),
    ownerName: optionalText(160),
    ownerPhone: optionalText(40),
    ownerEmail: optionalEmail,
    ownerIdNumber: optionalText(60),
    ownerNotes: optionalText(1000),
    tags: z.array(z.enum(PROPERTY_TAGS as unknown as [string, ...string[]])).max(4).optional(),
    images: z.array(propertyImageSchema).max(10).optional(),
  }).strict()
  .refine((data) => !data.bedrooms || !data.bathrooms || data.bathrooms <= data.bedrooms + 2, {
    message: "Check the bedroom and bathroom counts",
    path: ["bathrooms"],
  });

export const propertyListQuery = z.object({
  q: z.string().trim().max(120).optional(),
  type: z.enum(PROPERTY_TYPES).optional(),
  tag: z.enum(PROPERTY_TAGS as unknown as [string, ...string[]]).optional(),
  purpose: z.enum(PROPERTY_PURPOSES).optional(),
  status: z.enum(PROPERTY_STATUSES).optional(),
  city: z.string().trim().max(80).optional(),
  minPrice: z.coerce.number().nonnegative().optional(),
  maxPrice: z.coerce.number().nonnegative().optional(),
  sort: z.enum(["newest", "oldest", "price_asc", "price_desc", "area"]).default("newest"),
  trash: z.enum(["0", "1"]).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(12),
}).strict();

export const propertyLinkSchema = z.object({
  customerId: z.string().trim().min(1).max(60),
  relation: z.enum(["INTERESTED", "PURCHASED"]).default("INTERESTED"),
}).strict();
