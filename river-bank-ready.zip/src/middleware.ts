import NextAuth from "next-auth";
import { NextResponse, type NextRequest } from "next/server";
import { authConfig, REMEMBER_SESSION_MS, SHORT_SESSION_MS } from "@/auth.config";
import { CSRF_COOKIE } from "@/lib/utils";
import type { Role } from "@/lib/rbac";

const { auth } = NextAuth(authConfig);

const PUBLIC_PAGE_PREFIXES = ["/login", "/f/"];
const PUBLIC_API_PREFIXES = ["/api/auth", "/api/health", "/api/feedback/public"];

const ROLE_RULES: Array<{ prefix: string; roles: Role[] }> = [
  { prefix: "/users", roles: ["ADMIN"] },
  { prefix: "/api/users", roles: ["ADMIN"] },
  { prefix: "/activity", roles: ["ADMIN", "MANAGER"] },
  { prefix: "/api/activity", roles: ["ADMIN", "MANAGER"] },
  { prefix: "/api/settings", roles: ["ADMIN"] },
  { prefix: "/settings", roles: ["ADMIN"] },
];

function withCsrfCookie(req: NextRequest, res: NextResponse) {
  if (!req.cookies.get(CSRF_COOKIE)) {
    res.cookies.set(CSRF_COOKIE, crypto.randomUUID(), {
      httpOnly: false,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 7 * 24 * 60 * 60,
    });
  }
  return res;
}

function isPublic(prefixes: string[], path: string) {
  return prefixes.some((prefix) => path === prefix || path.startsWith(prefix.endsWith("/") ? prefix : `${prefix}/`));
}

export default auth((req) => {
  const { nextUrl } = req;
  const path = nextUrl.pathname;
  const isApi = path.startsWith("/api/");
  const user = req.auth?.user ?? null;
  const isLoggedIn = Boolean(user?.id);

  // Root routing
  if (path === "/") {
    return NextResponse.redirect(new URL(isLoggedIn ? "/dashboard" : "/login", nextUrl));
  }

  const isPublicPage = isPublic(PUBLIC_PAGE_PREFIXES, path);
  const isPublicApi = isPublic(PUBLIC_API_PREFIXES, path);

  if (isPublicPage) {
    if (isLoggedIn && path === "/login") {
      return withCsrfCookie(req, NextResponse.redirect(new URL("/dashboard", nextUrl)));
    }
    return withCsrfCookie(req, NextResponse.next());
  }

  if (isPublicApi) {
    return withCsrfCookie(req, NextResponse.next());
  }

  if (!isLoggedIn) {
    if (isApi) {
      return withCsrfCookie(
        req,
        NextResponse.json({ error: "unauthorized", message: "Authentication required" }, { status: 401 }),
      );
    }
    const loginUrl = new URL("/login", nextUrl);
    loginUrl.searchParams.set("callbackUrl", path + nextUrl.search);
    return NextResponse.redirect(loginUrl);
  }

  // App-level session lifetime: 8 hours unless "remember me", then 30 days.
  const authAt = req.auth?.authAt;
  if (typeof authAt === "number") {
    const limit = req.auth?.remember ? REMEMBER_SESSION_MS : SHORT_SESSION_MS;
    if (Date.now() - authAt > limit) {
      if (isApi) {
        return NextResponse.json({ error: "session_expired", message: "Session expired" }, { status: 401 });
      }
      return NextResponse.redirect(new URL("/login?expired=1", nextUrl));
    }
  }

  // Forced password change before anything else.
  const changePath = path === "/change-password";
  if (user?.mustChangePassword && !changePath && path !== "/api/auth/change-password") {
    if (isApi) {
      return NextResponse.json({ error: "password_change_required", message: "Password change required" }, { status: 403 });
    }
    return NextResponse.redirect(new URL("/change-password", nextUrl));
  }
  if (!user?.mustChangePassword && changePath) {
    return NextResponse.redirect(new URL("/dashboard", nextUrl));
  }

  // Coarse role gating. Fine-grained ownership is enforced in every handler.
  const rule = ROLE_RULES.filter((r) => isPublic([r.prefix], path)).sort(
    (a, b) => b.prefix.length - a.prefix.length,
  )[0];
  if (rule && user && !rule.roles.includes(user.role)) {
    if (isApi) {
      return NextResponse.json({ error: "forbidden", message: "Insufficient permissions" }, { status: 403 });
    }
    return NextResponse.redirect(new URL("/forbidden", nextUrl));
  }

  // CSRF double-submit check for every mutating API call.
  if (isApi && !["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    const cookieToken = req.cookies.get(CSRF_COOKIE)?.value;
    const headerToken = req.headers.get("x-csrf-token");
    if (cookieToken && headerToken !== cookieToken) {
      return NextResponse.json({ error: "csrf_failed", message: "Invalid CSRF token" }, { status: 403 });
    }
    const origin = req.headers.get("origin");
    if (origin) {
      try {
        if (new URL(origin).host !== req.headers.get("host")) {
          return NextResponse.json({ error: "origin_mismatch", message: "Cross-origin request blocked" }, { status: 403 });
        }
      } catch {
        return NextResponse.json({ error: "origin_mismatch", message: "Invalid origin" }, { status: 403 });
      }
    }
  }

  return withCsrfCookie(req, NextResponse.next());
});

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|css|js|woff2?)$).*)",
  ],
};
