import NextAuth, { CredentialsSignin } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { compare } from "bcryptjs";
import { headers } from "next/headers";
import { z } from "zod";
import { authConfig } from "./auth.config";
import { prisma } from "./lib/prisma";
import { clientIp, rateLimit } from "./lib/rate-limit";
import { logActivity } from "./lib/activity";
import { asRole } from "./lib/rbac";

const credentialsSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  remember: z.union([z.boolean(), z.string()]).optional(),
});

class RateLimitedError extends CredentialsSignin {
  code = "rate_limited";
}

class AccountDisabledError extends CredentialsSignin {
  code = "account_disabled";
}

export const { handlers, auth, signIn, signOut } = NextAuth({
  ...authConfig,
  providers: [
    Credentials({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
        remember: { label: "Remember me", type: "text" },
      },
      async authorize(raw) {
        const parsed = credentialsSchema.safeParse(raw);
        if (!parsed.success) return null;

        const email = parsed.data.email.trim().toLowerCase();
        const remember = parsed.data.remember === true || parsed.data.remember === "true";

        let ip = "unknown";
        let userAgent: string | null = null;
        try {
          const h = await headers();
          ip = clientIp(h);
          userAgent = h.get("user-agent");
        } catch {
          /* headers unavailable */
        }

        // 5 attempts / 15 minutes per IP + email.
        const limit = rateLimit(`login:${ip}:${email}`, 5, 15 * 60 * 1000);
        if (!limit.ok) {
          await logActivity({
            userEmail: email,
            action: "LOGIN_FAILED",
            entityType: "User",
            description: `Rate-limited sign-in attempt for ${email}`,
            metadata: { reason: "rate_limited", retryAfterSeconds: limit.retryAfterSeconds },
            ip,
            userAgent,
          });
          throw new RateLimitedError();
        }

        const user = await prisma.user.findUnique({ where: { email } });
        if (!user) {
          await logActivity({
            userEmail: email,
            action: "LOGIN_FAILED",
            entityType: "User",
            description: `Failed sign-in for unknown email ${email}`,
            metadata: { reason: "unknown_user" },
            ip,
            userAgent,
          });
          return null;
        }

        if (!user.isActive) {
          await logActivity({
            userId: user.id,
            userEmail: user.email,
            action: "LOGIN_FAILED",
            entityType: "User",
            entityId: user.id,
            description: `Sign-in blocked for deactivated account ${email}`,
            metadata: { reason: "inactive" },
            ip,
            userAgent,
          });
          throw new AccountDisabledError();
        }

        const valid = await compare(parsed.data.password, user.passwordHash);
        if (!valid) {
          await logActivity({
            userId: user.id,
            userEmail: user.email,
            action: "LOGIN_FAILED",
            entityType: "User",
            entityId: user.id,
            description: `Incorrect password for ${email}`,
            metadata: { reason: "bad_password" },
            ip,
            userAgent,
          });
          return null;
        }

        await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
        await logActivity({
          userId: user.id,
          userEmail: user.email,
          action: "LOGIN",
          entityType: "User",
          entityId: user.id,
          description: `${user.name} signed in`,
          metadata: { remember },
          ip,
          userAgent,
        });

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          image: user.avatarUrl,
          role: asRole(user.role),
          managerId: user.managerId,
          mustChangePassword: user.mustChangePassword,
          locale: user.locale,
          remember,
        };
      },
    }),
  ],
});
