import type { DefaultSession } from "next-auth";
import type { Role } from "@/lib/rbac";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: Role;
      managerId?: string | null;
      mustChangePassword: boolean;
      locale: string;
    } & DefaultSession["user"];
    authAt?: number;
    remember?: boolean;
  }

  interface User {
    role?: Role;
    managerId?: string | null;
    mustChangePassword?: boolean;
    locale?: string;
    remember?: boolean;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id?: string;
    role?: Role;
    managerId?: string | null;
    mustChangePassword?: boolean;
    locale?: string;
    remember?: boolean;
    authAt?: number;
  }
}
