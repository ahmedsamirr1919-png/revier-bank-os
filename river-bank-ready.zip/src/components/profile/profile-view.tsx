"use client";

import { useEffect, useState } from "react";
import { KeyRound, Loader2, Save, UserRound } from "lucide-react";
import { toast } from "sonner";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { formatDate } from "@/lib/utils";

type Profile = {
  id: string;
  name: string;
  email: string;
  role: string;
  phone: string | null;
  locale: string;
  isActive: boolean;
  mustChangePassword: boolean;
  manager: { name: string; email: string } | null;
  createdAt: string;
  lastLoginAt: string | null;
};

export function ProfileView() {
  const { t, locale, setLocale, enumLabel } = useI18n();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", locale: "en" });

  useEffect(() => {
    api
      .get<Profile>("/api/profile")
      .then((data) => {
        setProfile(data);
        setForm({
          name: data.name,
          email: data.email,
          phone: data.phone ?? "",
          locale: data.locale,
        });
      })
      .catch(() => toast.error(t("toast.error")))
      .finally(() => setLoading(false));
  }, [t]);

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    try {
      const updated = await api.patch<Profile>("/api/profile", {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        locale: form.locale,
      });
      setProfile((current) => (current ? { ...current, ...updated } : current));
      if (form.locale !== locale) setLocale(form.locale as "en" | "ar");
      toast.success(t("toast.saved"));
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setSaving(false);
    }
  };

  if (loading || !profile) {
    return (
      <div className="flex items-center justify-center py-16 text-muted-foreground">
        <Loader2 className="mr-2 animate-spin" />
        {t("common.loading")}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold tracking-tight md:text-2xl">{t("profile.title")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("profile.subtitle")}</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <UserRound className="size-4 text-primary" />
              {t("profile.account")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div>
              <p className="text-xs text-muted-foreground">{t("users.name")}</p>
              <p className="font-medium">{profile.name}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{t("users.email")}</p>
              <p className="font-medium" dir="ltr">
                {profile.email}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{t("users.role")}</p>
              <p className="font-medium">{enumLabel("roles", profile.role)}</p>
            </div>
            {profile.manager && (
              <div>
                <p className="text-xs text-muted-foreground">{t("users.manager")}</p>
                <p className="font-medium">{profile.manager.name}</p>
              </div>
            )}
            <div>
              <p className="text-xs text-muted-foreground">{t("profile.memberSince")}</p>
              <p className="font-medium">{formatDate(profile.createdAt, locale)}</p>
            </div>
            {profile.lastLoginAt && (
              <div>
                <p className="text-xs text-muted-foreground">{t("profile.lastLogin")}</p>
                <p className="font-medium">{formatDate(profile.lastLoginAt, locale, true)}</p>
              </div>
            )}
            {profile.mustChangePassword && (
              <p className="rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs text-amber-700 dark:text-amber-400">
                {t("auth.mustChangePassword")}
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("profile.edit")}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={save} className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>{t("users.name")}</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div className="space-y-1.5">
                <Label>{t("users.email")}</Label>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
              </div>
              <div className="space-y-1.5">
                <Label>{t("users.phone")}</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>{t("settings.language")}</Label>
                <Select value={form.locale} onValueChange={(value) => setForm({ ...form, locale: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ar">العربية</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="sm:col-span-2">
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="animate-spin" />}
                  <Save />
                  {t("common.save")}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <KeyRound className="size-4 text-primary" />
            {t("auth.changePasswordTitle")}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-muted-foreground">{t("auth.changePasswordSubtitle")}</p>
          <Button variant="outline" size="sm" asChild>
            <Link href="/change-password">{t("auth.updatePassword")}</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}


