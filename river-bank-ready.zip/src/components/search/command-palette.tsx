"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Command, Search, X } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { cn } from "@/lib/utils";

type Result = {
  entityType: string;
  entityId: string;
  title: string;
  subtitle: string | null;
};

const MODULE_ROUTES: Record<string, (id: string) => string> = {
  customer: (id) => `/customers/${id}`,
  property: (id) => `/properties/${id}`,
  deal: (id) => `/deals/${id}`,
  task: (id) => `/tasks/${id}`,
  feedback: (id) => `/feedback/${id}`,
};

export function CommandPalette() {
  const { t } = useI18n();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setOpen(true);
      }
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const search = useCallback(
    async (value: string) => {
      if (!value.trim()) {
        setResults([]);
        return;
      }
      setLoading(true);
      try {
        const data = await api.get<{ results: Result[] }>(`/api/search?q=${encodeURIComponent(value)}&limit=24`);
        setResults(data.results);
      } catch {
        setResults([]);
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      search(query);
    }, 250);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [query, search]);

  useEffect(() => {
    setActiveIndex(0);
  }, [results]);

  const grouped = results.reduce<Record<string, Result[]>>((acc, item) => {
    (acc[item.entityType] ??= []).push(item);
    return acc;
  }, {});

  const openResult = (result: Result) => {
    const route = MODULE_ROUTES[result.entityType]?.(result.entityId);
    if (route) router.push(route);
    setOpen(false);
    setQuery("");
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="hidden items-center gap-2 rounded-lg border border-input bg-background px-3 py-1.5 text-xs text-muted-foreground transition hover:bg-accent md:flex"
      >
        <Search className="size-3.5" />
        <span>{t("search.placeholder")}</span>
        <kbd className="ml-2 rounded border bg-muted px-1.5 py-0.5 text-[10px] font-medium">Ctrl K</kbd>
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl p-0">
          <div className="flex items-center gap-2 border-b px-3 py-2">
            <Search className="size-4 text-muted-foreground" />
            <Input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  setActiveIndex((i) => Math.min(i + 1, results.length - 1));
                } else if (e.key === "ArrowUp") {
                  e.preventDefault();
                  setActiveIndex((i) => Math.max(i - 1, 0));
                } else if (e.key === "Enter") {
                  e.preventDefault();
                  const item = results[activeIndex];
                  if (item) openResult(item);
                }
              }}
              placeholder={t("search.placeholder")}
              className="border-0 shadow-none focus-visible:ring-0"
            />
            {loading && <span className="text-xs text-muted-foreground">…</span>}
            <button type="button" onClick={() => setOpen(false)} className="text-muted-foreground">
              <X className="size-4" />
            </button>
          </div>
          <div className="max-h-[60vh] overflow-y-auto p-2">
            {Object.keys(grouped).length === 0 && !loading && (
              <p className="py-8 text-center text-sm text-muted-foreground">{t("search.noResults")}</p>
            )}
            {Object.entries(grouped).map(([module, items]) => (
              <div key={module} className="mb-3">
                <p className="px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                  {t(`nav.${module === "customer" ? "customers" : module === "property" ? "properties" : module === "deal" ? "deals" : module === "task" ? "tasks" : module === "feedback" ? "feedback" : module}`)}
                </p>
                <ul className="space-y-1">
                  {items.map((item, index) => (
                    <li key={`${item.entityType}-${item.entityId}`}>
                      <button
                        type="button"
                        onClick={() => openResult(item)}
                        className={cn(
                          "flex w-full items-center justify-between rounded-lg px-2 py-2 text-start text-sm transition",
                          index === activeIndex ? "bg-accent" : "hover:bg-accent",
                        )}
                      >
                        <span className="font-medium">{item.title}</span>
                        {item.subtitle && <span className="text-xs text-muted-foreground">{item.subtitle}</span>}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
