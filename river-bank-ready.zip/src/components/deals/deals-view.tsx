"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  Building2,
  CalendarDays,
  Eye,
  Handshake,
  LayoutGrid,
  List,
  Loader2,
  MoreHorizontal,
  Pencil,
  RotateCcw,
  Trash2,
  User as UserIcon,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { SearchInput } from "@/components/shared/search-input";
import { Pagination } from "@/components/shared/pagination";
import { EmptyState } from "@/components/shared/empty-state";
import { StatusBadge } from "@/components/shared/status-badge";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { DEAL_STAGE_COLORS, DEAL_STAGES } from "@/lib/constants";
import { cn, formatCurrency, formatDate } from "@/lib/utils";
import type { AgentOption, DealFilters, DealListItem } from "./types";

export function DealsView({
  items,
  total,
  page,
  pageSize,
  pages,
  filters,
  agents,
  canRestore,
}: {
  items: DealListItem[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
  filters: DealFilters;
  agents: AgentOption[];
  canRestore: boolean;
}) {
  const { t, enumLabel, locale } = useI18n();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [view, setView] = useState<"board" | "table">("board");
  const [deleteTarget, setDeleteTarget] = useState<DealListItem | null>(null);
  const [pending, setPending] = useState(false);

  const setFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value && value !== "all") params.set(key, value);
    else params.delete(key);
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  };

  const remove = async () => {
    if (!deleteTarget) return;
    setPending(true);
    try {
      await api.delete(`/api/deals/${deleteTarget.id}`);
      toast.success(t("toast.deleted"));
      setDeleteTarget(null);
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const restore = async (deal: DealListItem) => {
    try {
      await api.post(`/api/deals/${deal.id}/restore`);
      toast.success(t("common.saved"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    }
  };

  const effectiveView = filters.trash === "1" ? "table" : view;

  const actions = (deal: DealListItem) => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon-sm" aria-label={t("common.actions")}>
          <MoreHorizontal />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="text-xs">{deal.code}</DropdownMenuLabel>
        <DropdownMenuItem asChild>
          <Link href={`/deals/${deal.id}`}>
            <Eye />
            {t("common.view")}
          </Link>
        </DropdownMenuItem>
        {!deal.isDeleted && (
          <DropdownMenuItem asChild>
            <Link href={`/deals/${deal.id}/edit`}>
              <Pencil />
              {t("common.edit")}
            </Link>
          </DropdownMenuItem>
        )}
        {deal.isDeleted && canRestore && (
          <DropdownMenuItem onSelect={() => void restore(deal)}>
            <RotateCcw />
            {t("customers.restore")}
          </DropdownMenuItem>
        )}
        {!deal.isDeleted && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-destructive focus:text-destructive"
              onSelect={() => setDeleteTarget(deal)}
            >
              <Trash2 />
              {t("common.delete")}
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );

  return (
    <>
      <Card className="overflow-hidden">
        <div className="flex flex-col gap-3 border-b p-4 lg:flex-row lg:items-center lg:justify-between">
          <SearchInput placeholder={t("deals.searchPlaceholder")} className="w-full lg:max-w-sm" />
          <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:items-center">
            <Select value={filters.stage || "all"} onValueChange={(value) => setFilter("stage", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("deals.filterStage")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {DEAL_STAGES.map((stage) => (
                  <SelectItem key={stage} value={stage}>
                    {enumLabel("dealStage", stage)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.agentId || "all"} onValueChange={(value) => setFilter("agentId", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("deals.agent")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {agents.map((agent) => (
                  <SelectItem key={agent.id} value={agent.id}>
                    {agent.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.sort} onValueChange={(value) => setFilter("sort", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("common.sortBy")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">{t("common.newest")}</SelectItem>
                <SelectItem value="oldest">{t("common.oldest")}</SelectItem>
                <SelectItem value="value_desc">{t("deals.value")} ↓</SelectItem>
                <SelectItem value="value_asc">{t("deals.value")} ↑</SelectItem>
                <SelectItem value="expected">{t("deals.expectedClose")}</SelectItem>
              </SelectContent>
            </Select>

            {filters.trash !== "1" && (
              <div className="col-span-2 flex items-center rounded-md border p-0.5 sm:col-span-1">
                <Button
                  type="button"
                  variant={view === "board" ? "secondary" : "ghost"}
                  size="icon-sm"
                  onClick={() => setView("board")}
                  aria-label={t("deals.board")}
                  title={t("deals.board")}
                >
                  <LayoutGrid />
                </Button>
                <Button
                  type="button"
                  variant={view === "table" ? "secondary" : "ghost"}
                  size="icon-sm"
                  onClick={() => setView("table")}
                  aria-label={t("deals.table")}
                  title={t("deals.table")}
                >
                  <List />
                </Button>
              </div>
            )}
          </div>
        </div>

        {items.length === 0 ? (
          <EmptyState
            icon={Handshake}
            title={t("deals.noDeals")}
            description={t("common.noResultsHint")}
            action={
              filters.trash !== "1" ? (
                <Button size="sm" asChild>
                  <Link href="/deals/new">{t("deals.new")}</Link>
                </Button>
              ) : undefined
            }
          />
        ) : effectiveView === "board" ? (
          <div className="flex gap-3 overflow-x-auto p-4">
            {DEAL_STAGES.map((stage) => {
              const stageDeals = items.filter((deal) => deal.stage === stage);
              return (
                <section key={stage} className="flex w-[270px] shrink-0 flex-col rounded-xl bg-muted/40">
                  <header className="flex items-center justify-between gap-2 border-b px-3 py-2.5">
                    <div className="flex min-w-0 items-center gap-2">
                      <span
                        className="size-2 shrink-0 rounded-full"
                        style={{ backgroundColor: DEAL_STAGE_COLORS[stage] ?? "#64748b" }}
                      />
                      <h3 className="truncate text-xs font-semibold">{enumLabel("dealStage", stage)}</h3>
                    </div>
                    <span className="rounded-full bg-background px-1.5 text-[11px] text-muted-foreground">
                      {stageDeals.length}
                    </span>
                  </header>
                  <div className="flex flex-1 flex-col gap-2 p-2">
                    {stageDeals.length === 0 ? (
                      <p className="px-2 py-4 text-center text-[11px] text-muted-foreground">
                        {t("common.noData")}
                      </p>
                    ) : (
                      stageDeals.map((deal) => (
                        <article
                          key={deal.id}
                          className="rounded-lg border bg-card p-3 shadow-sm transition-shadow hover:shadow-md"
                        >
                          <div className="flex items-start justify-between gap-1">
                            <Link
                              href={`/deals/${deal.id}`}
                              className="line-clamp-2 text-sm font-medium hover:underline"
                            >
                              {deal.title}
                            </Link>
                            {actions(deal)}
                          </div>
                          <p className="mt-0.5 text-[11px] text-muted-foreground">{deal.code}</p>
                          <p className="mt-2 text-sm font-semibold text-primary" dir="ltr">
                            {formatCurrency(deal.value, locale)}
                          </p>
                          <div className="mt-2 space-y-1 text-[11px] text-muted-foreground">
                            <p className="flex items-center gap-1.5">
                              <UserIcon className="size-3 shrink-0" />
                              <span className="truncate">{deal.customer.fullName}</span>
                            </p>
                            {deal.property && (
                              <p className="flex items-center gap-1.5">
                                <Building2 className="size-3 shrink-0" />
                                <span className="truncate">{deal.property.title}</span>
                              </p>
                            )}
                            <p className="flex items-center gap-1.5">
                              <CalendarDays className="size-3 shrink-0" />
                              <span>{formatDate(deal.expectedCloseDate, locale)}</span>
                            </p>
                          </div>
                          <div className="mt-2 flex items-center justify-between border-t pt-2 text-[10px] text-muted-foreground">
                            <span className="truncate">{deal.agent.name}</span>
                            <span>{deal.probability}%</span>
                          </div>
                        </article>
                      ))
                    )}
                  </div>
                </section>
              );
            })}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("deals.titleField")}</TableHead>
                  <TableHead>{t("deals.customer")}</TableHead>
                  <TableHead>{t("deals.stage")}</TableHead>
                  <TableHead>{t("deals.value")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("deals.expectedClose")}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t("deals.agent")}</TableHead>
                  <TableHead className="hidden xl:table-cell">{t("customers.tasks")}</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((deal) => (
                  <TableRow key={deal.id} className={cn(deal.isDeleted && "opacity-70")}>
                    <TableCell>
                      <Link href={`/deals/${deal.id}`} className="font-medium hover:underline">
                        {deal.title}
                      </Link>
                      <span className="block text-xs text-muted-foreground">{deal.code}</span>
                    </TableCell>
                    <TableCell>
                      <Link
                        href={`/customers/${deal.customer.id}`}
                        className="text-sm hover:underline"
                      >
                        {deal.customer.fullName}
                      </Link>
                      <span className="block text-xs text-muted-foreground" dir="ltr">
                        {deal.customer.phone}
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge value={deal.stage} group="dealStage" />
                    </TableCell>
                    <TableCell dir="ltr" className="font-medium">
                      {formatCurrency(deal.value, locale)}
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-muted-foreground">
                      {formatDate(deal.expectedCloseDate, locale)}
                    </TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">
                      {deal.agent.name}
                    </TableCell>
                    <TableCell className="hidden xl:table-cell text-muted-foreground">
                      {deal._count.tasks}
                    </TableCell>
                    <TableCell className="text-end">{actions(deal)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        <Pagination page={page} pages={pages} total={total} pageSize={pageSize} />
      </Card>

      <AlertDialog open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("deals.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("deals.deleteBody")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={remove} disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
