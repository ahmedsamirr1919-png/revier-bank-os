export type AgentOption = {
  id: string;
  name: string;
  email: string;
  role: string;
};

export type CustomerOption = {
  id: string;
  code: string;
  fullName: string;
  phone: string;
  status: string;
  assignedAgentId?: string | null;
};

export type PropertyOption = {
  id: string;
  code: string;
  title: string;
  price: number;
  status: string;
};

export type DealListItem = {
  id: string;
  code: string;
  title: string;
  value: number;
  currency: string;
  stage: string;
  probability: number;
  expectedCloseDate: Date | string | null;
  closedAt: Date | string | null;
  isDeleted: boolean;
  createdAt: Date | string;
  customer: { id: string; code: string; fullName: string; phone: string };
  property: { id: string; code: string; title: string } | null;
  agent: { id: string; name: string };
  _count: { tasks: number; stageHistory: number };
};

export type DealFilters = {
  q: string;
  stage: string;
  agentId: string;
  sort: string;
  trash: string;
};

export type DealFormValues = Partial<{
  id: string;
  title: string;
  customerId: string;
  propertyId: string | null;
  agentId: string;
  value: number;
  currency: string;
  commissionRate: number;
  probability: number;
  expectedCloseDate: Date | string | null;
  stage: string;
  lostReason: string | null;
  notes: string | null;
}>;
