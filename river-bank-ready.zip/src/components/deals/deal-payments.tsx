"use client";

import { useEffect, useState } from "react";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { formatCurrency } from "@/lib/utils";

type Payment = {
  id: string;
  amount: number;
  currency: string;
  method: string;
  status: string;
  paidAt: string;
  dueAt: string | null;
  notes: string | null;
  createdBy: { id: string; name: string } | null;
};

export function DealPayments({ dealId }: { dealId: string }) {
  const { t, locale } = useI18n();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    amount: "",
    method: "BANK_TRANSFER",
    status: "PAID",
    notes: "",
  });

  const load = async () => {
    setLoading(true);
    try {
      const data = await api.get<Payment[]>(`/api/deals/${dealId}/payments`);
      setPayments(data);
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [dealId]);

  const totalPaid = payments
    .filter((p) => p.status === "PAID")
    .reduce((sum, p) => sum + p.amount, 0);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    try {
      await api.post(`/api/deals/${dealId}/payments`, {
        amount: Number(form.amount),
        method: form.method,
        status: form.status,
        notes: form.notes || null,
      });
      toast.success(t("toast.created"));
      setShowForm(false);
      setForm({ amount: "", method: "BANK_TRANSFER", status: "PAID", notes: "" });
      load();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-2">
        <CardTitle className="text-base">{t("payments.title")}</CardTitle>
        <Button size="sm" variant="outline" onClick={() => setShowForm((v) => !v)}>
          <Plus />
          {t("payments.record")}
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-muted-foreground">
          {t("payments.totalPaid")}: <span className="font-medium text-foreground">{formatCurrency(totalPaid, locale, true)}</span>
        </div>

        {showForm && (
          <form onSubmit={submit} className="grid gap-3 rounded-lg border p-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>{t("payments.amount")}</Label>
              <Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} required />
            </div>
            <div className="space-y-1.5">
              <Label>{t("payments.method")}</Label>
              <select
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={form.method}
                onChange={(e) => setForm({ ...form, method: e.target.value })}
              >
                <option value="CASH">{t("payments.methods.CASH")}</option>
                <option value="BANK_TRANSFER">{t("payments.methods.BANK_TRANSFER")}</option>
                <option value="CARD">{t("payments.methods.CARD")}</option>
                <option value="CHEQUE">{t("payments.methods.CHEQUE")}</option>
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>{t("payments.status")}</Label>
              <select
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
              >
                <option value="PAID">{t("payments.statuses.PAID")}</option>
                <option value="PENDING">{t("payments.statuses.PENDING")}</option>
                <option value="OVERDUE">{t("payments.statuses.OVERDUE")}</option>
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>{t("payments.notes")}</Label>
              <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <Button type="submit" size="sm" disabled={saving}>
                {saving && <Loader2 className="animate-spin" />}
                {t("common.save")}
              </Button>
            </div>
          </form>
        )}

        {loading ? (
          <Loader2 className="animate-spin" />
        ) : payments.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("payments.empty")}</p>
        ) : (
          <ul className="divide-y">
            {payments.map((payment) => (
              <li key={payment.id} className="flex items-center justify-between py-2 text-sm">
                <div>
                  <p className="font-medium">{formatCurrency(payment.amount, locale, true)}</p>
                  <p className="text-xs text-muted-foreground">
                    {t(`payments.methods.${payment.method}`)} · {t(`payments.statuses.${payment.status}`)} · {new Date(payment.paidAt).toLocaleDateString(locale === "ar" ? "ar-AE" : "en-GB")}
                  </p>
                  {payment.notes && <p className="text-xs text-muted-foreground">{payment.notes}</p>}
                </div>
                <Button
                  size="icon-sm"
                  variant="ghost"
                  onClick={async () => {
                    try {
                      await api.delete(`/api/deals/${dealId}/payments/${payment.id}`);
                      toast.success(t("toast.deleted"));
                      load();
                    } catch {
                      toast.error(t("toast.error"));
                    }
                  }}
                >
                  <Trash2 />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
