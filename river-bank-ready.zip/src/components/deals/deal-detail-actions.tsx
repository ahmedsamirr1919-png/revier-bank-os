"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { GitBranch, Loader2, Pencil, RotateCcw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { DealStageDialog } from "./deal-stage-dialog";

export function DealDetailActions({
  deal,
  canRestore,
  isDeleted,
}: {
  deal: { id: string; stage: string };
  canRestore: boolean;
  isDeleted: boolean;
}) {
  const { t } = useI18n();
  const router = useRouter();
  const [stageOpen, setStageOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [pending, setPending] = useState(false);

  const remove = async () => {
    setPending(true);
    try {
      await api.delete(`/api/deals/${deal.id}`);
      toast.success(t("toast.deleted"));
      setDeleteOpen(false);
      router.push("/deals");
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const restore = async () => {
    setPending(true);
    try {
      await api.post(`/api/deals/${deal.id}/restore`);
      toast.success(t("common.saved"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  if (isDeleted) {
    return canRestore ? (
      <Button variant="outline" size="sm" onClick={restore} disabled={pending}>
        {pending ? <Loader2 className="animate-spin" /> : <RotateCcw />}
        {t("customers.restore")}
      </Button>
    ) : null;
  }

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setStageOpen(true)}>
        <GitBranch />
        {t("deals.changeStage")}
      </Button>
      <Button variant="outline" size="sm" asChild>
        <Link href={`/deals/${deal.id}/edit`}>
          <Pencil />
          {t("common.edit")}
        </Link>
      </Button>
      <Button
        variant="outline"
        size="sm"
        className="text-destructive hover:text-destructive"
        onClick={() => setDeleteOpen(true)}
      >
        <Trash2 />
        {t("common.delete")}
      </Button>

      <DealStageDialog
        open={stageOpen}
        onOpenChange={setStageOpen}
        dealId={deal.id}
        currentStage={deal.stage}
        onChanged={() => router.refresh()}
      />

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("deals.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("deals.deleteBody")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={remove} disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
