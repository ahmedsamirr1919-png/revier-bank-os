"use client";

import { useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { DEAL_STAGES } from "@/lib/constants";

export function DealStageDialog({
  open,
  onOpenChange,
  dealId,
  currentStage,
  onChanged,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dealId: string;
  currentStage: string;
  onChanged?: () => void;
}) {
  const { t, enumLabel } = useI18n();
  const [stage, setStage] = useState(currentStage);
  const [note, setNote] = useState("");
  const [lostReason, setLostReason] = useState("");
  const [pending, setPending] = useState(false);

  const submit = async () => {
    setPending(true);
    try {
      await api.patch(`/api/deals/${dealId}/stage`, {
        stage,
        note: note || null,
        lostReason: stage === "CLOSED_LOST" ? lostReason || null : null,
      });
      toast.success(t("deals.stageChanged"));
      onOpenChange(false);
      onChanged?.();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{t("deals.changeStage")}</DialogTitle>
          <DialogDescription>{t("deals.progress")}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label className="mb-1.5 block">{t("deals.stage")}</Label>
            <Select value={stage} onValueChange={setStage}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DEAL_STAGES.map((item) => (
                  <SelectItem key={item} value={item}>
                    {enumLabel("dealStage", item)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {stage === "CLOSED_LOST" && (
            <div>
              <Label className="mb-1.5 block">{t("deals.setLostReason")}</Label>
              <Input
                value={lostReason}
                onChange={(event) => setLostReason(event.target.value)}
                placeholder={t("deals.lostReasonPlaceholder")}
                maxLength={500}
              />
            </div>
          )}

          <div>
            <Label className="mb-1.5 block">{t("common.notes")}</Label>
            <Input
              value={note}
              onChange={(event) => setNote(event.target.value)}
              maxLength={300}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>
            {t("common.cancel")}
          </Button>
          <Button onClick={submit} disabled={pending || stage === currentStage}>
            {pending && <Loader2 className="animate-spin" />}
            {t("common.save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
