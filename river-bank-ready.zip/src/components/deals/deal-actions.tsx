"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Plus, Trash2, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/components/locale-provider";

export function DealActions({ canRestore, trash }: { canRestore: boolean; trash: boolean }) {
  const { t } = useI18n();
  const router = useRouter();

  return (
    <>
      {canRestore && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const params = new URLSearchParams();
            if (!trash) params.set("trash", "1");
            router.push(`/deals${params.size ? `?${params.toString()}` : ""}`);
          }}
        >
          {trash ? <Undo2 /> : <Trash2 />}
          {trash ? t("deals.title") : t("customers.trash")}
        </Button>
      )}

      {!trash && (
        <Button size="sm" asChild>
          <Link href="/deals/new">
            <Plus />
            {t("deals.new")}
          </Link>
        </Button>
      )}
    </>
  );
}
