"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api, fieldErrors } from "@/lib/client-api";
import { DEAL_STAGES } from "@/lib/constants";
import { SearchableSelect } from "@/components/shared/searchable-select";
import { formatCurrency } from "@/lib/utils";
import type { AgentOption, CustomerOption, DealFormValues, PropertyOption } from "./types";

type FormState = {
  title: string;
  customerId: string;
  propertyId: string;
  agentId: string;
  value: string;
  commissionRate: string;
  probability: string;
  expectedCloseDate: string;
  stage: string;
  lostReason: string;
  notes: string;
};

function toDateInput(value: Date | string | null | undefined) {
  if (!value) return "";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "";
  const pad = (part: number) => String(part).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function DealForm({
  mode,
  deal,
  customers,
  properties,
  agents,
  canAssignAgent,
  initialCustomerId,
  initialPropertyId,
}: {
  mode: "create" | "edit";
  deal?: DealFormValues;
  customers: CustomerOption[];
  properties: PropertyOption[];
  agents: AgentOption[];
  canAssignAgent: boolean;
  initialCustomerId?: string;
  initialPropertyId?: string;
}) {
  const { t, enumLabel, locale } = useI18n();
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [form, setForm] = useState<FormState>({
    title: deal?.title ?? "",
    customerId: deal?.customerId ?? initialCustomerId ?? "",
    propertyId: deal?.propertyId ?? initialPropertyId ?? "",
    agentId: deal?.agentId ?? "",
    value: deal?.value ? String(deal.value) : "",
    commissionRate:
      deal?.commissionRate !== undefined && deal?.commissionRate !== null
        ? String(deal.commissionRate)
        : "2.5",
    probability:
      deal?.probability !== undefined && deal?.probability !== null ? String(deal.probability) : "20",
    expectedCloseDate: toDateInput(deal?.expectedCloseDate),
    stage: deal?.stage ?? "PROSPECTING",
    lostReason: deal?.lostReason ?? "",
    notes: deal?.notes ?? "",
  });

  const set = (key: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    if (errors[key]?.length) setErrors((current) => ({ ...current, [key]: [] }));
  };

  const errorFor = (key: string) => errors[key]?.[0];
  const commission =
    Number(form.value || 0) > 0 && Number(form.commissionRate || 0) >= 0
      ? Math.round((Number(form.value) * Number(form.commissionRate)) / 100)
      : 0;

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setPending(true);
    setErrors({});
    try {
      const payload = {
        title: form.title,
        customerId: form.customerId,
        propertyId: form.propertyId || null,
        agentId: form.agentId || null,
        value: form.value,
        currency: "EGP",
        commissionRate: form.commissionRate || "2.5",
        probability: form.probability || "20",
        expectedCloseDate: form.expectedCloseDate || null,
        stage: form.stage,
        lostReason: form.stage === "CLOSED_LOST" ? form.lostReason || null : null,
        notes: form.notes || null,
      };

      if (mode === "create") {
        const created = await api.post<{ id: string }>("/api/deals", payload);
        toast.success(t("toast.created"));
        router.push(`/deals/${created.id}`);
      } else if (deal?.id) {
        await api.patch(`/api/deals/${deal.id}`, payload);
        toast.success(t("toast.updated"));
        router.push(`/deals/${deal.id}`);
      }
      router.refresh();
    } catch (error) {
      const fields = fieldErrors(error);
      if (fields) setErrors(fields);
      toast.error(fields ? t("common.requiredField") : t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const backHref = deal?.id ? `/deals/${deal.id}` : "/deals";

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href={backHref}>
            <ArrowLeft className="rtl:rotate-180" />
            {t("common.back")}
          </Link>
        </Button>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("deals.details")}</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <Field label={t("deals.titleField")} required error={errorFor("title")} className="sm:col-span-2">
              <Input
                value={form.title}
                onChange={(event) => set("title", event.target.value)}
                required
                maxLength={160}
                autoFocus
              />
            </Field>

            <Field label={t("deals.customer")} required error={errorFor("customerId")}>
              <SearchableSelect
                value={form.customerId}
                onChange={(value) => set("customerId", value)}
                options={customers.map((customer) => ({
                  id: customer.id,
                  label: `${customer.fullName} · ${customer.code}`,
                  sub: customer.phone,
                }))}
                placeholder={t("deals.selectCustomer")}
                searchPlaceholder={t("customers.searchPlaceholder")}
                emptyLabel={t("common.noResults")}
              />
            </Field>

            <Field label={t("deals.property")} error={errorFor("propertyId")}>
              <SearchableSelect
                value={form.propertyId}
                onChange={(value) => set("propertyId", value)}
                options={properties.map((property) => ({
                  id: property.id,
                  label: `${property.title} · ${property.code}`,
                  sub: `${property.status} · ${formatCurrency(property.price, locale)}`,
                }))}
                placeholder={t("deals.selectProperty")}
                searchPlaceholder={t("properties.searchPlaceholder")}
                emptyLabel={t("common.noResults")}
                allowNone
                noneLabel={t("common.none")}
              />
            </Field>

            {canAssignAgent && (
              <Field label={t("deals.agent")} error={errorFor("agentId")}>
                <Select
                  value={form.agentId || "self"}
                  onValueChange={(value) => set("agentId", value === "self" ? "" : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("deals.selectAgent")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="self">{t("common.unassigned")}</SelectItem>
                    {agents.map((agent) => (
                      <SelectItem key={agent.id} value={agent.id}>
                        {agent.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            )}

            <Field label={t("deals.value")} required error={errorFor("value")}>
              <Input
                type="number"
                min={1}
                step={1}
                value={form.value}
                onChange={(event) => set("value", event.target.value)}
                required
                dir="ltr"
              />
            </Field>

            <Field label={t("deals.commissionRate")} error={errorFor("commissionRate")}>
              <Input
                type="number"
                min={0}
                max={100}
                step="0.1"
                value={form.commissionRate}
                onChange={(event) => set("commissionRate", event.target.value)}
                dir="ltr"
              />
            </Field>

            <Field label={t("deals.probability")} error={errorFor("probability")}>
              <Input
                type="number"
                min={0}
                max={100}
                step={1}
                value={form.probability}
                onChange={(event) => set("probability", event.target.value)}
                dir="ltr"
              />
            </Field>

            <Field label={t("deals.expectedCloseDate")} error={errorFor("expectedCloseDate")}>
              <Input
                type="date"
                value={form.expectedCloseDate}
                onChange={(event) => set("expectedCloseDate", event.target.value)}
                dir="ltr"
              />
            </Field>

            <Field label={t("deals.stage")} error={errorFor("stage")}>
              <Select value={form.stage} onValueChange={(value) => set("stage", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEAL_STAGES.map((stage) => (
                    <SelectItem key={stage} value={stage}>
                      {enumLabel("dealStage", stage)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            {form.stage === "CLOSED_LOST" && (
              <Field label={t("deals.lostReason")} error={errorFor("lostReason")} className="sm:col-span-2">
                <Input
                  value={form.lostReason}
                  onChange={(event) => set("lostReason", event.target.value)}
                  placeholder={t("deals.lostReasonPlaceholder")}
                  maxLength={500}
                />
              </Field>
            )}

            <Field label={t("deals.notes")} error={errorFor("notes")} className="sm:col-span-2">
              <Textarea
                value={form.notes}
                onChange={(event) => set("notes", event.target.value)}
                rows={4}
                maxLength={3000}
              />
            </Field>
          </CardContent>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("deals.financials")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-center justify-between gap-3">
                <span className="text-muted-foreground">{t("deals.value")}</span>
                <span className="font-semibold" dir="ltr">
                  {formatCurrency(Number(form.value || 0), locale)}
                </span>
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="text-muted-foreground">{t("deals.commissionRate")}</span>
                <span className="font-medium" dir="ltr">
                  {form.commissionRate || "0"}%
                </span>
              </div>
              <div className="flex items-center justify-between gap-3 border-t pt-3">
                <span className="text-muted-foreground">{t("deals.commissionAmount")}</span>
                <span className="font-semibold text-primary" dir="ltr">
                  {formatCurrency(commission, locale)}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="space-y-2 py-4 text-xs text-muted-foreground">
              <p>{t("deals.createFromCustomer")}</p>
              <p>{t("customers.deals")}</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex items-center justify-end gap-2">
        <Button type="button" variant="outline" asChild disabled={pending}>
          <Link href={backHref}>{t("common.cancel")}</Link>
        </Button>
        <Button type="submit" disabled={pending || !form.customerId}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />}
          {mode === "create" ? t("common.create") : t("common.save")}
        </Button>
      </div>
    </form>
  );
}

function Field({
  label,
  required,
  error,
  children,
  className,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
  className?: string;
}) {
  const { t } = useI18n();
  return (
    <div className={className}>
      <Label className="mb-1.5 block">
        {label}
        {required ? (
          <span className="ms-0.5 text-destructive">*</span>
        ) : (
          <span className="ms-1 text-[10px] font-normal text-muted-foreground">({t("common.optional")})</span>
        )}
      </Label>
      {children}
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}
