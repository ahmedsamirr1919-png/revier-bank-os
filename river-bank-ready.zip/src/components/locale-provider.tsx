"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { dictionaries, translate, type Messages } from "@/lib/i18n";
import { LOCALE_COOKIE, type Locale } from "@/lib/utils";
import { enumLabel as getEnumLabel } from "@/lib/i18n";

type LocaleContextValue = {
  locale: Locale;
  dir: "ltr" | "rtl";
  messages: Messages;
  t: (key: string, vars?: Record<string, string | number>) => string;
  enumLabel: (group: string, value: string | null | undefined) => string;
  setLocale: (locale: Locale) => void;
};

const LocaleContext = React.createContext<LocaleContextValue | null>(null);

export function LocaleProvider({
  initialLocale,
  children,
}: {
  initialLocale: Locale;
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [locale, setLocaleState] = React.useState<Locale>(initialLocale);
  const dir = locale === "ar" ? "rtl" : "ltr";
  const messages = dictionaries[locale];

  const t = React.useCallback(
    (key: string, vars?: Record<string, string | number>) => translate(messages, key, vars),
    [messages],
  );

  const enumLabel = React.useCallback(
    (group: string, value: string | null | undefined) => getEnumLabel(messages, group, value),
    [messages],
  );

  const setLocale = React.useCallback(
    (next: Locale) => {
      setLocaleState(next);
      document.cookie = `${LOCALE_COOKIE}=${next};path=/;max-age=31536000;samesite=lax`;
      document.documentElement.lang = next;
      document.documentElement.dir = next === "ar" ? "rtl" : "ltr";
      router.refresh();
    },
    [router],
  );

  React.useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
  }, [locale, dir]);

  const value = React.useMemo<LocaleContextValue>(
    () => ({ locale, dir, messages, t, enumLabel, setLocale }),
    [locale, dir, messages, t, enumLabel, setLocale],
  );

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useI18n() {
  const ctx = React.useContext(LocaleContext);
  if (!ctx) throw new Error("useI18n must be used inside <LocaleProvider>");
  return ctx;
}

export function useT() {
  return useI18n().t;
}
