"use client";

import { useEffect, useState } from "react";
import { Loader2, Plus, ShieldCheck, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api, fieldErrors } from "@/lib/client-api";

type User = {
  id: string;
  name: string;
  email: string;
  role: string;
  isActive: boolean;
  managerId: string | null;
  manager: { id: string; name: string } | null;
};

export function UsersView() {
  const { t, enumLabel } = useI18n();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "AGENT",
    managerId: "",
  });

  const load = async () => {
    setLoading(true);
    try {
      const data = await api.get<{ items: User[] }>("/api/users?pageSize=100");
      setUsers(data.items);
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const create = async (event: React.FormEvent) => {
    event.preventDefault();
    setCreating(true);
    try {
      await api.post("/api/users", {
        name: form.name,
        email: form.email,
        password: form.password,
        role: form.role,
        managerId: form.managerId || null,
      });
      toast.success(t("toast.created"));
      setShowCreate(false);
      setForm({ name: "", email: "", password: "", role: "AGENT", managerId: "" });
      load();
    } catch (error) {
      const fields = fieldErrors(error);
      if (fields) toast.error(Object.values(fields).flat().join(", "));
      else toast.error(t("toast.error"));
    } finally {
      setCreating(false);
    }
  };

  const update = async (id: string, patch: Partial<User> & { password?: string }) => {
    try {
      await api.patch(`/api/users/${id}`, patch);
      toast.success(t("toast.saved"));
      load();
    } catch {
      toast.error(t("toast.error"));
    }
  };

  const remove = async (id: string) => {
    if (!confirm(t("common.confirmDeleteTitle"))) return;
    try {
      await api.delete(`/api/users/${id}`);
      toast.success(t("toast.deleted"));
      load();
    } catch {
      toast.error(t("toast.error"));
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight md:text-2xl">{t("users.title")}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{t("users.subtitle")}</p>
        </div>
        <Button size="sm" onClick={() => setShowCreate((value) => !value)}>
          <Plus />
          {t("users.new")}
        </Button>
      </div>

      {showCreate && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t("users.new")}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={create} className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>{t("users.name")}</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div className="space-y-1.5">
                <Label>{t("users.email")}</Label>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
              </div>
              <div className="space-y-1.5">
                <Label>{t("users.password")}</Label>
                <Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
              </div>
              <div className="space-y-1.5">
                <Label>{t("users.role")}</Label>
                <Select value={form.role} onValueChange={(value) => setForm({ ...form, role: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ADMIN">{enumLabel("roles", "ADMIN")}</SelectItem>
                    <SelectItem value="MANAGER">{enumLabel("roles", "MANAGER")}</SelectItem>
                    <SelectItem value="AGENT">{enumLabel("roles", "AGENT")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>{t("users.manager")}</Label>
                <Select value={form.managerId || "__none"} onValueChange={(value) => setForm({ ...form, managerId: value === "__none" ? "" : value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none">{t("common.none")}</SelectItem>
                    {users
                      .filter((user) => user.role === "MANAGER" || user.role === "ADMIN")
                      .map((user) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="sm:col-span-2">
                <Button type="submit" disabled={creating}>
                  {creating && <Loader2 className="animate-spin" />}
                  {t("common.create")}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="pt-5">
          {loading ? (
            <Loader2 className="animate-spin" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-muted-foreground">
                    <th className="py-2 text-start font-medium">{t("users.name")}</th>
                    <th className="py-2 text-start font-medium">{t("users.email")}</th>
                    <th className="py-2 text-start font-medium">{t("users.role")}</th>
                    <th className="py-2 text-start font-medium">{t("users.manager")}</th>
                    <th className="py-2 text-start font-medium">{t("users.status")}</th>
                    <th className="py-2 text-start font-medium">{t("common.actions")}</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id} className="border-b last:border-0">
                      <td className="py-2">{user.name}</td>
                      <td className="py-2">{user.email}</td>
                      <td className="py-2">
                        <Select
                          value={user.role}
                          onValueChange={(value) => update(user.id, { role: value as User["role"] })}
                        >
                          <SelectTrigger className="w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ADMIN">{enumLabel("roles", "ADMIN")}</SelectItem>
                            <SelectItem value="MANAGER">{enumLabel("roles", "MANAGER")}</SelectItem>
                            <SelectItem value="AGENT">{enumLabel("roles", "AGENT")}</SelectItem>
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="py-2">{user.manager?.name ?? "—"}</td>
                      <td className="py-2">
                        <Button
                          size="sm"
                          variant={user.isActive ? "outline" : "destructive"}
                          onClick={() => update(user.id, { isActive: !user.isActive })}
                        >
                          {user.isActive ? t("common.active") : t("common.inactive")}
                        </Button>
                      </td>
                      <td className="py-2">
                        <Button size="icon-sm" variant="ghost" onClick={() => remove(user.id)}>
                          <Trash2 />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
