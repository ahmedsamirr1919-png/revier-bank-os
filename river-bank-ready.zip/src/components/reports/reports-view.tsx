"use client";

import { Users as UsersIcon, TrendingUp as TrendingUpIcon, Handshake as HandshakeIcon, Wallet as WalletIcon } from "lucide-react";
import { StatCard } from "@/components/shared/stat-card";
import { useEffect, useState } from "react";
import { Download, FileSpreadsheet, FileText, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { formatCurrency } from "@/lib/utils";
import * as XLSX from "xlsx";
import { jsPDF } from "jspdf";

type ReportData = {
  period: { from: string; to: string };
  summary: {
    totalCustomers: number;
    newCustomers: number;
    totalDeals: number;
    wonDeals: number;
    lostDeals: number;
    revenue: number;
    commission: number;
    winRate: number;
    avgDealSize: number;
    avgRating: number;
    totalFeedback: number;
    negativeFeedback: number;
    resolvedFeedback: number;
  };
  dealsByStage: Array<{ stage: string; count: number }>;
  leadsBySource: Array<{ source: string; count: number }>;
  monthlySales: Array<{ month: string; revenue: number }>;
  agentPerformance: Array<{ name: string; dealsWon: number; revenue: number; commission: number }>;
};

const PRESETS = ["thisMonth", "lastMonth", "thisQuarter", "thisYear"] as const;

function presetRange(preset: string): { from: string; to: string } {
  const now = new Date();
  const startOfDay = (date: Date) => {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    return d;
  };
  const endOfDay = (date: Date) => {
    const d = new Date(date);
    d.setHours(23, 59, 59, 999);
    return d;
  };

  if (preset === "thisMonth") {
    return {
      from: startOfDay(new Date(now.getFullYear(), now.getMonth(), 1)).toISOString(),
      to: endOfDay(new Date(now.getFullYear(), now.getMonth() + 1, 0)).toISOString(),
    };
  }
  if (preset === "lastMonth") {
    return {
      from: startOfDay(new Date(now.getFullYear(), now.getMonth() - 1, 1)).toISOString(),
      to: endOfDay(new Date(now.getFullYear(), now.getMonth(), 0)).toISOString(),
    };
  }
  if (preset === "thisQuarter") {
    const quarter = Math.floor(now.getMonth() / 3);
    return {
      from: startOfDay(new Date(now.getFullYear(), quarter * 3, 1)).toISOString(),
      to: endOfDay(new Date(now.getFullYear(), quarter * 3 + 3, 0)).toISOString(),
    };
  }
  if (preset === "thisYear") {
    return {
      from: startOfDay(new Date(now.getFullYear(), 0, 1)).toISOString(),
      to: endOfDay(new Date(now.getFullYear(), 11, 31)).toISOString(),
    };
  }
  return {
    from: startOfDay(new Date(now.getFullYear(), now.getMonth(), 1)).toISOString(),
    to: endOfDay(new Date(now.getFullYear(), now.getMonth() + 1, 0)).toISOString(),
  };
}

export function ReportsView() {
  const { t, locale, messages, enumLabel } = useI18n();
  const [preset, setPreset] = useState("thisMonth");
  const [from, setFrom] = useState(presetRange("thisMonth").from.slice(0, 10));
  const [to, setTo] = useState(presetRange("thisMonth").to.slice(0, 10));
  const [data, setData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async (nextFrom?: string, nextTo?: string) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("from", new Date(nextFrom ?? from).toISOString());
      params.set("to", new Date(nextTo ?? to + "T23:59:59").toISOString());
      const result = await api.get<ReportData>(`/api/reports?${params.toString()}`);
      setData(result);
    } catch (error) {
      toast.error((error as Error).message || t("toast.error"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const applyPreset = (value: string) => {
    setPreset(value);
    if (value !== "custom") {
      const range = presetRange(value);
      setFrom(range.from.slice(0, 10));
      setTo(range.to.slice(0, 10));
      load(range.from.slice(0, 10), range.to.slice(0, 10));
    }
  };

  const exportExcel = () => {
    if (!data) return;
    const workbook = XLSX.utils.book_new();

    const summarySheet = XLSX.utils.json_to_sheet([
      { Metric: t("reports.totalCustomers"), Value: data.summary.totalCustomers },
      { Metric: t("reports.newCustomers") ?? "New customers", Value: data.summary.newCustomers },
      { Metric: t("reports.totalDeals"), Value: data.summary.totalDeals },
      { Metric: t("reports.dealsWon"), Value: data.summary.wonDeals },
      { Metric: t("reports.lostDeals") ?? "Lost deals", Value: data.summary.lostDeals },
      { Metric: t("reports.totalRevenue"), Value: data.summary.revenue },
      { Metric: t("reports.commission"), Value: data.summary.commission },
      { Metric: t("reports.winRate"), Value: `${data.summary.winRate}%` },
      { Metric: t("reports.avgDealSize"), Value: data.summary.avgDealSize },
      { Metric: t("reports.rating"), Value: data.summary.avgRating },
      { Metric: t("feedback.total"), Value: data.summary.totalFeedback },
      { Metric: t("feedback.negative"), Value: data.summary.negativeFeedback },
      { Metric: t("feedback.resolved"), Value: data.summary.resolvedFeedback },
    ]);
    XLSX.utils.book_append_sheet(workbook, summarySheet, "Summary");

    const stageSheet = XLSX.utils.json_to_sheet(
      data.dealsByStage.map((row) => ({
        Stage: enumLabel("dealStage", row.stage),
        Count: row.count,
      })),
    );
    XLSX.utils.book_append_sheet(workbook, stageSheet, "Deals by stage");

    const sourceSheet = XLSX.utils.json_to_sheet(
      data.leadsBySource.map((row) => ({
        Source: enumLabel("source", row.source),
        Count: row.count,
      })),
    );
    XLSX.utils.book_append_sheet(workbook, sourceSheet, "Leads by source");

    const monthlySheet = XLSX.utils.json_to_sheet(
      data.monthlySales.map((row) => ({ Month: row.month, Revenue: row.revenue })),
    );
    XLSX.utils.book_append_sheet(workbook, monthlySheet, "Monthly sales");

    const agentSheet = XLSX.utils.json_to_sheet(
      data.agentPerformance.map((row) => ({
        Agent: row.name,
        "Deals won": row.dealsWon,
        Revenue: row.revenue,
        Commission: row.commission,
      })),
    );
    XLSX.utils.book_append_sheet(workbook, agentSheet, "Agent performance");

    XLSX.writeFile(workbook, `river-bank-report-${from}-to-${to}.xlsx`);
    toast.success(t("toast.exported"));
  };

  const exportPdf = () => {
    if (!data) return;
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text(t("reports.title"), 14, 18);
    doc.setFontSize(10);
    doc.text(t("reports.generated", { date: new Date().toLocaleString(locale === "ar" ? "ar-AE" : "en-GB") }), 14, 26);
    doc.text(`${t("reports.dateRange")}: ${from} → ${to}`, 14, 32);

    let y = 42;
    doc.setFontSize(12);
    doc.text(t("reports.summary"), 14, y);
    y += 6;
    doc.setFontSize(10);
    const summaryRows = [
      [t("reports.totalCustomers"), String(data.summary.totalCustomers)],
      [t("reports.newCustomers") ?? "New customers", String(data.summary.newCustomers)],
      [t("reports.totalDeals"), String(data.summary.totalDeals)],
      [t("reports.dealsWon"), String(data.summary.wonDeals)],
      [t("reports.totalRevenue"), String(data.summary.revenue)],
      [t("reports.commission"), String(data.summary.commission)],
      [t("reports.winRate"), `${data.summary.winRate}%`],
      [t("reports.avgDealSize"), String(data.summary.avgDealSize)],
      [t("reports.rating"), String(data.summary.avgRating)],
    ];
    for (const [label, value] of summaryRows) {
      doc.text(`${label}: ${value}`, 14, y);
      y += 5;
    }

    y += 4;
    doc.setFontSize(12);
    doc.text(t("reports.agentPerformance"), 14, y);
    y += 6;
    doc.setFontSize(9);
    doc.text(["Agent", "Won", "Revenue", "Commission"].join("  |  "), 14, y);
    y += 5;
    for (const row of data.agentPerformance) {
      doc.text([row.name, String(row.dealsWon), String(row.revenue), String(row.commission)].join("  |  "), 14, y);
      y += 5;
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
    }

    doc.save(`river-bank-report-${from}-to-${to}.pdf`);
    toast.success(t("toast.exported"));
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight md:text-2xl">{t("reports.title")}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{t("reports.subtitle")}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" onClick={exportPdf} disabled={!data || loading}>
            <FileText />
            {t("reports.exportPdf")}
          </Button>
          <Button size="sm" onClick={exportExcel} disabled={!data || loading}>
            <FileSpreadsheet />
            {t("reports.exportExcel")}
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="flex flex-col gap-3 pt-5 sm:flex-row sm:items-end">
          <div className="space-y-1.5">
            <Label>{t("reports.period")}</Label>
            <Select value={preset} onValueChange={applyPreset}>
              <SelectTrigger className="w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PRESETS.map((item) => (
                  <SelectItem key={item} value={item}>
                    {t(`reports.${item}`)}
                  </SelectItem>
                ))}
                <SelectItem value="custom">{t("reports.custom")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>{t("reports.dateRange")}</Label>
            <div className="flex items-center gap-2">
              <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
              <span className="text-muted-foreground">→</span>
              <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => load(from, to)}
            disabled={loading}
          >
            {loading ? <Loader2 className="animate-spin" /> : <Download />}
            {t("reports.applyRange")}
          </Button>
        </CardContent>
      </Card>

      {loading && !data ? (
        <div className="flex items-center justify-center py-16 text-muted-foreground">
          <Loader2 className="mr-2 animate-spin" />
          {t("common.loading")}
        </div>
      ) : data ? (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard label={t("reports.totalCustomers")} value={String(data.summary.totalCustomers)} icon={UsersIcon} />
            <StatCard label={t("reports.newCustomers") ?? "New customers"} value={String(data.summary.newCustomers)} icon={TrendingUpIcon} tone="teal" />
            <StatCard label={t("reports.totalDeals")} value={String(data.summary.totalDeals)} icon={HandshakeIcon} tone="amber" />
            <StatCard label={t("reports.dealsWon")} value={String(data.summary.wonDeals)} icon={HandshakeIcon} tone="emerald" />
            <StatCard label={t("reports.totalRevenue")} value={formatCurrency(data.summary.revenue, locale, true)} icon={WalletIcon} tone="primary" />
            <StatCard label={t("reports.commission")} value={formatCurrency(data.summary.commission, locale, true)} icon={WalletIcon} />
            <StatCard label={t("reports.winRate")} value={`${data.summary.winRate}%`} icon={TrendingUpIcon} />
            <StatCard label={t("reports.avgDealSize")} value={formatCurrency(data.summary.avgDealSize, locale, true)} icon={HandshakeIcon} />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{t("reports.leadsBySource")}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {data.leadsBySource.map((row) => (
                    <li key={row.source} className="flex items-center justify-between text-sm">
                      <span>{enumLabel("source", row.source)}</span>
                      <span className="font-medium">{row.count}</span>
                    </li>
                  ))}
                  {data.leadsBySource.length === 0 && (
                    <li className="text-sm text-muted-foreground">{t("reports.noData")}</li>
                  )}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">{t("reports.funnel")}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {data.dealsByStage.map((row) => (
                    <li key={row.stage} className="flex items-center justify-between text-sm">
                      <span>{enumLabel("dealStage", row.stage)}</span>
                      <span className="font-medium">{row.count}</span>
                    </li>
                  ))}
                  {data.dealsByStage.length === 0 && (
                    <li className="text-sm text-muted-foreground">{t("reports.noData")}</li>
                  )}
                </ul>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("reports.agentPerformance")}</CardTitle>
            </CardHeader>
            <CardContent>
              {data.agentPerformance.length === 0 ? (
                <p className="text-sm text-muted-foreground">{t("reports.noData")}</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b text-muted-foreground">
                        <th className="py-2 text-start font-medium">{t("reports.agent")}</th>
                        <th className="py-2 text-start font-medium">{t("reports.dealsWon")}</th>
                        <th className="py-2 text-start font-medium">{t("reports.revenueLabel")}</th>
                        <th className="py-2 text-start font-medium">{t("reports.commission")}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.agentPerformance.map((row) => (
                        <tr key={row.name} className="border-b last:border-0">
                          <td className="py-2">{row.name}</td>
                          <td className="py-2">{row.dealsWon}</td>
                          <td className="py-2">{formatCurrency(row.revenue, locale, true)}</td>
                          <td className="py-2">{formatCurrency(row.commission, locale, true)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("reports.satisfaction")}</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-3">
              <div>
                <p className="text-xs text-muted-foreground">{t("feedback.average")}</p>
                <p className="text-2xl font-semibold">{data.summary.avgRating}/5</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{t("feedback.total")}</p>
                <p className="text-2xl font-semibold">{data.summary.totalFeedback}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{t("feedback.negative")}</p>
                <p className="text-2xl font-semibold">{data.summary.negativeFeedback}</p>
              </div>
            </CardContent>
          </Card>
        </>
      ) : null}
    </div>
  );
}


