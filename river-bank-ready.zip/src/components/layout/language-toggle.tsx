"use client";

import { Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/components/locale-provider";

export function LanguageToggle({ compact = false }: { compact?: boolean }) {
  const { locale, setLocale, t } = useI18n();
  const next = locale === "ar" ? "en" : "ar";

  return (
    <Button
      variant="ghost"
      size={compact ? "icon" : "sm"}
      onClick={() => setLocale(next)}
      title={t("common.language")}
      aria-label={t("common.language")}
      className="text-muted-foreground"
    >
      <Languages />
      {!compact && <span className="text-xs font-medium">{locale === "ar" ? "English" : "العربية"}</span>}
    </Button>
  );
}
