import { cn } from "@/lib/utils";

export function Logo({
  className,
  size = 36,
  showText = true,
  subtitle,
}: {
  className?: string;
  size?: number;
  showText?: boolean;
  subtitle?: string;
}) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0 drop-shadow-sm"
      >
        <defs>
          <linearGradient id="rb-logo-bg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#0b3a45" />
            <stop offset="1" stopColor="#061c22" />
          </linearGradient>
          <linearGradient id="rb-logo-wave" x1="8" y1="40" x2="56" y2="20" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22b8c4" />
            <stop offset="1" stopColor="#38bdf8" />
          </linearGradient>
        </defs>
        <rect width="64" height="64" rx="16" fill="url(#rb-logo-bg)" />
        <path
          d="M9 42c6.3-9 12.7-9 19 0s12.7 9 19 0 12.7-9 8 0"
          stroke="url(#rb-logo-wave)"
          strokeWidth="4.5"
          strokeLinecap="round"
        />
        <path
          d="M9 30c6.3-9 12.7-9 19 0s12.7 9 19 0"
          stroke="#0ea5e9"
          strokeOpacity="0.55"
          strokeWidth="4"
          strokeLinecap="round"
        />
        <path d="M9 18c6.3-9 12.7-9 19 0" stroke="#5eead4" strokeOpacity="0.35" strokeWidth="3.5" strokeLinecap="round" />
      </svg>
      {showText && (
        <div className="flex flex-col leading-none">
          <span className="text-[17px] font-semibold tracking-tight">River Bank</span>
          {subtitle && <span className="mt-1 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{subtitle}</span>}
        </div>
      )}
    </div>
  );
}
