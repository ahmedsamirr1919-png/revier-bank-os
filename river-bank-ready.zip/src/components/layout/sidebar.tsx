"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Activity,
  Building2,
  CalendarDays,
  ChartNoAxesCombined,
  Handshake,
  LayoutDashboard,
  ListTodo,
  MessageSquareHeart,
  Settings,
  ShieldCheck,
  Users,
  type LucideIcon,
} from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { useI18n } from "@/components/locale-provider";
import { cn } from "@/lib/utils";
import type { Role } from "@/lib/rbac";

type NavItem = {
  href: string;
  key: string;
  icon: LucideIcon;
  roles?: Role[];
};

const MAIN_NAV: NavItem[] = [
  { href: "/dashboard", key: "nav.dashboard", icon: LayoutDashboard },
  { href: "/customers", key: "nav.customers", icon: Users },
  { href: "/properties", key: "nav.properties", icon: Building2 },
  { href: "/properties?purpose=RENT", key: "nav.rent", icon: Building2 },
  { href: "/deals", key: "nav.deals", icon: Handshake },
  { href: "/tasks", key: "nav.tasks", icon: ListTodo },
  { href: "/calendar", key: "nav.calendar", icon: CalendarDays },
  { href: "/feedback", key: "nav.feedback", icon: MessageSquareHeart },
];

const MANAGEMENT_NAV: NavItem[] = [
  { href: "/reports", key: "nav.reports", icon: ChartNoAxesCombined },
  { href: "/users", key: "nav.users", icon: ShieldCheck, roles: ["ADMIN"] },
  { href: "/activity", key: "nav.activity", icon: Activity, roles: ["ADMIN", "MANAGER"] },
  { href: "/settings", key: "nav.settings", icon: Settings, roles: ["ADMIN"] },
];

export function SidebarContent({
  role,
  onNavigate,
}: {
  role: Role;
  onNavigate?: () => void;
}) {
  const pathname = usePathname();
  const { t } = useI18n();

  const visible = (item: NavItem) => !item.roles || item.roles.includes(role);

  const link = (item: NavItem) => {
    const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
    const Icon = item.icon;
    return (
      <Link
        key={item.href}
        href={item.href}
        onClick={onNavigate}
        className={cn(
          "group relative flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
          active
            ? "bg-sidebar-accent font-medium text-white"
            : "text-sidebar-muted hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
        )}
      >
        {active && (
          <span className="absolute inset-y-2 start-0 w-0.5 rounded-full bg-[#2dd4bf]" aria-hidden="true" />
        )}
        <Icon className={cn("size-[18px] shrink-0", active ? "text-[#2dd4bf]" : "opacity-80")} />
        <span className="truncate">{t(item.key)}</span>
      </Link>
    );
  };

  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-16 items-center border-b border-sidebar-border px-5">
        <Link href="/dashboard" onClick={onNavigate} className="flex items-center gap-2.5">
          <Logo size={34} subtitle={t("app.tagline")} />
        </Link>
      </div>

      <nav className="flex-1 space-y-5 overflow-y-auto px-3 py-5">
        <div>
          <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-sidebar-muted/70">
            {t("nav.main")}
          </p>
          <div className="space-y-0.5">{MAIN_NAV.filter(visible).map(link)}</div>
        </div>
        <div>
          <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-sidebar-muted/70">
            {t("nav.management")}
          </p>
          <div className="space-y-0.5">{MANAGEMENT_NAV.filter(visible).map(link)}</div>
        </div>
      </nav>

      <div className="border-t border-sidebar-border p-4">
        <div className="rounded-lg bg-sidebar-accent/50 px-3 py-2.5">
          <p className="text-[11px] font-medium text-sidebar-foreground/90">River Bank CRM</p>
          <p className="mt-0.5 text-[10px] text-sidebar-muted">v1.0 · SQLite</p>
        </div>
      </div>
    </div>
  );
}
