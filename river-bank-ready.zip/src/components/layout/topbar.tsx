"use client";

import { usePathname } from "next/navigation";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LanguageToggle } from "@/components/layout/language-toggle";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { UserMenu } from "@/components/layout/user-menu";
import { useI18n } from "@/components/locale-provider";
import type { Role } from "@/lib/rbac";

const TITLES: Record<string, string> = {
  dashboard: "nav.dashboard",
  customers: "nav.customers",
  properties: "nav.properties",
  deals: "nav.deals",
  tasks: "nav.tasks",
  calendar: "nav.calendar",
  feedback: "nav.feedback",
  reports: "nav.reports",
  users: "nav.users",
  activity: "nav.activity",
  settings: "nav.settings",
  profile: "nav.profile",
};

export function Topbar({
  user,
  onMenu,
}: {
  user: { name: string; email: string; role: Role };
  onMenu: () => void;
}) {
  const pathname = usePathname();
  const { t } = useI18n();
  const segment = pathname.split("/").filter(Boolean)[0] ?? "dashboard";
  const title = t(TITLES[segment] ?? "nav.dashboard");

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b bg-background/85 px-4 backdrop-blur md:px-6">
      <Button variant="ghost" size="icon" className="lg:hidden" onClick={onMenu} aria-label={t("common.menu")}>
        <Menu />
      </Button>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold">{title}</p>
      </div>
      <div className="flex items-center gap-1">
        <LanguageToggle compact />
        <ThemeToggle />
        <div className="mx-1 h-6 w-px bg-border" />
        <UserMenu user={user} />
      </div>
    </header>
  );
}
