"use client";

import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/components/locale-provider";
import { STATUS_STYLES } from "@/lib/constants";
import { cn } from "@/lib/utils";

export function StatusBadge({
  value,
  group = "customerStatus",
  className,
}: {
  value: string | null | undefined;
  group?: string;
  className?: string;
}) {
  const { enumLabel } = useI18n();
  if (!value) return <span className="text-muted-foreground">—</span>;
  return (
    <Badge
      variant="outline"
      className={cn("border-transparent font-medium", STATUS_STYLES[value] ?? "bg-muted text-muted-foreground", className)}
    >
      {enumLabel(group, value)}
    </Badge>
  );
}
