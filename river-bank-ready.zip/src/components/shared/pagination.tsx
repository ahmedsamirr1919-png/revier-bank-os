"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/components/locale-provider";
import { PAGE_SIZE_OPTIONS } from "@/lib/constants";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

function pageWindow(page: number, pages: number) {
  const set = new Set<number>();
  for (let p = Math.max(1, page - 1); p <= Math.min(pages, page + 1); p += 1) set.add(p);
  set.add(1);
  set.add(pages);
  return Array.from(set).sort((a, b) => a - b);
}

export function Pagination({
  page,
  pages,
  total,
  pageSize,
}: {
  page: number;
  pages: number;
  total: number;
  pageSize: number;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { t, dir } = useI18n();

  const navigate = (nextPage: number, nextSize = pageSize) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(nextPage));
    params.set("pageSize", String(nextSize));
    router.push(`${pathname}?${params.toString()}`);
  };

  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);
  const numbers = pageWindow(page, pages);
  const PrevIcon = dir === "rtl" ? ChevronRight : ChevronLeft;
  const NextIcon = dir === "rtl" ? ChevronLeft : ChevronRight;

  return (
    <div className="flex flex-col gap-3 border-t px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span>
          {t("common.showing")} {from}–{to} {t("common.of")} {total}
        </span>
        <div className="flex items-center gap-1.5">
          <span className="hidden sm:inline">{t("common.perPage")}</span>
          <Select value={String(pageSize)} onValueChange={(value) => navigate(1, Number(value))}>
            <SelectTrigger className="h-7 w-16 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PAGE_SIZE_OPTIONS.map((size) => (
                <SelectItem key={size} value={String(size)}>
                  {size}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <Button
          variant="outline"
          size="icon-sm"
          disabled={page <= 1}
          onClick={() => navigate(page - 1)}
          aria-label={t("common.previous")}
        >
          <PrevIcon />
        </Button>
        {numbers.map((num, index) => {
          const prev = numbers[index - 1];
          return (
            <span key={num} className="flex items-center">
              {prev && num - prev > 1 && <span className="px-1 text-xs text-muted-foreground">…</span>}
              <Button
                variant={num === page ? "default" : "ghost"}
                size="icon-sm"
                onClick={() => navigate(num)}
                aria-current={num === page ? "page" : undefined}
              >
                {num}
              </Button>
            </span>
          );
        })}
        <Button
          variant="outline"
          size="icon-sm"
          disabled={page >= pages}
          onClick={() => navigate(page + 1)}
          aria-label={t("common.next")}
        >
          <NextIcon />
        </Button>
      </div>
    </div>
  );
}
