"use client";

import { Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/components/locale-provider";

export function Stars({
  value,
  onChange,
  size = "md",
  showValue = false,
}: {
  value: number;
  onChange?: (value: number) => void;
  size?: "sm" | "md" | "lg";
  showValue?: boolean;
}) {
  const { t } = useI18n();
  const px = size === "lg" ? "size-8" : size === "sm" ? "size-3.5" : "size-5";
  const interactive = Boolean(onChange);

  return (
    <div className="flex items-center gap-1" role={interactive ? "radiogroup" : undefined} aria-label={t("feedback.rating")}>
      {[1, 2, 3, 4, 5].map((star) => {
        const active = star <= Math.round(value);
        const content = (
          <Star
            className={cn(
              px,
              "transition-colors",
              active ? "fill-amber-400 text-amber-400" : "fill-transparent text-muted-foreground/40",
              interactive && "hover:scale-110",
            )}
          />
        );
        if (!interactive) {
          return (
            <span key={star} aria-hidden="true">
              {content}
            </span>
          );
        }
        return (
          <button
            key={star}
            type="button"
            role="radio"
            aria-checked={star === value}
            aria-label={t("feedback.stars", { count: star })}
            onClick={() => onChange?.(star)}
            className="rounded-sm p-0.5 outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {content}
          </button>
        );
      })}
      {showValue && <span className="ms-1 text-xs font-medium text-muted-foreground">{value.toFixed(1)}</span>}
    </div>
  );
}
