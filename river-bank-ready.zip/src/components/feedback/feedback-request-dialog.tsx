"use client";

import { useState } from "react";
import { CheckCircle2, ExternalLink, Link2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api, ApiClientError, fieldErrors } from "@/lib/client-api";
import { CopyLinkButton, feedbackLink } from "./copy-link-button";
import type { FeedbackCustomerOption, FeedbackDealOption, FeedbackListItem } from "./types";

type RequestResult = FeedbackListItem & { reused: boolean };

const EXPIRY_OPTIONS = [7, 14, 30];

export function FeedbackRequestDialog({
  open,
  onOpenChange,
  customers,
  deals,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customers: FeedbackCustomerOption[];
  deals: FeedbackDealOption[];
}) {
  const { t, locale } = useI18n();
  const [customerId, setCustomerId] = useState("");
  const [dealId, setDealId] = useState("");
  const [expiry, setExpiry] = useState("14");
  const [pending, setPending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [result, setResult] = useState<RequestResult | null>(null);

  const reset = () => {
    setCustomerId("");
    setDealId("");
    setExpiry("14");
    setErrors({});
    setResult(null);
    setPending(false);
  };

  const handleOpenChange = (next: boolean) => {
    if (!next) reset();
    onOpenChange(next);
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setPending(true);
    setErrors({});
    try {
      const created = await api.post<RequestResult>("/api/feedback/request", {
        customerId: customerId || null,
        dealId: dealId || null,
        expiresInDays: Number(expiry),
      });
      setResult(created);
      toast.success(t("feedback.requestCreated"));
    } catch (error) {
      const fields = fieldErrors(error);
      if (fields) setErrors(fields);
      toast.error(error instanceof ApiClientError ? error.message : t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 className="size-5 text-primary" />
            {t("feedback.requestTitle")}
          </DialogTitle>
          <DialogDescription>{t("feedback.requestHint")}</DialogDescription>
        </DialogHeader>

        {result ? (
          <div className="space-y-4">
            <div className="flex items-start gap-3 rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3">
              <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
              <div className="min-w-0">
                <p className="text-sm font-medium">
                  {result.reused ? t("feedback.requestReused") : t("feedback.requestCreated")}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {result.customer?.fullName ?? result.deal?.title ?? t("common.noData")}
                  {result.expiresAt
                    ? ` · ${t("feedback.expiresOn", {
                        date: new Intl.DateTimeFormat(locale === "ar" ? "ar-AE" : "en-GB", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric",
                        }).format(new Date(result.expiresAt)),
                      })}`
                    : ""}
                </p>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>{t("common.copyLink")}</Label>
              <div className="flex items-center gap-2">
                <Input
                  readOnly
                  value={feedbackLink(result.token)}
                  dir="ltr"
                  className="text-xs"
                  onFocus={(event) => event.currentTarget.select()}
                />
                <Button variant="outline" size="sm" asChild>
                  <a href={`/f/${result.token}`} target="_blank" rel="noreferrer">
                    <ExternalLink />
                    {t("feedback.openLink")}
                  </a>
                </Button>
              </div>
              <CopyLinkButton token={result.token} />
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t("feedback.customer")}</Label>
              <Select
                value={customerId || "__none"}
                onValueChange={(value) => setCustomerId(value === "__none" ? "" : value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t("feedback.selectCustomer")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">{t("feedback.noCustomer")}</SelectItem>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.fullName} · {customer.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.customerId?.[0] && (
                <p className="text-xs text-destructive">{errors.customerId[0]}</p>
              )}
            </div>

            <div className="space-y-1.5">
              <Label>{t("feedback.deal")}</Label>
              <Select
                value={dealId || "__none"}
                onValueChange={(value) => {
                  const next = value === "__none" ? "" : value;
                  setDealId(next);
                  const deal = deals.find((item) => item.id === next);
                  if (deal) setCustomerId(deal.customerId);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t("feedback.selectDeal")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">{t("feedback.noDeal")}</SelectItem>
                  {deals.map((deal) => (
                    <SelectItem key={deal.id} value={deal.id}>
                      {deal.title} · {deal.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>{t("feedback.requestExpiry")}</Label>
              <Select value={expiry} onValueChange={setExpiry}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EXPIRY_OPTIONS.map((days) => (
                    <SelectItem key={days} value={String(days)}>
                      {t("feedback.days", { count: days })}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => handleOpenChange(false)}>
                {t("common.cancel")}
              </Button>
              <Button type="submit" disabled={pending}>
                {pending && <Loader2 className="animate-spin" />}
                {t("feedback.requestLink")}
              </Button>
            </DialogFooter>
          </form>
        )}

        {result && (
          <DialogFooter>
            <Button type="button" onClick={() => handleOpenChange(false)}>
              {t("common.close")}
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
