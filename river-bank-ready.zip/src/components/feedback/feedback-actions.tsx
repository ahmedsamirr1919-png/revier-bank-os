"use client";

import { useState } from "react";
import { Link2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/components/locale-provider";
import { FeedbackLogDialog } from "./feedback-log-dialog";
import { FeedbackRequestDialog } from "./feedback-request-dialog";
import type {
  FeedbackAgentOption,
  FeedbackCustomerOption,
  FeedbackDealOption,
} from "./types";

export function FeedbackActions({
  customers,
  deals,
  agents,
}: {
  customers: FeedbackCustomerOption[];
  deals: FeedbackDealOption[];
  agents: FeedbackAgentOption[];
}) {
  const { t } = useI18n();
  const [requestOpen, setRequestOpen] = useState(false);
  const [logOpen, setLogOpen] = useState(false);

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setRequestOpen(true)}>
        <Link2 />
        {t("feedback.requestLink")}
      </Button>
      <Button size="sm" onClick={() => setLogOpen(true)}>
        <Plus />
        {t("feedback.new")}
      </Button>

      <FeedbackRequestDialog
        open={requestOpen}
        onOpenChange={setRequestOpen}
        customers={customers}
        deals={deals}
      />
      <FeedbackLogDialog
        open={logOpen}
        onOpenChange={setLogOpen}
        customers={customers}
        deals={deals}
        agents={agents}
      />
    </>
  );
}
