"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  AlertTriangle,
  Eye,
  Hourglass,
  MessageSquareHeart,
  Star,
  User as UserIcon,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { Pagination } from "@/components/shared/pagination";
import { SearchInput } from "@/components/shared/search-input";
import { StatCard } from "@/components/shared/stat-card";
import { StatusBadge } from "@/components/shared/status-badge";
import { Stars } from "@/components/shared/stars";
import { useI18n } from "@/components/locale-provider";
import { FEEDBACK_STATUSES } from "@/lib/constants";
import { cn, formatDate, parseJsonArray } from "@/lib/utils";
import { CopyLinkButton } from "./copy-link-button";
import type {
  FeedbackAgentOption,
  FeedbackFilters,
  FeedbackListItem,
  FeedbackStats,
} from "./types";

export function FeedbackView({
  items,
  total,
  page,
  pageSize,
  pages,
  filters,
  agents,
  stats,
}: {
  items: FeedbackListItem[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
  filters: FeedbackFilters;
  agents: FeedbackAgentOption[];
  stats: FeedbackStats;
}) {
  const { t, enumLabel, locale } = useI18n();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const setFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value && value !== "all") params.set(key, value);
    else params.delete(key);
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label={t("feedback.average")}
          value={stats.total ? `${stats.average.toFixed(1)} / 5` : "—"}
          hint={t("feedback.resolved") + ": " + stats.resolved}
          icon={Star}
          tone="amber"
        />
        <StatCard
          label={t("feedback.total")}
          value={String(stats.total)}
          hint={t("feedback.responses")}
          icon={MessageSquareHeart}
          tone="teal"
        />
        <StatCard
          label={t("feedback.negative")}
          value={String(stats.negative)}
          hint={t("feedback.alertHint", { threshold: stats.threshold })}
          icon={AlertTriangle}
          tone="rose"
        />
        <StatCard
          label={t("feedback.requestPending")}
          value={String(stats.pending)}
          hint={t("feedback.requestPendingHint")}
          icon={Hourglass}
          tone="primary"
        />
      </div>

      <Card className="overflow-hidden">
        <div className="flex flex-col gap-3 border-b p-4 lg:flex-row lg:items-center lg:justify-between">
          <SearchInput placeholder={t("feedback.searchPlaceholder")} className="w-full lg:max-w-sm" />
          <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:items-center">
            <Select
              value={filters.status || "all"}
              onValueChange={(value) => setFilter("status", value)}
            >
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("common.status")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {FEEDBACK_STATUSES.map((status) => (
                  <SelectItem key={status} value={status}>
                    {enumLabel("feedbackStatus", status)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={filters.rating || "all"}
              onValueChange={(value) => setFilter("rating", value)}
            >
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("feedback.filterRating")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("feedback.allRatings")}</SelectItem>
                {[5, 4, 3, 2, 1].map((rating) => (
                  <SelectItem key={rating} value={String(rating)}>
                    {rating} ★
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={filters.agentId || "all"}
              onValueChange={(value) => setFilter("agentId", value)}
            >
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("feedback.agent")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {agents.map((agent) => (
                  <SelectItem key={agent.id} value={agent.id}>
                    {agent.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.sort} onValueChange={(value) => setFilter("sort", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("common.sortBy")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">{t("common.newest")}</SelectItem>
                <SelectItem value="oldest">{t("common.oldest")}</SelectItem>
                <SelectItem value="rating_desc">{t("feedback.highestRated")}</SelectItem>
                <SelectItem value="rating_asc">{t("feedback.lowestRated")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {items.length === 0 ? (
          <EmptyState
            icon={MessageSquareHeart}
            title={t("feedback.noFeedback")}
            description={t("common.noResultsHint")}
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-36">{t("feedback.rating")}</TableHead>
                  <TableHead>{t("feedback.customer")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("feedback.agent")}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t("feedback.source")}</TableHead>
                  <TableHead>{t("common.status")}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t("feedback.submittedAt")}</TableHead>
                  <TableHead className="hidden xl:table-cell">{t("feedback.responses")}</TableHead>
                  <TableHead className="w-24" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => {
                  const pending = item.status === "PENDING";
                  const categories = parseJsonArray(item.categories);
                  return (
                    <TableRow key={item.id} className={cn(pending && "bg-muted/30")}>
                      <TableCell>
                        {pending ? (
                          <Badge variant="warning">{t("feedback.notSubmitted")}</Badge>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Stars value={item.rating} size="sm" />
                            <span className="text-xs text-muted-foreground">{item.rating}/5</span>
                          </div>
                        )}
                        {item.isNegative && (
                          <span className="mt-1 flex items-center gap-1 text-[11px] font-medium text-rose-600 dark:text-rose-400">
                            <AlertTriangle className="size-3" />
                            {t("feedback.negative")}
                          </span>
                        )}
                      </TableCell>

                      <TableCell className="max-w-[260px]">
                        {item.customer ? (
                          <Link
                            href={`/customers/${item.customer.id}`}
                            className="text-sm font-medium hover:underline"
                          >
                            {item.customer.fullName}
                          </Link>
                        ) : (
                          <span className="text-sm">{item.submittedByName ?? t("feedback.anonymous")}</span>
                        )}
                        <span className="block text-xs text-muted-foreground">
                          {item.customer?.code ?? item.deal?.code ?? "—"}
                          {item.comment && !pending ? ` · ${item.comment}` : ""}
                        </span>
                        {categories.length > 0 && !pending && (
                          <div className="mt-1 flex flex-wrap gap-1">
                            {categories.slice(0, 3).map((category) => (
                              <Badge key={category} variant="muted" className="text-[10px]">
                                {enumLabel("feedbackCategory", category)}
                              </Badge>
                            ))}
                          </div>
                        )}
                        {pending && (
                          <span className="mt-1 block text-xs text-muted-foreground">
                            {t("feedback.requestPending")}
                          </span>
                        )}
                      </TableCell>

                      <TableCell className="hidden md:table-cell">
                        <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                          <UserIcon className="size-3.5" />
                          {item.agent?.name ?? t("common.unassigned")}
                        </span>
                      </TableCell>

                      <TableCell className="hidden lg:table-cell">
                        <Badge variant="outline">{enumLabel("feedbackSource", item.source)}</Badge>
                      </TableCell>

                      <TableCell>
                        <StatusBadge value={item.status} group="feedbackStatus" />
                      </TableCell>

                      <TableCell className="hidden text-muted-foreground lg:table-cell">
                        {formatDate(item.createdAt, locale)}
                      </TableCell>

                      <TableCell className="hidden text-muted-foreground xl:table-cell">
                        {item._count.replies}
                      </TableCell>

                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          {pending && <CopyLinkButton token={item.token} withLabel={false} variant="ghost" />}
                          <Button variant="ghost" size="icon-sm" asChild aria-label={t("common.view")}>
                            <Link href={`/feedback/${item.id}`}>
                              <Eye />
                            </Link>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}

        <Pagination page={page} pages={pages} total={total} pageSize={pageSize} />
      </Card>
    </div>
  );
}
