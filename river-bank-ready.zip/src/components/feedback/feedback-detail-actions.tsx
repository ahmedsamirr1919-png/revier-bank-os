"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Loader2, RotateCcw, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useI18n } from "@/components/locale-provider";
import { api, fieldErrors } from "@/lib/client-api";
import { CopyLinkButton } from "./copy-link-button";

export function FeedbackDetailActions({
  feedback,
}: {
  feedback: { id: string; token: string; status: string; rating: number };
}) {
  const { t } = useI18n();
  const router = useRouter();
  const [reply, setReply] = useState("");
  const [pending, setPending] = useState(false);
  const [statusPending, setStatusPending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});

  const pendingRequest = feedback.status === "PENDING";
  const resolved = feedback.status === "RESOLVED";

  const sendReply = async (event: React.FormEvent) => {
    event.preventDefault();
    if (reply.trim().length < 2) {
      toast.error(t("common.requiredField"));
      return;
    }
    setPending(true);
    setErrors({});
    try {
      await api.post(`/api/feedback/${feedback.id}/reply`, { body: reply.trim() });
      toast.success(t("feedback.replyAdded"));
      setReply("");
      router.refresh();
    } catch (error) {
      const fields = fieldErrors(error);
      if (fields) setErrors(fields);
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const toggleStatus = async () => {
    setStatusPending(true);
    try {
      await api.patch(`/api/feedback/${feedback.id}`, {
        status: resolved ? "NEW" : "RESOLVED",
      });
      toast.success(t("feedback.statusUpdated"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setStatusPending(false);
    }
  };

  if (pendingRequest) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("feedback.requestPending")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <p>{t("feedback.requestPendingHint")}</p>
          <CopyLinkButton token={feedback.token} />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-2">
        <CardTitle className="text-base">{t("feedback.reply")}</CardTitle>
        <Button
          type="button"
          variant={resolved ? "outline" : "outline"}
          size="sm"
          onClick={toggleStatus}
          disabled={statusPending}
        >
          {statusPending ? (
            <Loader2 className="animate-spin" />
          ) : resolved ? (
            <RotateCcw />
          ) : (
            <CheckCircle2 />
          )}
          {resolved ? t("feedback.markNew") : t("feedback.markResolved")}
        </Button>
      </CardHeader>
      <CardContent>
        <form onSubmit={sendReply} className="space-y-3">
          <Textarea
            value={reply}
            onChange={(event) => setReply(event.target.value)}
            placeholder={t("feedback.replyPlaceholder")}
            rows={4}
          />
          {errors.body?.[0] && <p className="text-xs text-destructive">{errors.body[0]}</p>}
          <div className="flex justify-end">
            <Button type="submit" size="sm" disabled={pending}>
              {pending ? <Loader2 className="animate-spin" /> : <Send />}
              {t("feedback.sendReply")}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
