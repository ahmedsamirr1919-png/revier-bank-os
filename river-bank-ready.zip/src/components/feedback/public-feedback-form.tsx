"use client";

import { useState } from "react";
import { AlertTriangle, CheckCircle2, Loader2, MessageSquareHeart, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Stars } from "@/components/shared/stars";
import { useI18n } from "@/components/locale-provider";
import { api, ApiClientError, fieldErrors } from "@/lib/client-api";
import { FEEDBACK_CATEGORIES } from "@/lib/constants";
import { cn } from "@/lib/utils";

export function PublicFeedbackForm({
  token,
  customerName,
  agentName,
  dealTitle,
}: {
  token: string;
  customerName: string | null;
  agentName: string | null;
  dealTitle: string | null;
}) {
  const { t, enumLabel } = useI18n();
  const [rating, setRating] = useState(0);
  const [categories, setCategories] = useState<string[]>([]);
  const [comment, setComment] = useState("");
  const [name, setName] = useState("");
  const [pending, setPending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [done, setDone] = useState(false);
  const [unavailable, setUnavailable] = useState<"expired" | "used" | null>(null);

  const toggleCategory = (category: string) => {
    setCategories((current) =>
      current.includes(category) ? current.filter((item) => item !== category) : [...current, category],
    );
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!rating) {
      setErrors({ rating: [t("feedback.ratingRequired")] });
      return;
    }
    if (rating <= 2 && comment.trim().length < 3) {
      setErrors({ comment: [t("feedback.commentRequired")] });
      return;
    }
    setPending(true);
    setErrors({});
    try {
      await api.post(`/api/feedback/public/${token}`, {
        rating,
        categories,
        comment: comment || null,
        submittedByName: name || null,
      });
      setDone(true);
    } catch (error) {
      if (error instanceof ApiClientError && (error.code === "expired" || error.code === "already_submitted")) {
        setUnavailable(error.code === "expired" ? "expired" : "used");
        return;
      }
      const fields = fieldErrors(error);
      if (fields) setErrors(fields);
    } finally {
      setPending(false);
    }
  };

  if (unavailable) {
    return (
      <Card className="w-full max-w-xl shadow-xl">
        <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
          <span className="flex size-12 items-center justify-center rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400">
            <AlertTriangle className="size-6" />
          </span>
          <h1 className="text-lg font-semibold">
            {unavailable === "expired" ? t("feedback.expired") : t("feedback.invalidToken")}
          </h1>
          <p className="max-w-sm text-sm text-muted-foreground">{t("feedback.invalidTokenBody")}</p>
        </CardContent>
      </Card>
    );
  }

  if (done) {
    return (
      <Card className="w-full max-w-xl shadow-xl">
        <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
          <span className="flex size-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="size-7" />
          </span>
          <h1 className="text-xl font-semibold">{t("feedback.thankYou")}</h1>
          <p className="max-w-sm text-sm text-muted-foreground">{t("feedback.thankYouBody")}</p>
          <Stars value={rating} size="lg" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-xl shadow-xl">
      <CardContent className="space-y-5">
        <div className="space-y-2 text-center">
          <span className="mx-auto flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
            <MessageSquareHeart className="size-6" />
          </span>
          <h1 className="text-xl font-semibold">{t("feedback.publicTitle")}</h1>
          <p className="text-sm text-muted-foreground">{t("feedback.publicSubtitle")}</p>
          {(customerName || dealTitle) && (
            <div className="flex flex-wrap items-center justify-center gap-2 pt-1 text-xs text-muted-foreground">
              {customerName && <span className="rounded-full bg-muted px-2.5 py-1">{customerName}</span>}
              {dealTitle && <span className="rounded-full bg-muted px-2.5 py-1">{dealTitle}</span>}
              {agentName && (
                <span className="rounded-full bg-muted px-2.5 py-1">
                  {t("feedback.agent")}: {agentName}
                </span>
              )}
            </div>
          )}
        </div>

        <form onSubmit={submit} className="space-y-5">
          <div className="space-y-2 text-center">
            <Label>{t("feedback.rating")}</Label>
            <div className="flex justify-center">
              <Stars value={rating} onChange={setRating} size="lg" />
            </div>
            <p className="text-xs text-muted-foreground">
              {rating ? t("feedback.stars", { count: rating }) : t("feedback.ratingRequired")}
            </p>
            {errors.rating?.[0] && <p className="text-xs text-destructive">{errors.rating[0]}</p>}
          </div>

          <div className="space-y-2">
            <Label>{t("feedback.categories")}</Label>
            <p className="text-xs text-muted-foreground">{t("feedback.selectCategories")}</p>
            <div className="flex flex-wrap justify-center gap-2">
              {FEEDBACK_CATEGORIES.map((category) => {
                const active = categories.includes(category);
                return (
                  <button
                    key={category}
                    type="button"
                    aria-pressed={active}
                    onClick={() => toggleCategory(category)}
                    className={cn(
                      "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                      active
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-input text-muted-foreground hover:bg-accent",
                    )}
                  >
                    {enumLabel("feedbackCategory", category)}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>
              {t("feedback.comment")}{" "}
              <span className="font-normal text-muted-foreground">({t("feedback.optionalComment")})</span>
            </Label>
            <Textarea
              value={comment}
              onChange={(event) => setComment(event.target.value)}
              placeholder={t("feedback.commentPlaceholder")}
              rows={4}
            />
            {rating > 0 && rating <= 2 && (
              <p className="flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400">
                <Star className="size-3" />
                {t("feedback.commentRequired")}
              </p>
            )}
            {errors.comment?.[0] && <p className="text-xs text-destructive">{errors.comment[0]}</p>}
          </div>

          <div className="space-y-1.5">
            <Label>
              {t("feedback.name")}{" "}
              <span className="font-normal text-muted-foreground">({t("feedback.optionalComment")})</span>
            </Label>
            <Input
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder={t("feedback.anonymousHint")}
            />
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={pending}>
            {pending && <Loader2 className="animate-spin" />}
            {pending ? t("feedback.submitting") : t("feedback.submit")}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
