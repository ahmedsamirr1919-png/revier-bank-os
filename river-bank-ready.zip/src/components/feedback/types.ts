export type FeedbackReplyItem = {
  id: string;
  body: string;
  createdAt: Date | string;
  author: { id: string; name: string; role?: string };
};

export type FeedbackListItem = {
  id: string;
  token: string;
  source: string;
  rating: number;
  categories: string;
  comment: string | null;
  customerId: string | null;
  dealId: string | null;
  propertyId: string | null;
  agentId: string | null;
  submittedByName: string | null;
  submittedById: string | null;
  isNegative: boolean;
  status: string;
  expiresAt: Date | string | null;
  resolvedAt: Date | string | null;
  createdAt: Date | string;
  customer: {
    id: string;
    code: string;
    fullName: string;
    phone: string;
    email: string | null;
  } | null;
  deal: { id: string; code: string; title: string } | null;
  property: { id: string; code: string; title: string } | null;
  agent: { id: string; name: string } | null;
  resolvedBy: { id: string; name: string } | null;
  _count: { replies: number };
};

export type FeedbackDetail = FeedbackListItem & {
  replies: FeedbackReplyItem[];
};

export type FeedbackFilters = {
  q: string;
  status: string;
  rating: string;
  source: string;
  agentId: string;
  sort: string;
};

export type FeedbackStats = {
  average: number;
  total: number;
  negative: number;
  resolved: number;
  pending: number;
  threshold: number;
};

export type FeedbackCustomerOption = {
  id: string;
  code: string;
  fullName: string;
  assignedAgentId: string | null;
};

export type FeedbackDealOption = {
  id: string;
  code: string;
  title: string;
  customerId: string;
  propertyId: string | null;
  agentId: string;
};

export type FeedbackAgentOption = {
  id: string;
  name: string;
  email: string;
  role: string;
};
