"use client";

import { Check, Copy } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/components/locale-provider";

export function feedbackLink(token: string) {
  const origin = typeof window === "undefined" ? "" : window.location.origin;
  return `${origin}/f/${token}`;
}

export function CopyLinkButton({
  token,
  size = "sm",
  variant = "outline",
  withLabel = true,
}: {
  token: string;
  size?: "sm" | "default";
  variant?: "outline" | "ghost" | "secondary" | "default";
  withLabel?: boolean;
}) {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    const link = feedbackLink(token);
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(link);
      } else {
        const input = document.createElement("textarea");
        input.value = link;
        input.style.position = "fixed";
        input.style.opacity = "0";
        document.body.appendChild(input);
        input.select();
        document.execCommand("copy");
        document.body.removeChild(input);
      }
      setCopied(true);
      toast.success(t("feedback.linkCopied"));
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error(t("toast.error"));
    }
  };

  return (
    <Button type="button" variant={variant} size={size} onClick={copy}>
      {copied ? <Check /> : <Copy />}
      {withLabel && (copied ? t("common.copied") : t("common.copyLink"))}
    </Button>
  );
}
