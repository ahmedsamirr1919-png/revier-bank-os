"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, MessageSquarePlus } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Stars } from "@/components/shared/stars";
import { useI18n } from "@/components/locale-provider";
import { api, ApiClientError, fieldErrors } from "@/lib/client-api";
import { FEEDBACK_CATEGORIES } from "@/lib/constants";
import { cn } from "@/lib/utils";
import type {
  FeedbackAgentOption,
  FeedbackCustomerOption,
  FeedbackDealOption,
} from "./types";

export function FeedbackLogDialog({
  open,
  onOpenChange,
  customers,
  deals,
  agents,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customers: FeedbackCustomerOption[];
  deals: FeedbackDealOption[];
  agents: FeedbackAgentOption[];
}) {
  const { t, enumLabel } = useI18n();
  const router = useRouter();
  const [rating, setRating] = useState(0);
  const [categories, setCategories] = useState<string[]>([]);
  const [comment, setComment] = useState("");
  const [customerId, setCustomerId] = useState("");
  const [dealId, setDealId] = useState("");
  const [agentId, setAgentId] = useState("");
  const [submittedByName, setSubmittedByName] = useState("");
  const [pending, setPending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});

  const reset = () => {
    setRating(0);
    setCategories([]);
    setComment("");
    setCustomerId("");
    setDealId("");
    setAgentId("");
    setSubmittedByName("");
    setPending(false);
    setErrors({});
  };

  const handleOpenChange = (next: boolean) => {
    if (!next) reset();
    onOpenChange(next);
  };

  const toggleCategory = (category: string) => {
    setCategories((current) =>
      current.includes(category) ? current.filter((item) => item !== category) : [...current, category],
    );
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!rating) {
      toast.error(t("feedback.ratingRequired"));
      return;
    }
    setPending(true);
    setErrors({});
    try {
      await api.post("/api/feedback", {
        rating,
        categories,
        comment: comment || null,
        customerId: customerId || null,
        dealId: dealId || null,
        agentId: agentId || null,
        submittedByName: submittedByName || null,
      });
      toast.success(t("toast.created"));
      handleOpenChange(false);
      router.refresh();
    } catch (error) {
      const fields = fieldErrors(error);
      if (fields) setErrors(fields);
      toast.error(error instanceof ApiClientError ? error.message : t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquarePlus className="size-5 text-primary" />
            {t("feedback.logTitle")}
          </DialogTitle>
          <DialogDescription>{t("feedback.logHint")}</DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label>{t("feedback.rating")}</Label>
            <Stars value={rating} onChange={setRating} size="lg" />
            <p className="text-xs text-muted-foreground">
              {rating ? t("feedback.stars", { count: rating }) : t("feedback.ratingRequired")}
            </p>
          </div>

          <div className="space-y-2">
            <Label>{t("feedback.categories")}</Label>
            <p className="text-xs text-muted-foreground">{t("feedback.selectCategories")}</p>
            <div className="flex flex-wrap gap-2">
              {FEEDBACK_CATEGORIES.map((category) => {
                const active = categories.includes(category);
                return (
                  <button
                    key={category}
                    type="button"
                    aria-pressed={active}
                    onClick={() => toggleCategory(category)}
                    className={cn(
                      "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                      active
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-input text-muted-foreground hover:bg-accent",
                    )}
                  >
                    {enumLabel("feedbackCategory", category)}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>{t("feedback.customer")}</Label>
              <Select
                value={customerId || "__none"}
                onValueChange={(value) => setCustomerId(value === "__none" ? "" : value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t("feedback.selectCustomer")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">{t("feedback.noCustomer")}</SelectItem>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.fullName} · {customer.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>{t("feedback.deal")}</Label>
              <Select
                value={dealId || "__none"}
                onValueChange={(value) => {
                  const next = value === "__none" ? "" : value;
                  setDealId(next);
                  const deal = deals.find((item) => item.id === next);
                  if (deal) {
                    setCustomerId(deal.customerId);
                    setAgentId(deal.agentId);
                  }
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t("feedback.selectDeal")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">{t("feedback.noDeal")}</SelectItem>
                  {deals.map((deal) => (
                    <SelectItem key={deal.id} value={deal.id}>
                      {deal.title} · {deal.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {agents.length > 0 && (
              <div className="space-y-1.5">
                <Label>{t("feedback.agent")}</Label>
                <Select
                  value={agentId || "__none"}
                  onValueChange={(value) => setAgentId(value === "__none" ? "" : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("feedback.selectAgent")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none">{t("common.none")}</SelectItem>
                    {agents.map((agent) => (
                      <SelectItem key={agent.id} value={agent.id}>
                        {agent.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-1.5">
              <Label>{t("feedback.submittedBy")}</Label>
              <Input
                value={submittedByName}
                onChange={(event) => setSubmittedByName(event.target.value)}
                placeholder={t("feedback.submittedByPlaceholder")}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>
              {t("feedback.comment")}{" "}
              <span className="font-normal text-muted-foreground">({t("feedback.optionalComment")})</span>
            </Label>
            <Textarea
              value={comment}
              onChange={(event) => setComment(event.target.value)}
              placeholder={t("feedback.commentPlaceholder")}
              rows={4}
            />
            {errors.comment?.[0] && <p className="text-xs text-destructive">{errors.comment[0]}</p>}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => handleOpenChange(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {t("common.save")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
