"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  ImagePlus,
  Loader2,
  Save,
  Star,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api, fieldErrors } from "@/lib/client-api";
import { PROPERTY_PURPOSES, PROPERTY_STATUSES, PROPERTY_TAGS, PROPERTY_TYPES } from "@/lib/constants";
import { cn } from "@/lib/utils";
import type { PropertyImage } from "./types";

type FormState = {
  title: string;
  type: string;
  price: string;
  area: string;
  location: string;
  city: string;
  bedrooms: string;
  bathrooms: string;
  status: string;
  purpose: string;
  description: string;
  ownerName: string;
  ownerPhone: string;
  ownerEmail: string;
  ownerIdNumber: string;
  ownerNotes: string;
};

export type PropertyFormValues = Partial<{
  id: string;
  title: string;
  type: string;
  price: number;
  area: number;
  location: string;
  city: string;
  bedrooms: number | null;
  bathrooms: number | null;
  status: string;
  purpose: string;
  description: string | null;
  ownerName: string | null;
  ownerPhone: string | null;
  ownerEmail: string | null;
  ownerIdNumber: string | null;
  ownerNotes: string | null;
  tags: string | null;
  images: PropertyImage[];
}>;

export function PropertyForm({
  mode,
  property,
}: {
  mode: "create" | "edit";
  property?: PropertyFormValues;
}) {
  const { t, enumLabel } = useI18n();
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [images, setImages] = useState<Array<{ url: string; alt: string; isPrimary: boolean }>>(
    (property?.images ?? [])
      .slice()
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))
      .map((image, index) => ({
        url: image.url,
        alt: image.alt ?? "",
        isPrimary: image.isPrimary ?? index === 0,
      })),
  );
  const [tags, setTags] = useState<string[]>(property?.tags ? JSON.parse(property.tags) : []);
  const [imageUrl, setImageUrl] = useState("");
  const [imageAlt, setImageAlt] = useState("");
  const [imageError, setImageError] = useState("");
  const [form, setForm] = useState<FormState>({
    title: property?.title ?? "",
    type: property?.type ?? "APARTMENT",
    price: property?.price ? String(property.price) : "",
    area: property?.area ? String(property.area) : "",
    location: property?.location ?? "",
    city: property?.city ?? "",
    bedrooms: property?.bedrooms !== null && property?.bedrooms !== undefined ? String(property.bedrooms) : "",
    bathrooms:
      property?.bathrooms !== null && property?.bathrooms !== undefined ? String(property.bathrooms) : "",
    status: property?.status ?? "AVAILABLE",
    purpose: property?.purpose ?? "SALE",
    description: property?.description ?? "",
    ownerName: property?.ownerName ?? "",
    ownerPhone: property?.ownerPhone ?? "",
    ownerEmail: property?.ownerEmail ?? "",
    ownerIdNumber: property?.ownerIdNumber ?? "",
    ownerNotes: property?.ownerNotes ?? "",
  });

  const set = (key: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    if (errors[key]?.length) setErrors((current) => ({ ...current, [key]: [] }));
  };

  const errorFor = (key: string) => errors[key]?.[0];

  const addImage = () => {
    const url = imageUrl.trim();
    if (!url) return;
    try {
      new URL(url);
    } catch {
      setImageError(t("properties.imageUrl"));
      return;
    }
    if (images.some((image) => image.url === url)) {
      setImageError(t("properties.imageUrl"));
      return;
    }
    setImageError("");
    setImages((current) => [
      ...current,
      { url, alt: imageAlt.trim(), isPrimary: current.length === 0 },
    ]);
    setImageUrl("");
    setImageAlt("");
  };

  const removeImage = (index: number) => {
    setImages((current) => {
      const next = current.filter((_, i) => i !== index);
      if (next.length && !next.some((image) => image.isPrimary)) next[0].isPrimary = true;
      return next;
    });
  };

  const moveImage = (index: number, direction: -1 | 1) => {
    setImages((current) => {
      const next = [...current];
      const target = index + direction;
      if (target < 0 || target >= next.length) return current;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  };

  const makePrimary = (index: number) => {
    setImages((current) => current.map((image, i) => ({ ...image, isPrimary: i === index })));
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setPending(true);
    setErrors({});
    const normalizedImages =
      images.length && !images.some((image) => image.isPrimary)
        ? images.map((image, index) => ({ ...image, isPrimary: index === 0 }))
        : images;
    try {
      const payload = {
        title: form.title,
        type: form.type,
        price: form.price,
        area: form.area,
        location: form.location,
        city: form.city,
        bedrooms: form.bedrooms || null,
        bathrooms: form.bathrooms || null,
        status: form.status,
        purpose: form.purpose,
        description: form.description || null,
        ownerName: form.ownerName || null,
        ownerPhone: form.ownerPhone || null,
        ownerEmail: form.ownerEmail || null,
        ownerIdNumber: form.ownerIdNumber || null,
        ownerNotes: form.ownerNotes || null,
        tags,
        images: normalizedImages.map((image) => ({
          url: image.url,
          alt: image.alt || null,
          isPrimary: image.isPrimary,
        })),
      };

      if (mode === "create") {
        const created = await api.post<{ id: string }>("/api/properties", payload);
        toast.success(t("toast.created"));
        router.push(`/properties/${created.id}`);
      } else if (property?.id) {
        await api.patch(`/api/properties/${property.id}`, payload);
        toast.success(t("toast.updated"));
        router.push(`/properties/${property.id}`);
      }
      router.refresh();
    } catch (error) {
      const fields = fieldErrors(error);
      if (fields) setErrors(fields);
      toast.error(fields ? t("common.requiredField") : t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const backHref = property?.id ? `/properties/${property.id}` : "/properties";

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href={backHref}>
            <ArrowLeft className="rtl:rotate-180" />
            {t("common.back")}
          </Link>
        </Button>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("properties.details")}</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <Field label={t("properties.titleField")} required error={errorFor("title")} className="sm:col-span-2">
              <Input
                value={form.title}
                onChange={(event) => set("title", event.target.value)}
                required
                maxLength={160}
                autoFocus
              />
            </Field>
            <Field label={t("properties.location")} required error={errorFor("location")}>
              <Input
                value={form.location}
                onChange={(event) => set("location", event.target.value)}
                required
                maxLength={160}
              />
            </Field>
            <Field label={t("properties.city")} error={errorFor("city")}>
              <Input
                value={form.city}
                onChange={(event) => set("city", event.target.value)}
                maxLength={80}
              />
            </Field>
            <Field label={t("properties.price")} required error={errorFor("price")}>
              <Input
                type="number"
                min={1}
                step={1}
                value={form.price}
                onChange={(event) => set("price", event.target.value)}
                required
                dir="ltr"
              />
            </Field>
            <Field label={`${t("properties.area")} (${t("properties.sqm")})`} required error={errorFor("area")}>
              <Input
                type="number"
                min={1}
                step="any"
                value={form.area}
                onChange={(event) => set("area", event.target.value)}
                required
                dir="ltr"
              />
            </Field>
            <Field label={t("properties.bedrooms")} error={errorFor("bedrooms")}>
              <Input
                type="number"
                min={0}
                value={form.bedrooms}
                onChange={(event) => set("bedrooms", event.target.value)}
                dir="ltr"
              />
            </Field>
            <Field label={t("properties.bathrooms")} error={errorFor("bathrooms")}>
              <Input
                type="number"
                min={0}
                value={form.bathrooms}
                onChange={(event) => set("bathrooms", event.target.value)}
                dir="ltr"
              />
            </Field>
            <Field label={t("properties.description")} error={errorFor("description")} className="sm:col-span-2">
              <Textarea
                value={form.description}
                onChange={(event) => set("description", event.target.value)}
                rows={4}
                maxLength={3000}
              />
            </Field>
          </CardContent>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("properties.details")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Field label={t("properties.type")}>
                <Select value={form.type} onValueChange={(value) => set("type", value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PROPERTY_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {enumLabel("propertyType", type)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label={t("properties.purpose")}>
                <Select value={form.purpose} onValueChange={(value) => set("purpose", value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PROPERTY_PURPOSES.map((purpose) => (
                      <SelectItem key={purpose} value={purpose}>
                        {enumLabel("propertyPurpose", purpose)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label={t("properties.status")}>
                <Select value={form.status} onValueChange={(value) => set("status", value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PROPERTY_STATUSES.map((status) => (
                      <SelectItem key={status} value={status}>
                        {enumLabel("propertyStatus", status)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("properties.images")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {images.length === 0 ? (
                <p className="rounded-lg border border-dashed p-4 text-center text-xs text-muted-foreground">
                  {t("properties.noImages")}
                </p>
              ) : (
                <ul className="space-y-2">
                  {images.map((image, index) => (
                    <li
                      key={`${image.url}-${index}`}
                      className={cn(
                        "flex items-center gap-2 rounded-lg border p-2",
                        image.isPrimary && "border-primary/50 bg-primary/5",
                      )}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={image.url}
                        alt={image.alt || ""}
                        className="size-12 shrink-0 rounded-md object-cover"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs">{image.alt || image.url}</p>
                        {image.isPrimary && (
                          <span className="mt-0.5 inline-flex items-center gap-1 text-[10px] font-medium text-primary">
                            <Star className="size-3 fill-current" />
                            {t("properties.primary")}
                          </span>
                        )}
                      </div>
                      <div className="flex shrink-0 items-center gap-0.5">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon-sm"
                          disabled={index === 0}
                          onClick={() => moveImage(index, -1)}
                          aria-label="Move up"
                        >
                          <ArrowUp />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon-sm"
                          disabled={index === images.length - 1}
                          onClick={() => moveImage(index, 1)}
                          aria-label="Move down"
                        >
                          <ArrowDown />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon-sm"
                          disabled={image.isPrimary}
                          onClick={() => makePrimary(index)}
                          aria-label={t("properties.makePrimary")}
                        >
                          <Star />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon-sm"
                          className="text-destructive hover:text-destructive"
                          onClick={() => removeImage(index)}
                          aria-label={t("properties.removeImage")}
                        >
                          <Trash2 />
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}

              <div className="space-y-2 rounded-lg border border-dashed p-3">
                <Input
                  type="url"
                  value={imageUrl}
                  onChange={(event) => {
                    setImageUrl(event.target.value);
                    setImageError("");
                  }}
                  placeholder={`${t("properties.imageUrl")}…`}
                  dir="ltr"
                />
                <Input
                  value={imageAlt}
                  onChange={(event) => setImageAlt(event.target.value)}
                  placeholder={`${t("common.description")} (${t("common.optional")})`}
                  maxLength={160}
                />
                {imageError && <p className="text-xs text-destructive">{imageError}</p>}
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={addImage}
                  disabled={!imageUrl.trim() || images.length >= 10}
                >
                  <ImagePlus />
                  {t("properties.addImage")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("properties.owner")}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <Field label={t("properties.ownerName")} error={errorFor("ownerName")}>
            <Input
              value={form.ownerName}
              onChange={(event) => set("ownerName", event.target.value)}
              maxLength={160}
            />
          </Field>
          <Field label={t("properties.ownerPhone")} error={errorFor("ownerPhone")}>
            <Input
              type="tel"
              value={form.ownerPhone}
              onChange={(event) => set("ownerPhone", event.target.value)}
              maxLength={40}
              dir="ltr"
            />
          </Field>
          <Field label={t("properties.ownerEmail")} error={errorFor("ownerEmail")}>
            <Input
              type="email"
              value={form.ownerEmail}
              onChange={(event) => set("ownerEmail", event.target.value)}
              maxLength={160}
              dir="ltr"
            />
          </Field>
          <Field label={t("properties.ownerIdNumber")} error={errorFor("ownerIdNumber")}>
            <Input
              value={form.ownerIdNumber}
              onChange={(event) => set("ownerIdNumber", event.target.value)}
              maxLength={60}
              dir="ltr"
            />
          </Field>
          <Field label={t("properties.ownerNotes")} error={errorFor("ownerNotes")} className="sm:col-span-2">
            <Textarea
              value={form.ownerNotes}
              onChange={(event) => set("ownerNotes", event.target.value)}
              rows={3}
              maxLength={1000}
            />
          </Field>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("properties.tags")}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          {PROPERTY_TAGS.map((tag) => (
            <label key={tag} className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={tags.includes(tag)}
                onCheckedChange={(checked) =>
                  setTags((current) =>
                    checked ? [...current, tag] : current.filter((item) => item !== tag),
                  )
                }
              />
              {enumLabel("propertyTag", tag)}
            </label>
          ))}
        </CardContent>
      </Card>

      <div className="flex items-center justify-end gap-2">
        <Button type="button" variant="outline" asChild disabled={pending}>
          <Link href={backHref}>{t("common.cancel")}</Link>
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />}
          {mode === "create" ? t("common.create") : t("common.save")}
        </Button>
      </div>
    </form>
  );
}

function Field({
  label,
  required,
  error,
  children,
  className,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
  className?: string;
}) {
  const { t } = useI18n();
  return (
    <div className={className}>
      <Label className="mb-1.5 block">
        {label}
        {required ? (
          <span className="ms-0.5 text-destructive">*</span>
        ) : (
          <span className="ms-1 text-[10px] font-normal text-muted-foreground">({t("common.optional")})</span>
        )}
      </Label>
      {children}
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}

