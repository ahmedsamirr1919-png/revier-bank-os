"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2, Search, UserPlus } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { cn } from "@/lib/utils";
import type { CustomerOption } from "./types";

type CustomerResponse = { items: CustomerOption[]; total: number };

export function PropertyLinkDialog({
  open,
  onOpenChange,
  propertyId,
  linkedCustomerIds,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  propertyId: string;
  linkedCustomerIds: string[];
}) {
  const { t } = useI18n();
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [customers, setCustomers] = useState<CustomerOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [pending, setPending] = useState(false);
  const [selected, setSelected] = useState("");
  const [relation, setRelation] = useState<"INTERESTED" | "PURCHASED">("INTERESTED");

  useEffect(() => {
    if (!open) return;
    const controller = new AbortController();
    setLoading(true);
    const timer = setTimeout(() => {
      api
        .get<CustomerResponse>(
          `/api/customers?pageSize=20&sort=name${query.trim() ? `&q=${encodeURIComponent(query.trim())}` : ""}`,
          controller.signal,
        )
        .then((data) => setCustomers(data.items))
        .catch(() => {
          if (!controller.signal.aborted) setCustomers([]);
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
    }, 300);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [open, query]);

  useEffect(() => {
    if (!open) {
      setQuery("");
      setSelected("");
      setRelation("INTERESTED");
    }
  }, [open]);

  const link = async () => {
    if (!selected) return;
    setPending(true);
    try {
      await api.post(`/api/properties/${propertyId}/links`, {
        customerId: selected,
        relation,
      });
      toast.success(t("properties.linkAdded"));
      onOpenChange(false);
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{t("properties.linkCustomer")}</DialogTitle>
          <DialogDescription>{t("properties.linkedCustomers")}</DialogDescription>
        </DialogHeader>

        <div className="relative">
          <Search className="pointer-events-none absolute start-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t("customers.searchPlaceholder")}
            className="ps-8"
            autoFocus
          />
        </div>

        <div className="max-h-64 space-y-1 overflow-y-auto rounded-lg border p-1">
          {loading ? (
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              <Loader2 className="size-4 animate-spin" />
            </div>
          ) : customers.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">{t("common.noResults")}</p>
          ) : (
            customers.map((customer) => {
              const alreadyLinked = linkedCustomerIds.includes(customer.id);
              return (
                <button
                  key={customer.id}
                  type="button"
                  disabled={alreadyLinked}
                  onClick={() => setSelected(customer.id)}
                  className={cn(
                    "flex w-full items-center justify-between gap-3 rounded-md px-3 py-2 text-start text-sm transition-colors",
                    selected === customer.id ? "bg-primary/10 text-primary" : "hover:bg-muted",
                    alreadyLinked && "cursor-not-allowed opacity-50",
                  )}
                >
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{customer.fullName}</span>
                    <span className="block truncate text-xs text-muted-foreground" dir="ltr">
                      {customer.code} · {customer.phone}
                    </span>
                  </span>
                  {selected === customer.id && <Check className="size-4 shrink-0" />}
                  {alreadyLinked && <span className="shrink-0 text-xs">{t("properties.alreadyLinked")}</span>}
                </button>
              );
            })
          )}
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
            {t("properties.relation")}
          </label>
          <Select value={relation} onValueChange={(value) => setRelation(value as typeof relation)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="INTERESTED">{t("properties.interested")}</SelectItem>
              <SelectItem value="PURCHASED">{t("properties.purchased")}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t("common.cancel")}
          </Button>
          <Button onClick={link} disabled={!selected || pending}>
            {pending ? <Loader2 className="animate-spin" /> : <UserPlus />}
            {t("properties.addLink")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
