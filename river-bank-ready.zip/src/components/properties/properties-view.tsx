"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  Bath,
  BedDouble,
  Building2,
  Eye,
  Loader2,
  MapPin,
  MoreHorizontal,
  Pencil,
  RotateCcw,
  Ruler,
  Trash2,
  UserRound,
} from "lucide-react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { SearchInput } from "@/components/shared/search-input";
import { Pagination } from "@/components/shared/pagination";
import { EmptyState } from "@/components/shared/empty-state";
import { StatusBadge } from "@/components/shared/status-badge";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { PAGE_SIZE, PROPERTY_PURPOSES, PROPERTY_STATUSES, PROPERTY_TAGS, PROPERTY_TYPES } from "@/lib/constants";
import { cn, formatCurrency, formatNumber } from "@/lib/utils";
import type { PropertyFilters, PropertyListItem } from "./types";

export function PropertiesView({
  items,
  total,
  page,
  pageSize,
  pages,
  filters,
  canDelete,
}: {
  items: PropertyListItem[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
  filters: PropertyFilters;
  canDelete: boolean;
}) {
  const { t, enumLabel, locale } = useI18n();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [deleteTarget, setDeleteTarget] = useState<PropertyListItem | null>(null);
  const [pending, setPending] = useState(false);

  const setFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value && value !== "all") params.set(key, value);
    else params.delete(key);
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  };

  const remove = async () => {
    if (!deleteTarget) return;
    setPending(true);
    try {
      await api.delete(`/api/properties/${deleteTarget.id}`);
      toast.success(t("toast.deleted"));
      setDeleteTarget(null);
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const restore = async (property: PropertyListItem) => {
    try {
      await api.post(`/api/properties/${property.id}/restore`);
      toast.success(t("common.saved"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    }
  };

  return (
    <>
      <Card className="overflow-hidden">
        <div className="flex flex-col gap-3 border-b p-4 lg:flex-row lg:items-center lg:justify-between">
          <SearchInput
            placeholder={t("properties.searchPlaceholder")}
            className="w-full lg:max-w-sm"
          />
          <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:items-center">
            <Select value={filters.type || "all"} onValueChange={(value) => setFilter("type", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("properties.filterType")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {PROPERTY_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>
                    {enumLabel("propertyType", type)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.tag || "all"} onValueChange={(value) => setFilter("tag", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("properties.tags")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {PROPERTY_TAGS.map((tag) => (
                  <SelectItem key={tag} value={tag}>
                    {enumLabel("propertyTag", tag)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.purpose || "all"} onValueChange={(value) => setFilter("purpose", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("properties.purpose")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {PROPERTY_PURPOSES.map((purpose) => (
                  <SelectItem key={purpose} value={purpose}>
                    {enumLabel("propertyPurpose", purpose)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filters.status || "all"} onValueChange={(value) => setFilter("status", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("properties.filterStatus")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {PROPERTY_STATUSES.map((status) => (
                  <SelectItem key={status} value={status}>
                    {enumLabel("propertyStatus", status)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.sort} onValueChange={(value) => setFilter("sort", value)}>
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue placeholder={t("common.sortBy")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">{t("common.newest")}</SelectItem>
                <SelectItem value="oldest">{t("common.oldest")}</SelectItem>
                <SelectItem value="price_asc">{t("properties.price")} ↑</SelectItem>
                <SelectItem value="price_desc">{t("properties.price")} ↓</SelectItem>
                <SelectItem value="area">{t("properties.area")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {items.length === 0 ? (
          <EmptyState
            icon={Building2}
            title={t("common.noResults")}
            description={t("common.noResultsHint")}
            action={
              !filters.trash ? (
                <Button size="sm" asChild>
                  <Link href="/properties/new">{t("properties.new")}</Link>
                </Button>
              ) : undefined
            }
          />
        ) : (
          <div className="grid gap-4 p-4 sm:grid-cols-2 xl:grid-cols-3">
            {items.map((property) => {
              const image = property.images[0];
              return (
                <div
                  key={property.id}
                  className={cn(
                    "group overflow-hidden rounded-xl border bg-card transition-shadow hover:shadow-md",
                    property.isDeleted && "opacity-75",
                  )}
                >
                  <div className="relative aspect-[16/10] overflow-hidden bg-muted">
                    <Link href={`/properties/${property.id}`} aria-label={property.title}>
                      {image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={image.url}
                          alt={image.alt ?? property.title}
                          className="size-full object-cover transition-transform duration-300 group-hover:scale-105"
                          loading="lazy"
                        />
                      ) : (
                        <span className="flex size-full items-center justify-center text-muted-foreground">
                          <Building2 className="size-8" />
                        </span>
                      )}
                    </Link>
                    <div className="absolute start-3 top-3 flex items-center gap-2">
                      <StatusBadge value={property.status} group="propertyStatus" />
                      {property.isDeleted && (
                        <span className="rounded-full bg-destructive px-2 py-0.5 text-xs font-medium text-white">
                          {t("customers.trash")}
                        </span>
                      )}
                    </div>
                    <span className="absolute end-3 top-3 rounded-full bg-background/90 px-2 py-0.5 text-[11px] font-medium text-muted-foreground backdrop-blur">
                      {property.code}
                    </span>
                    <div className="absolute end-2 bottom-2 opacity-100 sm:opacity-0 sm:transition-opacity sm:group-hover:opacity-100">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="secondary"
                            size="icon-sm"
                            className="bg-background/90 backdrop-blur"
                            aria-label={t("common.actions")}
                          >
                            <MoreHorizontal />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-44">
                          <DropdownMenuLabel className="text-xs">{property.code}</DropdownMenuLabel>
                          <DropdownMenuItem asChild>
                            <Link href={`/properties/${property.id}`}>
                              <Eye />
                              {t("common.view")}
                            </Link>
                          </DropdownMenuItem>
                          {!property.isDeleted && (
                            <DropdownMenuItem asChild>
                              <Link href={`/properties/${property.id}/edit`}>
                                <Pencil />
                                {t("common.edit")}
                              </Link>
                            </DropdownMenuItem>
                          )}
                          {property.isDeleted && canDelete && (
                            <DropdownMenuItem onSelect={() => void restore(property)}>
                              <RotateCcw />
                              {t("customers.restore")}
                            </DropdownMenuItem>
                          )}
                          {!property.isDeleted && canDelete && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="text-destructive focus:text-destructive"
                                onSelect={() => setDeleteTarget(property)}
                              >
                                <Trash2 />
                                {t("common.delete")}
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>

                  <div className="space-y-2.5 p-4">
                    <div>
                      <Link
                        href={`/properties/${property.id}`}
                        className="line-clamp-1 font-semibold hover:underline"
                      >
                        {property.title}
                      </Link>
                      <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                        <MapPin className="size-3 shrink-0" />
                        <span className="truncate">
                          {property.location}, {property.city}
                        </span>
                      </p>
                      {property.ownerName && (
                        <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                          <UserRound className="size-3 shrink-0" />
                          <span className="truncate">{property.ownerName}</span>
                        </p>
                      )}
                      {(() => {
                        const tags = property.tags ? (JSON.parse(property.tags) as string[]) : [];
                        return tags.length ? (
                          <div className="mt-1 flex flex-wrap gap-1">
                            {tags.map((tag) => (
                              <span
                                key={tag}
                                className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary"
                              >
                                {enumLabel("propertyTag", tag)}
                              </span>
                            ))}
                          </div>
                        ) : null;
                      })()}
                    </div>

                    <div className="flex items-center justify-between">
                      <p className="text-lg font-semibold text-primary" dir="ltr">
                        {formatCurrency(property.price, locale)}
                      </p>
                      <span className="text-xs text-muted-foreground">
                        {enumLabel("propertyType", property.type)}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-t pt-2.5 text-xs text-muted-foreground">
                      {property.bedrooms !== null && (
                        <span className="flex items-center gap-1">
                          <BedDouble className="size-3.5" />
                          {formatNumber(property.bedrooms, locale)} {t("properties.beds")}
                        </span>
                      )}
                      {property.bathrooms !== null && (
                        <span className="flex items-center gap-1">
                          <Bath className="size-3.5" />
                          {formatNumber(property.bathrooms, locale)} {t("properties.baths")}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Ruler className="size-3.5" />
                        {formatNumber(property.area, locale)} {t("properties.sqm")}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                      <span>
                        {property._count.interests} {t("properties.interested")}
                      </span>
                      <span>
                        {property._count.deals} {t("customers.deals")}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <Pagination page={page} pages={pages} total={total} pageSize={pageSize || PAGE_SIZE} />
      </Card>

      <AlertDialog open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("properties.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("properties.deleteBody")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={remove} disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

