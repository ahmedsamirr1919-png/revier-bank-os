export type PropertyImage = {
  id: string;
  url: string;
  alt: string | null;
  isPrimary?: boolean;
  sortOrder?: number;
};

export type PropertyListItem = {
  id: string;
  code: string;
  title: string;
  type: string;
  price: number;
  area: number;
  location: string;
  city: string;
  bedrooms: number | null;
  bathrooms: number | null;
  status: string;
  ownerName: string | null;
  ownerPhone: string | null;
  tags: string | null;
  purpose: string;
  isDeleted: boolean;
  createdAt: Date | string;
  images: Array<{ id: string; url: string; alt: string | null }>;
  _count: { interests: number; deals: number };
};

export type PropertyFilters = {
  q: string;
  type: string;
  tag: string;
  purpose: string;
  status: string;
  sort: string;
  trash: string;
};

export type CustomerOption = {
  id: string;
  code: string;
  fullName: string;
  phone: string;
  status: string;
};
