"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Link2, Loader2, Pencil, RotateCcw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { PropertyLinkDialog } from "./property-link-dialog";

export function PropertyDetailActions({
  property,
  linkedCustomerIds,
  canDelete,
  isDeleted,
}: {
  property: { id: string; title: string };
  linkedCustomerIds: string[];
  canDelete: boolean;
  isDeleted: boolean;
}) {
  const { t } = useI18n();
  const router = useRouter();
  const [linkOpen, setLinkOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [pending, setPending] = useState(false);

  const remove = async () => {
    setPending(true);
    try {
      await api.delete(`/api/properties/${property.id}`);
      toast.success(t("toast.deleted"));
      setDeleteOpen(false);
      router.push("/properties");
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const restore = async () => {
    setPending(true);
    try {
      await api.post(`/api/properties/${property.id}/restore`);
      toast.success(t("common.saved"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  if (isDeleted) {
    return canDelete ? (
      <Button variant="outline" size="sm" onClick={restore} disabled={pending}>
        {pending ? <Loader2 className="animate-spin" /> : <RotateCcw />}
        {t("customers.restore")}
      </Button>
    ) : null;
  }

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setLinkOpen(true)}>
        <Link2 />
        {t("properties.linkCustomer")}
      </Button>
      <Button variant="outline" size="sm" asChild>
        <Link href={`/properties/${property.id}/edit`}>
          <Pencil />
          {t("common.edit")}
        </Link>
      </Button>
      {canDelete && (
        <Button
          variant="outline"
          size="sm"
          className="text-destructive hover:text-destructive"
          onClick={() => setDeleteOpen(true)}
        >
          <Trash2 />
          {t("common.delete")}
        </Button>
      )}

      <PropertyLinkDialog
        open={linkOpen}
        onOpenChange={setLinkOpen}
        propertyId={property.id}
        linkedCustomerIds={linkedCustomerIds}
      />

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("properties.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("properties.deleteBody")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={remove} disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
