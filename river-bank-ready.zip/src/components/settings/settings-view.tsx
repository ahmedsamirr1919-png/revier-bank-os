"use client";

import { useEffect, useState } from "react";
import { Loader2, Save, Download } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { Plus, Trash2 } from "lucide-react";

const KEYS = {
  company: "company.name",
  currency: "app.currency",
  commission: "app.commissionRate",
  threshold: "feedback.negativeThreshold",
  staleDays: "settings.staleLeadDays",
};

export function SettingsView() {
  const { t } = useI18n();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    company: "River Bank",
    currency: "EGP",
    commission: "2.5",
    threshold: "2",
    staleDays: "14",
  });

  type Synonym = { id: string; term: string; canonical: string; module: string | null };
  const [synonyms, setSynonyms] = useState<Synonym[]>([]);
  const [synTerm, setSynTerm] = useState("");
  const [synCanonical, setSynCanonical] = useState("");

  const loadSynonyms = async () => {
    try {
      const data = await api.get<Synonym[]>("/api/synonyms");
      setSynonyms(data);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    loadSynonyms();
  }, []);

  useEffect(() => {
    api
      .get<Array<{ key: string; value: string }>>("/api/settings")
      .then((settings) => {
        const map = new Map(settings.map((item) => [item.key, item.value]));
        setForm({
          company: map.get(KEYS.company) ?? "River Bank",
          currency: map.get(KEYS.currency) ?? "EGP",
          commission: map.get(KEYS.commission) ?? "2.5",
          threshold: map.get(KEYS.threshold) ?? "2",
          staleDays: map.get(KEYS.staleDays) ?? "14",
        });
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const save = async () => {
    setSaving(true);
    try {
      await Promise.all([
        api.patch("/api/settings", { key: KEYS.company, value: form.company }),
        api.patch("/api/settings", { key: KEYS.currency, value: form.currency }),
        api.patch("/api/settings", { key: KEYS.commission, value: form.commission }),
        api.patch("/api/settings", { key: KEYS.threshold, value: form.threshold }),
        api.patch("/api/settings", { key: KEYS.staleDays, value: form.staleDays }),
      ]);
      toast.success(t("settings.saved"));
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16 text-muted-foreground">
        <Loader2 className="mr-2 animate-spin" />
        {t("common.loading")}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold tracking-tight md:text-2xl">{t("settings.title")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("settings.subtitle")}</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("settings.company")}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5 sm:col-span-2">
            <Label>{t("settings.companyName")}</Label>
            <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>{t("settings.currency")}</Label>
            <Input value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>{t("settings.commissionRate")}</Label>
            <Input
              type="number"
              step="0.1"
              value={form.commission}
              onChange={(e) => setForm({ ...form, commission: e.target.value })}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("leads.title")}</CardTitle>
        </CardHeader>
        <CardContent className="max-w-sm space-y-1.5">
          <Label>{t("settings.staleLeadDays")}</Label>
          <Input
            type="number"
            min={1}
            max={90}
            value={form.staleDays}
            onChange={(e) => setForm({ ...form, staleDays: e.target.value })}
          />
          <p className="text-xs text-muted-foreground">{t("leads.staleHint")}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("feedback.title")}</CardTitle>
        </CardHeader>
        <CardContent className="max-w-sm space-y-1.5">
          <Label>{t("settings.negativeThreshold")}</Label>
          <Input
            type="number"
            min={1}
            max={5}
            value={form.threshold}
            onChange={(e) => setForm({ ...form, threshold: e.target.value })}
          />
          <p className="text-xs text-muted-foreground">
            {t("feedback.alertHint", { threshold: Number(form.threshold) || 2 })}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("settings.synonymsTitle")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-col gap-2 sm:flex-row">
            <Input placeholder={t("settings.synonymTerm")} value={synTerm} onChange={(e) => setSynTerm(e.target.value)} />
            <Input placeholder={t("settings.synonymCanonical")} value={synCanonical} onChange={(e) => setSynCanonical(e.target.value)} />
            <Button
              size="sm"
              onClick={async () => {
                if (!synTerm || !synCanonical) return;
                try {
                  await api.post("/api/synonyms", { term: synTerm, canonical: synCanonical });
                  setSynTerm("");
                  setSynCanonical("");
                  loadSynonyms();
                  toast.success(t("toast.created"));
                } catch {
                  toast.error(t("toast.error"));
                }
              }}
            >
              <Plus />
            </Button>
          </div>
          <ul className="divide-y">
            {synonyms.map((syn) => (
              <li key={syn.id} className="flex items-center justify-between py-2 text-sm">
                <span>
                  {syn.term} <span className="text-muted-foreground">→</span> {syn.canonical}
                </span>
                <Button
                  size="icon-sm"
                  variant="ghost"
                  onClick={async () => {
                    try {
                      await api.delete(`/api/synonyms/${syn.id}`);
                      loadSynonyms();
                    } catch {
                      toast.error(t("toast.error"));
                    }
                  }}
                >
                  <Trash2 />
                </Button>
              </li>
            ))}
            {synonyms.length === 0 && (
              <li className="py-4 text-center text-sm text-muted-foreground">{t("common.noResults")}</li>
            )}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("settings.backup")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-xs text-muted-foreground">{t("settings.backupHint")}</p>
          <Button variant="outline" asChild>
            <a href="/api/backup" download>
              <Download />
              {t("settings.downloadBackup")}
            </a>
          </Button>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving}>
          {saving && <Loader2 className="animate-spin" />}
          <Save />
          {t("settings.save")}
        </Button>
      </div>
    </div>
  );
}
