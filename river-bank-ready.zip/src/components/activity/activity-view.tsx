"use client";

import { useEffect, useState } from "react";
import { Activity as ActivityIcon, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { formatDate } from "@/lib/utils";

type Log = {
  id: string;
  action: string;
  entityType: string;
  entityId: string | null;
  description: string;
  userEmail: string | null;
  createdAt: string;
  user: { id: string; name: string; role: string } | null;
};

export function ActivityView() {
  const { t, locale } = useI18n();
  const [items, setItems] = useState<Log[]>([]);
  const [total, setTotal] = useState(0);
  const [q, setQ] = useState("");
  const [userId, setUserId] = useState("");
  const [users, setUsers] = useState<Array<{ id: string; name: string }>>([]);
  const [loading, setLoading] = useState(true);

  const load = async (search?: string, selectedUser?: string) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set("q", search);
      if (selectedUser) params.set("userId", selectedUser);
      params.set("pageSize", "50");
      const data = await api.get<{ items: Log[]; total: number }>(`/api/activity?${params.toString()}`);
      setItems(data.items);
      setTotal(data.total);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    api
      .get<{ items: Array<{ id: string; name: string }> }>("/api/activity/users")
      .then((data) => setUsers(data.items.map((u) => ({ id: u.id, name: u.name }))))
      .catch(() => {});
  }, []);

  useEffect(() => {
    load(q, userId);
  }, [userId]);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold tracking-tight md:text-2xl">{t("activity.title")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("activity.subtitle")}</p>
      </div>

      <Card>
        <CardHeader className="flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle className="text-base">{t("activity.title")}</CardTitle>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Select value={userId || "all"} onValueChange={(value) => setUserId(value === "all" ? "" : value)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder={t("activity.allUsers")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("activity.allUsers")}</SelectItem>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              placeholder={t("common.search")}
              className="w-64"
              value={q}
              onChange={(event) => setQ(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") load(q, userId);
              }}
            />
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-10 text-muted-foreground">
              <Loader2 className="mr-2 animate-spin" />
              {t("common.loading")}
            </div>
          ) : items.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">{t("common.noResults")}</p>
          ) : (
            <ul className="divide-y">
              {items.map((item) => (
                <li key={item.id} className="flex flex-col gap-1 py-3 text-sm">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-medium">{item.user?.name ?? item.userEmail ?? "—"}</span>
                    <span className="text-xs text-muted-foreground">{formatDate(item.createdAt, locale, true)}</span>
                  </div>
                  <p className="text-muted-foreground">{item.description}</p>
                  <p className="text-xs text-muted-foreground">
                    {item.action} · {item.entityType}{item.entityId ? ` · ${item.entityId}` : ""}
                  </p>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-xs text-muted-foreground">
            {total} {t("common.results") ?? "results"}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
