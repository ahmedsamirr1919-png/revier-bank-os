"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api, fieldErrors } from "@/lib/client-api";
import { TASK_PRIORITIES, TASK_STATUSES, TASK_TYPES } from "@/lib/constants";
import type {
  AgentOption,
  CustomerOption,
  DealOption,
  PropertyOption,
  TaskFormValues,
} from "./types";

type FormState = {
  title: string;
  description: string;
  type: string;
  priority: string;
  status: string;
  dueAt: string;
  customerId: string;
  dealId: string;
  propertyId: string;
  assignedToId: string;
};

function toDateTimeInput(value: Date | string | null | undefined) {
  if (!value) return "";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "";
  const pad = (part: number) => String(part).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(
    date.getHours(),
  )}:${pad(date.getMinutes())}`;
}

function defaultDueAt(value?: string | null) {
  if (!value) return "";
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? `${value}T09:00` : value;
}

export function TaskForm({
  mode,
  task,
  customers,
  deals,
  properties,
  agents,
  canAssignAgent,
  defaults,
}: {
  mode: "create" | "edit";
  task?: TaskFormValues;
  customers: CustomerOption[];
  deals: DealOption[];
  properties: PropertyOption[];
  agents: AgentOption[];
  canAssignAgent: boolean;
  defaults?: {
    customerId?: string;
    dealId?: string;
    propertyId?: string;
    dueAt?: string;
  };
}) {
  const { t, enumLabel } = useI18n();
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [form, setForm] = useState<FormState>({
    title: task?.title ?? "",
    description: task?.description ?? "",
    type: task?.type ?? "CALL_BACK",
    priority: task?.priority ?? "MEDIUM",
    status: task?.status ?? "PENDING",
    dueAt: task?.dueAt ? toDateTimeInput(task.dueAt) : defaultDueAt(defaults?.dueAt),
    customerId: task?.customerId ?? defaults?.customerId ?? "",
    dealId: task?.dealId ?? defaults?.dealId ?? "",
    propertyId: task?.propertyId ?? defaults?.propertyId ?? "",
    assignedToId: task?.assignedToId ?? "",
  });

  const set = (key: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    if (errors[key]?.length) setErrors((current) => ({ ...current, [key]: [] }));
  };

  const errorFor = (key: string) => errors[key]?.[0];

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setPending(true);
    setErrors({});
    try {
      const payload = {
        title: form.title,
        description: form.description || null,
        type: form.type,
        priority: form.priority,
        status: form.status,
        dueAt: form.dueAt,
        customerId: form.customerId || null,
        dealId: form.dealId || null,
        propertyId: form.propertyId || null,
        assignedToId: form.assignedToId || null,
      };

      if (mode === "create") {
        await api.post("/api/tasks", payload);
        toast.success(t("toast.created"));
        router.push("/tasks");
      } else if (task?.id) {
        await api.patch(`/api/tasks/${task.id}`, payload);
        toast.success(t("toast.updated"));
        router.push("/tasks");
      }
      router.refresh();
    } catch (error) {
      const fields = fieldErrors(error);
      if (fields) setErrors(fields);
      toast.error(fields ? t("common.requiredField") : t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/tasks">
            <ArrowLeft className="rtl:rotate-180" />
            {t("common.back")}
          </Link>
        </Button>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("tasks.title")}</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <Field label={t("tasks.titleField")} required error={errorFor("title")} className="sm:col-span-2">
              <Input
                value={form.title}
                onChange={(event) => set("title", event.target.value)}
                required
                maxLength={160}
                autoFocus
              />
            </Field>

            <Field label={t("tasks.type")} error={errorFor("type")}>
              <Select value={form.type} onValueChange={(value) => set("type", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TASK_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>
                      {enumLabel("taskType", type)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <Field label={t("tasks.priority")} error={errorFor("priority")}>
              <Select value={form.priority} onValueChange={(value) => set("priority", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TASK_PRIORITIES.map((priority) => (
                    <SelectItem key={priority} value={priority}>
                      {enumLabel("taskPriority", priority)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <Field label={t("tasks.dueAt")} required error={errorFor("dueAt")}>
              <Input
                type="datetime-local"
                value={form.dueAt}
                onChange={(event) => set("dueAt", event.target.value)}
                required
                dir="ltr"
              />
            </Field>

            <Field label={t("tasks.status")} error={errorFor("status")}>
              <Select value={form.status} onValueChange={(value) => set("status", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TASK_STATUSES.map((status) => (
                    <SelectItem key={status} value={status}>
                      {enumLabel("taskStatus", status)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <Field label={t("tasks.description")} error={errorFor("description")} className="sm:col-span-2">
              <Textarea
                value={form.description}
                onChange={(event) => set("description", event.target.value)}
                rows={4}
                maxLength={2000}
              />
            </Field>
          </CardContent>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("common.details")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Field label={t("tasks.customer")} error={errorFor("customerId")}>
                <Select
                  value={form.customerId || "none"}
                  onValueChange={(value) => set("customerId", value === "none" ? "" : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("deals.selectCustomer")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t("common.none")}</SelectItem>
                    {customers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id}>
                        {customer.fullName} · {customer.code}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>

              <Field label={t("tasks.deal")} error={errorFor("dealId")}>
                <Select
                  value={form.dealId || "none"}
                  onValueChange={(value) => set("dealId", value === "none" ? "" : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("deals.title")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t("common.none")}</SelectItem>
                    {deals.map((deal) => (
                      <SelectItem key={deal.id} value={deal.id}>
                        {deal.title} · {deal.code}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>

              <Field label={t("tasks.property")} error={errorFor("propertyId")}>
                <Select
                  value={form.propertyId || "none"}
                  onValueChange={(value) => set("propertyId", value === "none" ? "" : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("deals.selectProperty")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t("common.none")}</SelectItem>
                    {properties.map((property) => (
                      <SelectItem key={property.id} value={property.id}>
                        {property.title} · {property.code}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>

              {canAssignAgent && (
                <Field label={t("tasks.assignee")} error={errorFor("assignedToId")}>
                  <Select
                    value={form.assignedToId || "self"}
                    onValueChange={(value) => set("assignedToId", value === "self" ? "" : value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t("deals.selectAgent")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="self">{t("common.unassigned")}</SelectItem>
                      {agents.map((agent) => (
                        <SelectItem key={agent.id} value={agent.id}>
                          {agent.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="py-4 text-xs text-muted-foreground">
              <p className="font-medium text-foreground">{t("tasks.reminders")}</p>
              <p className="mt-1">{t("tasks.reminderHint")}</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex items-center justify-end gap-2">
        <Button type="button" variant="outline" asChild disabled={pending}>
          <Link href="/tasks">{t("common.cancel")}</Link>
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />}
          {mode === "create" ? t("common.create") : t("common.save")}
        </Button>
      </div>
    </form>
  );
}

function Field({
  label,
  required,
  error,
  children,
  className,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
  className?: string;
}) {
  const { t } = useI18n();
  return (
    <div className={className}>
      <Label className="mb-1.5 block">
        {label}
        {required ? (
          <span className="ms-0.5 text-destructive">*</span>
        ) : (
          <span className="ms-1 text-[10px] font-normal text-muted-foreground">({t("common.optional")})</span>
        )}
      </Label>
      {children}
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}
