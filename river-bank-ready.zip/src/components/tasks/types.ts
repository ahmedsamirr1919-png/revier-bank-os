export type AgentOption = {
  id: string;
  name: string;
  email: string;
  role: string;
};

export type CustomerOption = {
  id: string;
  code: string;
  fullName: string;
  phone: string;
  status: string;
};

export type DealOption = {
  id: string;
  code: string;
  title: string;
  stage: string;
};

export type PropertyOption = {
  id: string;
  code: string;
  title: string;
  status: string;
};

export type TaskListItem = {
  id: string;
  title: string;
  description: string | null;
  type: string;
  priority: string;
  status: string;
  dueAt: Date | string;
  completedAt: Date | string | null;
  createdAt: Date | string;
  customerId: string | null;
  dealId: string | null;
  propertyId: string | null;
  assignedToId: string;
  customer: { id: string; code: string; fullName: string } | null;
  deal: { id: string; code: string; title: string } | null;
  property: { id: string; code: string; title: string } | null;
  assignedTo: { id: string; name: string };
};

export type TaskFilters = {
  q: string;
  status: string;
  type: string;
  priority: string;
  sort: string;
};

export type TaskFormValues = Partial<{
  id: string;
  title: string;
  description: string | null;
  type: string;
  priority: string;
  status: string;
  dueAt: Date | string;
  customerId: string | null;
  dealId: string | null;
  propertyId: string | null;
  assignedToId: string;
}>;
