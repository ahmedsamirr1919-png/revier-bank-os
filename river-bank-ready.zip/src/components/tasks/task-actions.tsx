"use client";

import Link from "next/link";
import { CalendarDays, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/components/locale-provider";

export function TaskActions() {
  const { t } = useI18n();

  return (
    <>
      <Button variant="outline" size="sm" asChild>
        <Link href="/calendar">
          <CalendarDays />
          {t("calendar.title")}
        </Link>
      </Button>
      <Button size="sm" asChild>
        <Link href="/tasks/new">
          <Plus />
          {t("tasks.new")}
        </Link>
      </Button>
    </>
  );
}
