"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  AlarmClock,
  CalendarClock,
  CheckCircle2,
  Circle,
  ListTodo,
  Loader2,
  MoreHorizontal,
  Pencil,
  RotateCcw,
  Trash2,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { SearchInput } from "@/components/shared/search-input";
import { Pagination } from "@/components/shared/pagination";
import { EmptyState } from "@/components/shared/empty-state";
import { StatusBadge } from "@/components/shared/status-badge";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { TASK_PRIORITIES, TASK_STATUSES, TASK_TYPES } from "@/lib/constants";
import { cn, formatDate } from "@/lib/utils";
import type { TaskFilters, TaskListItem } from "./types";

export function TasksView({
  items,
  total,
  page,
  pageSize,
  pages,
  filters,
  counts,
}: {
  items: TaskListItem[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
  filters: TaskFilters;
  counts: { pending: number; overdue: number; today: number; done: number };
}) {
  const { t, enumLabel, locale } = useI18n();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [deleteTarget, setDeleteTarget] = useState<TaskListItem | null>(null);
  const [pending, setPending] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const setFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value && value !== "all") params.set(key, value);
    else params.delete(key);
    params.delete("page");
    router.push(`/tasks?${params.toString()}`);
  };

  const changeStatus = async (task: TaskListItem, status: string) => {
    setBusyId(task.id);
    try {
      await api.patch(`/api/tasks/${task.id}/status`, { status });
      toast.success(t("common.saved"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setBusyId(null);
    }
  };

  const remove = async () => {
    if (!deleteTarget) return;
    setPending(true);
    try {
      await api.delete(`/api/tasks/${deleteTarget.id}`);
      toast.success(t("toast.deleted"));
      setDeleteTarget(null);
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const now = Date.now();

  return (
    <>
      <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <CountCard
          icon={ListTodo}
          label={t("tasks.upcoming")}
          value={counts.pending}
          tone="text-sky-600 bg-sky-500/10"
        />
        <CountCard
          icon={AlarmClock}
          label={t("tasks.overdue")}
          value={counts.overdue}
          tone="text-rose-600 bg-rose-500/10"
        />
        <CountCard
          icon={CalendarClock}
          label={t("tasks.dueToday")}
          value={counts.today}
          tone="text-amber-600 bg-amber-500/10"
        />
        <CountCard
          icon={CheckCircle2}
          label={t("tasks.completed")}
          value={counts.done}
          tone="text-emerald-600 bg-emerald-500/10"
        />
      </div>

      <Card className="overflow-hidden">
        <div className="flex flex-col gap-3 border-b p-4 lg:flex-row lg:items-center lg:justify-between">
          <SearchInput placeholder={t("common.searchPlaceholder")} className="w-full lg:max-w-sm" />
          <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:items-center">
            <Select value={filters.status || "all"} onValueChange={(value) => setFilter("status", value)}>
              <SelectTrigger className="w-full sm:w-36" size="sm">
                <SelectValue placeholder={t("tasks.filterStatus")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {TASK_STATUSES.map((status) => (
                  <SelectItem key={status} value={status}>
                    {enumLabel("taskStatus", status)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.type || "all"} onValueChange={(value) => setFilter("type", value)}>
              <SelectTrigger className="w-full sm:w-36" size="sm">
                <SelectValue placeholder={t("tasks.type")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {TASK_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>
                    {enumLabel("taskType", type)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.priority || "all"} onValueChange={(value) => setFilter("priority", value)}>
              <SelectTrigger className="w-full sm:w-32" size="sm">
                <SelectValue placeholder={t("tasks.priority")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {TASK_PRIORITIES.map((priority) => (
                  <SelectItem key={priority} value={priority}>
                    {enumLabel("taskPriority", priority)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.sort} onValueChange={(value) => setFilter("sort", value)}>
              <SelectTrigger className="w-full sm:w-36" size="sm">
                <SelectValue placeholder={t("common.sortBy")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="due_asc">{t("tasks.dueAt")} ↑</SelectItem>
                <SelectItem value="due_desc">{t("tasks.dueAt")} ↓</SelectItem>
                <SelectItem value="newest">{t("common.newest")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {items.length === 0 ? (
          <EmptyState
            icon={ListTodo}
            title={t("tasks.noTasks")}
            description={t("common.noResultsHint")}
            action={
              <Button size="sm" asChild>
                <Link href="/tasks/new">{t("tasks.new")}</Link>
              </Button>
            }
          />
        ) : (
          <ul className="divide-y">
            {items.map((task) => {
              const overdue =
                task.status === "PENDING" && new Date(task.dueAt).getTime() < now;
              const done = task.status === "DONE";
              return (
                <li
                  key={task.id}
                  className={cn(
                    "flex flex-col gap-3 p-4 transition-colors hover:bg-muted/40 sm:flex-row sm:items-center",
                    overdue && "border-s-2 border-s-rose-500 bg-rose-500/[0.03]",
                  )}
                >
                  <button
                    type="button"
                    onClick={() => void changeStatus(task, done ? "PENDING" : "DONE")}
                    disabled={busyId === task.id}
                    className={cn(
                      "flex size-8 shrink-0 items-center justify-center rounded-full border transition-colors",
                      done
                        ? "border-emerald-500 bg-emerald-500 text-white"
                        : "text-muted-foreground hover:border-primary hover:text-primary",
                    )}
                    aria-label={done ? t("tasks.reopen") : t("tasks.complete")}
                  >
                    {busyId === task.id ? (
                      <Loader2 className="size-4 animate-spin" />
                    ) : done ? (
                      <CheckCircle2 className="size-4" />
                    ) : (
                      <Circle className="size-4" />
                    )}
                  </button>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link
                        href={`/tasks/${task.id}/edit`}
                        className={cn("text-sm font-medium hover:underline", done && "line-through opacity-60")}
                      >
                        {task.title}
                      </Link>
                      <StatusBadge value={task.priority} group="taskPriority" />
                      <StatusBadge value={task.status} group="taskStatus" />
                      <span className="text-[11px] text-muted-foreground">
                        {enumLabel("taskType", task.type)}
                      </span>
                    </div>

                    {task.description && (
                      <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{task.description}</p>
                    )}

                    <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <CalendarClock className="size-3" />
                        {formatDate(task.dueAt, locale, true)}
                        {overdue && (
                          <span className="font-medium text-rose-600">· {t("tasks.overdue")}</span>
                        )}
                      </span>
                      <span>{task.assignedTo.name}</span>
                      {task.customer && (
                        <Link href={`/customers/${task.customer.id}`} className="hover:underline">
                          {task.customer.fullName}
                        </Link>
                      )}
                      {task.deal && (
                        <Link href={`/deals/${task.deal.id}`} className="hover:underline">
                          {task.deal.title}
                        </Link>
                      )}
                      {task.property && (
                        <Link href={`/properties/${task.property.id}`} className="hover:underline">
                          {task.property.title}
                        </Link>
                      )}
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-1 self-end sm:self-center">
                    {!done && task.status !== "CANCELLED" && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => void changeStatus(task, done ? "PENDING" : "DONE")}
                        disabled={busyId === task.id}
                      >
                        <CheckCircle2 />
                        {t("tasks.complete")}
                      </Button>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon-sm" aria-label={t("common.actions")}>
                          <MoreHorizontal />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-44">
                        <DropdownMenuLabel className="truncate text-xs">{task.title}</DropdownMenuLabel>
                        <DropdownMenuItem asChild>
                          <Link href={`/tasks/${task.id}/edit`}>
                            <Pencil />
                            {t("common.edit")}
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onSelect={() => void changeStatus(task, done ? "PENDING" : "DONE")}>
                          {done ? <RotateCcw /> : <CheckCircle2 />}
                          {done ? t("tasks.reopen") : t("tasks.complete")}
                        </DropdownMenuItem>
                        {task.status !== "CANCELLED" && !done && (
                          <DropdownMenuItem onSelect={() => void changeStatus(task, "CANCELLED")}>
                            {t("tasks.cancelTask")}
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onSelect={() => setDeleteTarget(task)}
                        >
                          <Trash2 />
                          {t("common.delete")}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </li>
              );
            })}
          </ul>
        )}

        <Pagination page={page} pages={pages} total={total} pageSize={pageSize} />
      </Card>

      <AlertDialog open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("tasks.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("tasks.deleteBody")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={remove} disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function CountCard({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: LucideIcon;
  label: string;
  value: number;
  tone: string;
}) {
  return (
    <Card className="py-3">
      <div className="flex items-center gap-3 px-4">
        <span className={cn("flex size-9 items-center justify-center rounded-lg", tone)}>
          <Icon className="size-4" />
        </span>
        <div>
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="text-lg font-semibold leading-tight" dir="ltr">
            {value}
          </p>
        </div>
      </div>
    </Card>
  );
}
