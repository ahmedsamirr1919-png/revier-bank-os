"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useI18n } from "@/components/locale-provider";
import { enumLabel } from "@/lib/i18n";
import { DEAL_STAGES } from "@/lib/constants";

const CHART_COLORS = ["#0e7490", "#0f766e", "#0ea5e9", "#6366f1", "#f59e0b", "#10b981", "#ec4899"];

export function DashboardCharts({
  dealStages,
  sources,
  monthly,
  agents,
}: {
  dealStages: Array<{ stage: string; count: number }>;
  sources: Array<{ source: string; count: number }>;
  monthly: Array<{ month: string; revenue: number }>;
  agents: Array<{ name: string; revenue: number; deals: number }>;
}) {
  const { t, messages } = useI18n();

  const stageData = DEAL_STAGES.map((stage) => ({
    stage: enumLabel(messages, "dealStage", stage),
    count: dealStages.find((item) => item.stage === stage)?.count ?? 0,
  }));

  const sourceData = sources.map((item) => ({
    name: enumLabel(messages, "source", item.source),
    value: item.count,
  }));

  return (
    <div className="mt-5 grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("dashboard.salesFunnel")}</CardTitle>
        </CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stageData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="stage" tick={{ fontSize: 11 }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="count" fill="#0e7490" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("dashboard.leadsBySource")}</CardTitle>
        </CardHeader>
        <CardContent className="h-72">
          {sourceData.length === 0 ? (
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
              {t("dashboard.noData")}
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sourceData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  label
                >
                  {sourceData.map((_, index) => (
                    <Cell key={index} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("dashboard.monthlySales")}</CardTitle>
        </CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={monthly} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Line type="monotone" dataKey="revenue" stroke="#0f766e" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("dashboard.agentLeaderboard")}</CardTitle>
        </CardHeader>
        <CardContent>
          {agents.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t("dashboard.noData")}</p>
          ) : (
            <ul className="space-y-2">
              {agents
                .sort((a, b) => b.revenue - a.revenue)
                .slice(0, 6)
                .map((agent) => (
                  <li
                    key={agent.name}
                    className="flex items-center justify-between rounded-lg border px-3 py-2 text-sm"
                  >
                    <span className="font-medium">{agent.name}</span>
                    <span className="text-muted-foreground">
                      {agent.deals} {t("dashboard.deals")} · {agent.revenue.toLocaleString()}
                    </span>
                  </li>
                ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
