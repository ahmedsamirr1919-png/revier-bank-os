"use client";

import { useState } from "react";
import { FileSpreadsheet, FileUp, Loader2, Plus, Trash2, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Papa from "papaparse";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { CustomerImportDialog } from "./customer-import-dialog";
import type { CustomerFilters } from "./types";

export function CustomerActions({
  filters,
  canDelete,
  trash,
}: {
  filters: CustomerFilters;
  canDelete: boolean;
  trash: boolean;
}) {
  const { t } = useI18n();
  const router = useRouter();
  const [importOpen, setImportOpen] = useState(false);
  const [exporting, setExporting] = useState(false);

  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(filters)) {
    if (value && key !== "trash") query.set(key, value);
  }
  const exportHref = `/api/customers/export?${query.toString()}`;

  const exportExcel = async () => {
    setExporting(true);
    try {
      const response = await fetch(exportHref, { cache: "no-store" });
      if (!response.ok) throw new Error("Export failed");
      const csv = await response.text();
      const parsed = Papa.parse<Record<string, string>>(csv.replace(/^\uFEFF/, ""), {
        header: true,
        skipEmptyLines: true,
      });
      const XLSX = await import("xlsx");
      const sheet = XLSX.utils.json_to_sheet(parsed.data);
      const book = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(book, sheet, "Customers");
      XLSX.writeFile(book, `river-bank-customers-${new Date().toISOString().slice(0, 10)}.xlsx`);
      toast.success(t("toast.exported"));
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setExporting(false);
    }
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <FileSpreadsheet />
            {t("common.export")}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem asChild>
            <a href={exportHref} download>
              <FileSpreadsheet />
              {t("common.exportCsv")}
            </a>
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={exportExcel} disabled={exporting}>
            {exporting ? <Loader2 className="animate-spin" /> : <FileSpreadsheet />}
            {t("common.exportExcel")}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {!trash && (
        <Button variant="outline" size="sm" onClick={() => setImportOpen(true)}>
          <FileUp />
          {t("common.importCsv")}
        </Button>
      )}

      {canDelete && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const params = new URLSearchParams();
            if (!trash) params.set("trash", "1");
            router.push(`/customers${params.size ? `?${params.toString()}` : ""}`);
          }}
        >
          {trash ? <Undo2 /> : <Trash2 />}
          {trash ? t("customers.title") : t("customers.trash")}
        </Button>
      )}

      {!trash && (
        <Button size="sm" asChild>
          <Link href="/customers/new">
            <Plus />
            {t("customers.new")}
          </Link>
        </Button>
      )}

      <CustomerImportDialog open={importOpen} onOpenChange={setImportOpen} />
    </>
  );
}
