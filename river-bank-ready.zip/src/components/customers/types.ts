export type AgentOption = {
  id: string;
  name: string;
  email: string;
  role: string;
};

export type CustomerListItem = {
  id: string;
  code: string;
  fullName: string;
  phone: string;
  email: string | null;
  whatsapp: string | null;
  source: string;
  status: string;
  budgetMin: number | null;
  budgetMax: number | null;
  currency: string;
  preferredArea: string | null;
  propertyType: string | null;
  purpose: string | null;
  assignedAgentId: string | null;
  isDeleted: boolean;
  score: number;
  scoreStatus: string;
  createdAt: Date | string;
  assignedAgent: { id: string; name: string; email: string } | null;
  _count: { deals: number; activities: number };
};

export type CustomerFilters = {
  q: string;
  status: string;
  source: string;
  agentId: string;
  purpose: string;
  sort: string;
  trash: string;
};
