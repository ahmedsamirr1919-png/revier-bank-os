"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Loader2,
  MessageCircle,
  Pencil,
  Phone,
  RotateCcw,
  Trash2,
  UserCheck,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import type { AgentOption } from "./types";

export function CustomerDetailActions({
  customer,
  agents,
  canAssign,
  canDelete,
  isDeleted,
}: {
  customer: { id: string; fullName: string; phone: string; whatsapp: string | null; assignedAgentId: string | null };
  agents: AgentOption[];
  canAssign: boolean;
  canDelete: boolean;
  isDeleted: boolean;
}) {
  const { t, enumLabel } = useI18n();
  const router = useRouter();
  const [assignOpen, setAssignOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [pending, setPending] = useState(false);
  const [agentId, setAgentId] = useState(customer.assignedAgentId ?? "__none");

  const whatsapp = customer.whatsapp || customer.phone;

  const assign = async () => {
    setPending(true);
    try {
      await api.post(`/api/customers/${customer.id}/assign`, {
        assignedAgentId: agentId === "__none" ? null : agentId,
      });
      toast.success(t("toast.assigned"));
      setAssignOpen(false);
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const remove = async () => {
    setPending(true);
    try {
      await api.delete(`/api/customers/${customer.id}`);
      toast.success(t("toast.deleted"));
      setDeleteOpen(false);
      router.push("/customers");
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const restore = async () => {
    setPending(true);
    try {
      await api.post(`/api/customers/${customer.id}/restore`);
      toast.success(t("common.saved"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  if (isDeleted) {
    return (
      <Button variant="outline" size="sm" onClick={restore} disabled={pending}>
        {pending ? <Loader2 className="animate-spin" /> : <RotateCcw />}
        {t("customers.restore")}
      </Button>
    );
  }

  return (
    <>
      <Button variant="outline" size="sm" asChild>
        <a href={`tel:${customer.phone}`}>
          <Phone />
          {t("customers.call")}
        </a>
      </Button>
      <Button variant="outline" size="sm" asChild>
        <a
          href={`https://wa.me/${whatsapp.replace(/\D/g, "")}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <MessageCircle />
          {t("customers.sendWhatsapp")}
        </a>
      </Button>
      <Button variant="outline" size="sm" asChild>
        <Link href={`/customers/${customer.id}/edit`}>
          <Pencil />
          {t("common.edit")}
        </Link>
      </Button>
      {canAssign && (
        <Button variant="outline" size="sm" onClick={() => setAssignOpen(true)}>
          <UserCheck />
          {t("common.assign")}
        </Button>
      )}
      {canDelete && (
        <Button
          variant="outline"
          size="sm"
          className="text-destructive hover:text-destructive"
          onClick={() => setDeleteOpen(true)}
        >
          <Trash2 />
          {t("common.delete")}
        </Button>
      )}

      <Dialog open={assignOpen} onOpenChange={setAssignOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("customers.assignAgent")}</DialogTitle>
          </DialogHeader>
          <Select value={agentId} onValueChange={setAgentId}>
            <SelectTrigger>
              <SelectValue placeholder={t("customers.selectAgent")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">{t("common.unassigned")}</SelectItem>
              {agents.map((agent) => (
                <SelectItem key={agent.id} value={agent.id}>
                  {agent.name} · {enumLabel("roles", agent.role)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button onClick={assign} disabled={pending}>
              {pending ? <Loader2 className="animate-spin" /> : <UserCheck />}
              {t("common.assign")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("customers.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("customers.deleteBody")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={remove} disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {t("customers.deleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
