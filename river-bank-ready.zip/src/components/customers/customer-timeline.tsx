"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  CalendarCheck,
  CalendarClock,
  Loader2,
  Mail,
  MessageSquare,
  PhoneCall,
  Plus,
  Repeat,
  UserCheck,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EmptyState } from "@/components/shared/empty-state";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { formatDate } from "@/lib/utils";

export type TimelineItem = {
  id: string;
  type: string;
  title: string;
  body: string | null;
  outcome: string | null;
  occurredAt: Date | string;
  user: { id: string; name: string } | null;
};

const ACTIVITY_TYPES = ["CALL", "NOTE", "MEETING", "EMAIL", "SITE_VISIT"] as const;

const ICONS: Record<string, LucideIcon> = {
  CALL: PhoneCall,
  NOTE: MessageSquare,
  MEETING: CalendarCheck,
  EMAIL: Mail,
  SITE_VISIT: CalendarClock,
  STATUS_CHANGE: Repeat,
  ASSIGNMENT: UserCheck,
  FEEDBACK: MessageSquare,
};

export function CustomerTimeline({ customerId, items }: { customerId: string; items: TimelineItem[] }) {
  const { t, enumLabel, locale } = useI18n();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);
  const [form, setForm] = useState({ type: "CALL", title: "", body: "", outcome: "", occurredAt: "" });

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setPending(true);
    try {
      await api.post(`/api/customers/${customerId}/activities`, {
        type: form.type,
        title: form.title,
        body: form.body || null,
        outcome: form.outcome || null,
        ...(form.occurredAt ? { occurredAt: new Date(form.occurredAt).toISOString() } : {}),
      });
      toast.success(t("customers.activityAdded"));
      setOpen(false);
      setForm({ type: "CALL", title: "", body: "", outcome: "", occurredAt: "" });
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">{t("customers.timeline")}</h3>
        <Button size="sm" variant="outline" onClick={() => setOpen(true)}>
          <Plus />
          {t("customers.addActivity")}
        </Button>
      </div>

      {items.length === 0 ? (
        <div className="rounded-lg border">
          <EmptyState
            icon={MessageSquare}
            title={t("customers.noActivity")}
            action={
              <Button size="sm" onClick={() => setOpen(true)}>
                <Plus />
                {t("customers.addActivity")}
              </Button>
            }
          />
        </div>
      ) : (
        <ol className="relative space-y-4 border-s ps-5">
          {items.map((item) => {
            const Icon = ICONS[item.type] ?? MessageSquare;
            return (
              <li key={item.id} className="relative">
                <span className="absolute -start-[30px] top-0.5 flex size-5 items-center justify-center rounded-full border bg-background text-muted-foreground">
                  <Icon className="size-3" />
                </span>
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  <p className="text-sm font-medium">{item.title}</p>
                  <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                    {enumLabel("activityType", item.type)}
                  </span>
                </div>
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  {formatDate(item.occurredAt, locale, true)}
                  {item.user?.name ? ` · ${item.user.name}` : ""}
                </p>
                {item.body && <p className="mt-1.5 whitespace-pre-line text-sm text-muted-foreground">{item.body}</p>}
                {item.outcome && (
                  <p className="mt-1 text-xs">
                    <span className="font-medium">{t("customers.outcome")}:</span>{" "}
                    <span className="text-muted-foreground">{item.outcome}</span>
                  </p>
                )}
              </li>
            );
          })}
        </ol>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("customers.addActivity")}</DialogTitle>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label className="mb-1.5 block">{t("customers.activityType")}</Label>
                <Select value={form.type} onValueChange={(type) => setForm((f) => ({ ...f, type }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ACTIVITY_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {enumLabel("activityType", type)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="mb-1.5 block">{t("customers.occurredAt")}</Label>
                <Input
                  type="datetime-local"
                  value={form.occurredAt}
                  onChange={(event) => setForm((f) => ({ ...f, occurredAt: event.target.value }))}
                />
              </div>
            </div>
            <div>
              <Label className="mb-1.5 block">{t("customers.activityTitle")}</Label>
              <Input
                value={form.title}
                onChange={(event) => setForm((f) => ({ ...f, title: event.target.value }))}
                required
                maxLength={160}
              />
            </div>
            <div>
              <Label className="mb-1.5 block">{t("customers.activityBody")}</Label>
              <Textarea
                value={form.body}
                onChange={(event) => setForm((f) => ({ ...f, body: event.target.value }))}
                rows={3}
                maxLength={3000}
              />
            </div>
            <div>
              <Label className="mb-1.5 block">{t("customers.outcome")}</Label>
              <Input
                value={form.outcome}
                onChange={(event) => setForm((f) => ({ ...f, outcome: event.target.value }))}
                maxLength={300}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                {t("common.cancel")}
              </Button>
              <Button type="submit" disabled={pending || form.title.trim().length < 2}>
                {pending ? <Loader2 className="animate-spin" /> : <Plus />}
                {t("common.save")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
