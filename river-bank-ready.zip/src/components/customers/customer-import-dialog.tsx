"use client";

import { useRef, useState } from "react";
import Papa from "papaparse";
import { Download, FileUp, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";

const TEMPLATE_HEADERS = [
  "fullName",
  "phone",
  "email",
  "whatsapp",
  "source",
  "budgetMin",
  "budgetMax",
  "preferredArea",
  "propertyType",
  "status",
  "agentEmail",
  "notes",
];

type ImportResult = {
  imported: number;
  skipped: number;
  total: number;
  errors: Array<{ row: number; message: string }>;
};

export function CustomerImportDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t } = useI18n();
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [rows, setRows] = useState<Array<Record<string, string>> | null>(null);
  const [fileName, setFileName] = useState("");
  const [pending, setPending] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);

  const reset = () => {
    setRows(null);
    setFileName("");
    setResult(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const handleFile = (file: File | undefined) => {
    if (!file) return;
    setFileName(file.name);
    setResult(null);
    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header) => header.trim(),
      complete: (parsed) => {
        const cleaned = parsed.data.filter((row) =>
          Object.values(row).some((value) => (value ?? "").toString().trim() !== ""),
        );
        if (!cleaned.length) {
          toast.error(t("common.noData"));
          setRows(null);
          return;
        }
        setRows(cleaned);
      },
      error: () => toast.error(t("toast.error")),
    });
  };

  const submit = async () => {
    if (!rows?.length) return;
    setPending(true);
    try {
      const response = await api.post<ImportResult>("/api/customers/import", { rows });
      setResult(response);
      toast.success(t("toast.imported"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const downloadTemplate = () => {
    const sample = [
      "Sara Al Mansouri",
      "+971501234567",
      "sara@example.com",
      "+971501234567",
      "WEBSITE",
      "800000",
      "1200000",
      "Dubai Marina",
      "APARTMENT",
      "NEW",
      "agent@riverbank.com",
      "Looking for a sea view",
    ];
    const csv = `${TEMPLATE_HEADERS.join(",")}\r\n${sample.map((value) => `"${value}"`).join(",")}`;
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "river-bank-customers-template.csv";
    anchor.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        onOpenChange(next);
        if (!next) reset();
      }}
    >
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{t("customers.importTitle")}</DialogTitle>
          <DialogDescription>{t("customers.importHint")}</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <Input
            ref={inputRef}
            type="file"
            accept=".csv,text/csv"
            onChange={(event) => handleFile(event.target.files?.[0])}
            aria-label={t("customers.importFile")}
            className="cursor-pointer file:me-3 file:rounded-md file:border-0 file:bg-muted file:px-3 file:py-1.5 file:text-xs file:font-medium"
          />
          {fileName && (
            <p className="text-xs text-muted-foreground">
              {fileName}
              {rows ? ` · ${rows.length} ${t("common.results")}` : ""}
            </p>
          )}

          {result && (
            <div className="space-y-2 rounded-lg border bg-muted/40 p-3 text-sm">
              <p>
                {t("customers.importResult", {
                  imported: result.imported,
                  total: result.total,
                  skipped: result.skipped,
                })}
              </p>
              {result.errors.length > 0 && (
                <ul className="max-h-40 space-y-1 overflow-y-auto text-xs text-muted-foreground">
                  {result.errors.map((error) => (
                    <li key={`${error.row}-${error.message}`}>
                      #{error.row}: {error.message}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          <Button type="button" variant="ghost" size="sm" className="px-0" onClick={downloadTemplate}>
            <Download />
            {t("customers.downloadTemplate")}
          </Button>
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            {t("common.cancel")}
          </Button>
          <Button type="button" onClick={submit} disabled={!rows?.length || pending}>
            {pending ? <Loader2 className="animate-spin" /> : <FileUp />}
            {t("common.import")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
