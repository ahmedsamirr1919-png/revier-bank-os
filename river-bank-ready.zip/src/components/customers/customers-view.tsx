"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  Eye,
  Loader2,
  MoreHorizontal,
  Pencil,
  Phone,
  RotateCcw,
  Trash2,
  UserCheck,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { SearchInput } from "@/components/shared/search-input";
import { Pagination } from "@/components/shared/pagination";
import { EmptyState } from "@/components/shared/empty-state";
import { StatusBadge } from "@/components/shared/status-badge";
import { Card } from "@/components/ui/card";
import { useI18n } from "@/components/locale-provider";
import { api } from "@/lib/client-api";
import { CUSTOMER_SOURCES, CUSTOMER_STATUSES, LEAD_SCORE_STYLES, PAGE_SIZE, PROPERTY_PURPOSES } from "@/lib/constants";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { AgentOption, CustomerFilters, CustomerListItem } from "./types";

export function CustomersView({
  items,
  agents,
  total,
  page,
  pageSize,
  pages,
  filters,
  canAssign,
  canDelete,
  isAdmin,
}: {
  items: CustomerListItem[];
  agents: AgentOption[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
  filters: CustomerFilters;
  canAssign: boolean;
  canDelete: boolean;
  isAdmin: boolean;
}) {
  const { t, enumLabel, locale } = useI18n();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [assignTarget, setAssignTarget] = useState<CustomerListItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<CustomerListItem | null>(null);
  const [pending, setPending] = useState(false);
  const [agentId, setAgentId] = useState("__none");
  const [autoAssigning, setAutoAssigning] = useState(false);

  const setFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value && value !== "all") params.set(key, value);
    else params.delete(key);
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  };

  const openAssign = (customer: CustomerListItem) => {
    setAgentId(customer.assignedAgentId ?? "__none");
    setAssignTarget(customer);
  };

  const assign = async () => {
    if (!assignTarget) return;
    setPending(true);
    try {
      await api.post(`/api/customers/${assignTarget.id}/assign`, {
        assignedAgentId: agentId === "__none" ? null : agentId,
      });
      toast.success(t("toast.assigned"));
      setAssignTarget(null);
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const remove = async () => {
    if (!deleteTarget) return;
    setPending(true);
    try {
      await api.delete(`/api/customers/${deleteTarget.id}`);
      toast.success(t("toast.deleted"));
      setDeleteTarget(null);
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const restore = async (customer: CustomerListItem) => {
    try {
      await api.post(`/api/customers/${customer.id}/restore`);
      toast.success(t("common.saved"));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    }
  };

  const autoAssign = async () => {
    setAutoAssigning(true);
    try {
      const data = await api.post<{ assignments: Array<{ customerId: string; agentId: string }> }>("/api/leads/assign", {});
      toast.success(t("leads.autoAssigned", { count: data.assignments.length }));
      router.refresh();
    } catch {
      toast.error(t("toast.error"));
    } finally {
      setAutoAssigning(false);
    }
  };

  return (
    <>
      <Card className="overflow-hidden">
        <div className="flex flex-col gap-3 border-b p-4 lg:flex-row lg:items-center lg:justify-between">
          <SearchInput
            placeholder={t("customers.searchPlaceholder")}
            className="w-full lg:max-w-sm"
          />
          <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:items-center">
            <Select value={filters.status || "all"} onValueChange={(value) => setFilter("status", value)}>
              <SelectTrigger className="w-full sm:w-36" size="sm">
                <SelectValue placeholder={t("customers.status")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {CUSTOMER_STATUSES.map((status) => (
                  <SelectItem key={status} value={status}>
                    {enumLabel("customerStatus", status)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.source || "all"} onValueChange={(value) => setFilter("source", value)}>
              <SelectTrigger className="w-full sm:w-36" size="sm">
                <SelectValue placeholder={t("customers.source")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {CUSTOMER_SOURCES.map((source) => (
                  <SelectItem key={source} value={source}>
                    {enumLabel("source", source)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.purpose || "all"} onValueChange={(value) => setFilter("purpose", value)}>
              <SelectTrigger className="w-full sm:w-36" size="sm">
                <SelectValue placeholder={t("customers.purpose")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all")}</SelectItem>
                {PROPERTY_PURPOSES.map((purpose) => (
                  <SelectItem key={purpose} value={purpose}>
                    {enumLabel("propertyPurpose", purpose)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {canAssign && (
              <Select value={filters.agentId || "all"} onValueChange={(value) => setFilter("agentId", value)}>
                <SelectTrigger className="w-full sm:w-40" size="sm">
                  <SelectValue placeholder={t("customers.agent")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("common.all")}</SelectItem>
                  <SelectItem value="unassigned">{t("common.unassigned")}</SelectItem>
                  {agents.map((agent) => (
                    <SelectItem key={agent.id} value={agent.id}>
                      {agent.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Select value={filters.sort} onValueChange={(value) => setFilter("sort", value)}>
              <SelectTrigger className="w-full sm:w-36" size="sm">
                <SelectValue placeholder={t("common.sortBy")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">{t("common.newest")}</SelectItem>
                <SelectItem value="oldest">{t("common.oldest")}</SelectItem>
                <SelectItem value="name">{t("common.name")}</SelectItem>
                <SelectItem value="budget">{t("customers.budget")}</SelectItem>
              </SelectContent>
            </Select>
            {canAssign && (
              <Button size="sm" variant="outline" onClick={() => void autoAssign()} disabled={autoAssigning}>
                {autoAssigning ? <Loader2 className="animate-spin" /> : <UserCheck />}
                {t("leads.autoAssign")}
              </Button>
            )}
          </div>
        </div>

        {items.length === 0 ? (
          <EmptyState
            icon={Users}
            title={t("common.noResults")}
            description={t("common.noResultsHint")}
            action={
              !filters.trash ? (
                <Button size="sm" asChild>
                  <Link href="/customers/new">{t("customers.new")}</Link>
                </Button>
              ) : undefined
            }
          />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("customers.fullName")}</TableHead>
                <TableHead>{t("customers.contact")}</TableHead>
                <TableHead>{t("customers.status")}</TableHead>
                <TableHead className="hidden lg:table-cell">{t("leads.score")}</TableHead>
                <TableHead className="hidden md:table-cell">{t("customers.source")}</TableHead>
                <TableHead className="hidden lg:table-cell">{t("customers.budget")}</TableHead>
                <TableHead className="hidden sm:table-cell">{t("customers.agent")}</TableHead>
                <TableHead className="hidden xl:table-cell">{t("common.created")}</TableHead>
                <TableHead className="w-10 text-end">{t("common.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((customer) => {
                const budget =
                  customer.budgetMin && customer.budgetMax
                    ? `${formatCurrency(customer.budgetMin, locale, true)} – ${formatCurrency(customer.budgetMax, locale, true)}`
                    : customer.budgetMax
                      ? formatCurrency(customer.budgetMax, locale, true)
                      : customer.budgetMin
                        ? formatCurrency(customer.budgetMin, locale, true)
                        : "—";

                return (
                  <TableRow key={customer.id}>
                    <TableCell>
                      <Link href={`/customers/${customer.id}`} className="block min-w-0 hover:underline">
                        <span className="block truncate font-medium">{customer.fullName}</span>
                        <span className="block text-xs text-muted-foreground">{customer.code}</span>
                      </Link>
                    </TableCell>
                    <TableCell>
                      <a href={`tel:${customer.phone}`} className="flex items-center gap-1.5 text-sm hover:underline">
                        <Phone className="size-3 text-muted-foreground" />
                        <span dir="ltr">{customer.phone}</span>
                      </a>
                      {customer.email && (
                        <span className="mt-0.5 block truncate text-xs text-muted-foreground">{customer.email}</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <StatusBadge value={customer.status} />
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      {customer.scoreStatus ? (
                        <span
                          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${LEAD_SCORE_STYLES[customer.scoreStatus] ?? LEAD_SCORE_STYLES.COLD}`}
                        >
                          {customer.score} · {enumLabel("leadScore", customer.scoreStatus)}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                      {enumLabel("source", customer.source)}
                    </TableCell>
                    <TableCell className="hidden lg:table-cell text-sm" dir="ltr">
                      {budget}
                    </TableCell>
                    <TableCell className="hidden sm:table-cell text-sm">
                      {customer.assignedAgent ? (
                        customer.assignedAgent.name
                      ) : (
                        <span className="text-muted-foreground">{t("common.unassigned")}</span>
                      )}
                    </TableCell>
                    <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                      {formatDate(customer.createdAt, locale)}
                    </TableCell>
                    <TableCell className="text-end">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon-sm" aria-label={t("common.actions")}>
                            <MoreHorizontal />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-44">
                          <DropdownMenuLabel className="text-xs">{customer.code}</DropdownMenuLabel>
                          <DropdownMenuItem asChild>
                            <Link href={`/customers/${customer.id}`}>
                              <Eye />
                              {t("common.view")}
                            </Link>
                          </DropdownMenuItem>
                          {!filters.trash && (
                            <DropdownMenuItem asChild>
                              <Link href={`/customers/${customer.id}/edit`}>
                                <Pencil />
                                {t("common.edit")}
                              </Link>
                            </DropdownMenuItem>
                          )}
                          {!filters.trash && canAssign && (
                            <DropdownMenuItem onSelect={() => openAssign(customer)}>
                              <UserCheck />
                              {t("customers.assignAgent")}
                            </DropdownMenuItem>
                          )}
                          {filters.trash && canDelete && (
                            <DropdownMenuItem onSelect={() => void restore(customer)}>
                              <RotateCcw />
                              {t("customers.restore")}
                            </DropdownMenuItem>
                          )}
                          {!filters.trash && canDelete && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="text-destructive focus:text-destructive"
                                onSelect={() => setDeleteTarget(customer)}
                              >
                                <Trash2 />
                                {t("common.delete")}
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}

        <Pagination page={page} pages={pages} total={total} pageSize={pageSize || PAGE_SIZE} />
      </Card>

      <Dialog open={Boolean(assignTarget)} onOpenChange={(open) => !open && setAssignTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("customers.assignAgent")}</DialogTitle>
            <DialogDescription>{assignTarget?.fullName}</DialogDescription>
          </DialogHeader>
          <Select value={agentId} onValueChange={setAgentId}>
            <SelectTrigger>
              <SelectValue placeholder={t("customers.selectAgent")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">{t("common.unassigned")}</SelectItem>
              {agents.map((agent) => (
                <SelectItem key={agent.id} value={agent.id}>
                  {agent.name} · {enumLabel("roles", agent.role)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignTarget(null)}>
              {t("common.cancel")}
            </Button>
            <Button onClick={assign} disabled={pending}>
              {pending ? <Loader2 className="animate-spin" /> : <UserCheck />}
              {t("common.assign")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("customers.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("customers.deleteBody")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={remove} disabled={pending}>
              {pending && <Loader2 className="animate-spin" />}
              {t("customers.deleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

