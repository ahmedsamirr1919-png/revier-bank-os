"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useI18n } from "@/components/locale-provider";
import { api, fieldErrors } from "@/lib/client-api";
import { CUSTOMER_SOURCES, CUSTOMER_STATUSES, PROPERTY_PURPOSES, PROPERTY_TYPES } from "@/lib/constants";
import type { AgentOption } from "./types";

type FormState = {
  fullName: string;
  phone: string;
  email: string;
  whatsapp: string;
  source: string;
  status: string;
  budgetMin: string;
  budgetMax: string;
  preferredArea: string;
  propertyType: string;
    purpose: string;
  assignedAgentId: string;
  notes: string;
};

export type CustomerFormValues = Partial<{
  id: string;
  fullName: string;
  phone: string | null;
  email: string | null;
  whatsapp: string | null;
  source: string;
  status: string;
  budgetMin: number | null;
  budgetMax: number | null;
  preferredArea: string | null;
  propertyType: string | null;
    purpose: string | null;
  assignedAgentId: string | null;
  notes: string | null;
}>;

export function CustomerForm({
  mode,
  customer,
  agents,
  canAssign,
}: {
  mode: "create" | "edit";
  customer?: CustomerFormValues;
  agents: AgentOption[];
  canAssign: boolean;
}) {
  const { t, enumLabel } = useI18n();
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [form, setForm] = useState<FormState>({
    fullName: customer?.fullName ?? "",
    phone: customer?.phone ?? "",
    email: customer?.email ?? "",
    whatsapp: customer?.whatsapp ?? "",
    source: customer?.source ?? "WEBSITE",
    status: customer?.status ?? "NEW",
    budgetMin: customer?.budgetMin ? String(customer.budgetMin) : "",
    budgetMax: customer?.budgetMax ? String(customer.budgetMax) : "",
    preferredArea: customer?.preferredArea ?? "",
    propertyType: customer?.propertyType ?? "",
      purpose: customer?.purpose ?? "",
    assignedAgentId: customer?.assignedAgentId ?? "",
    notes: customer?.notes ?? "",
  });

  const set = (key: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    if (errors[key]?.length) setErrors((current) => ({ ...current, [key]: [] }));
  };

  const errorFor = (key: string) => errors[key]?.[0];

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setPending(true);
    setErrors({});
    try {
      const payload = {
        ...form,
        email: form.email || null,
        whatsapp: form.whatsapp || null,
        budgetMin: form.budgetMin || null,
        budgetMax: form.budgetMax || null,
        preferredArea: form.preferredArea || null,
        propertyType: form.propertyType || null,
          purpose: form.purpose || null,
        assignedAgentId: form.assignedAgentId || null,
        notes: form.notes || null,
        currency: "EGP",
      };

      if (mode === "create") {
        const created = await api.post<{ id: string }>("/api/customers", payload);
        toast.success(t("toast.created"));
        router.push(`/customers/${created.id}`);
      } else if (customer?.id) {
        await api.patch(`/api/customers/${customer.id}`, payload);
        toast.success(t("toast.updated"));
        router.push(`/customers/${customer.id}`);
      }
      router.refresh();
    } catch (error) {
      const fields = fieldErrors(error);
      if (fields) setErrors(fields);
      toast.error(fieldErrors(error) ? t("common.requiredField") : t("toast.error"));
    } finally {
      setPending(false);
    }
  };

  const backHref = customer?.id ? `/customers/${customer.id}` : "/customers";

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href={backHref}>
            <ArrowLeft className="rtl:rotate-180" />
            {t("common.back")}
          </Link>
        </Button>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("customers.info")}</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <Field
              label={t("customers.fullName")}
              required
              error={errorFor("fullName")}
              className="sm:col-span-2"
            >
              <Input
                value={form.fullName}
                onChange={(event) => set("fullName", event.target.value)}
                required
                maxLength={120}
                autoFocus
              />
            </Field>
            <Field label={t("customers.phone")} required error={errorFor("phone")}>
              <Input
                value={form.phone}
                onChange={(event) => set("phone", event.target.value)}
                required
                dir="ltr"
                maxLength={30}
              />
            </Field>
            <Field label={t("customers.email")} error={errorFor("email")}>
              <Input
                type="email"
                value={form.email}
                onChange={(event) => set("email", event.target.value)}
                dir="ltr"
                maxLength={160}
              />
            </Field>
            <Field label={t("customers.whatsapp")} error={errorFor("whatsapp")}>
              <Input
                value={form.whatsapp}
                onChange={(event) => set("whatsapp", event.target.value)}
                dir="ltr"
                maxLength={30}
              />
            </Field>
            <Field label={t("customers.preferredArea")} error={errorFor("preferredArea")}>
              <Input
                value={form.preferredArea}
                onChange={(event) => set("preferredArea", event.target.value)}
                maxLength={120}
              />
            </Field>
            <Field label={t("customers.notes")} error={errorFor("notes")} className="sm:col-span-2">
              <Textarea
                value={form.notes}
                onChange={(event) => set("notes", event.target.value)}
                rows={4}
                maxLength={3000}
                placeholder={t("customers.notePlaceholder")}
              />
            </Field>
          </CardContent>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("customers.pipeline")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Field label={t("customers.status")}>
                <Select value={form.status} onValueChange={(value) => set("status", value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CUSTOMER_STATUSES.map((status) => (
                      <SelectItem key={status} value={status}>
                        {enumLabel("customerStatus", status)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label={t("customers.source")}>
                <Select value={form.source} onValueChange={(value) => set("source", value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CUSTOMER_SOURCES.map((source) => (
                      <SelectItem key={source} value={source}>
                        {enumLabel("source", source)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              {canAssign && (
                <Field label={t("customers.agent")}>
                  <Select
                    value={form.assignedAgentId || "__none"}
                    onValueChange={(value) => set("assignedAgentId", value === "__none" ? "" : value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t("customers.selectAgent")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none">{t("common.unassigned")}</SelectItem>
                      {agents.map((agent) => (
                        <SelectItem key={agent.id} value={agent.id}>
                          {agent.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("customers.budgetRange")}</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-3">
              <Field label={t("customers.budgetMin")} error={errorFor("budgetMin")}>
                <Input
                  type="number"
                  min={0}
                  step={1000}
                  value={form.budgetMin}
                  onChange={(event) => set("budgetMin", event.target.value)}
                  dir="ltr"
                />
              </Field>
              <Field label={t("customers.budgetMax")} error={errorFor("budgetMax")}>
                <Input
                  type="number"
                  min={0}
                  step={1000}
                  value={form.budgetMax}
                  onChange={(event) => set("budgetMax", event.target.value)}
                  dir="ltr"
                />
              </Field>
              <Field label={t("customers.propertyType")} className="col-span-2">
                <Select
                  value={form.propertyType || "__none"}
                  onValueChange={(value) => set("propertyType", value === "__none" ? "" : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("common.selectPlaceholder")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none">{t("common.none")}</SelectItem>
                    {PROPERTY_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {enumLabel("propertyType", type)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label={t("customers.purpose")}>
                <Select value={form.purpose || "__none"} onValueChange={(value) => set("purpose", value === "__none" ? "" : value)}>
                  <SelectTrigger>
                    <SelectValue placeholder={t("common.selectPlaceholder")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none">{t("common.none")}</SelectItem>
                    {PROPERTY_PURPOSES.map((purpose) => (
                      <SelectItem key={purpose} value={purpose}>
                        {enumLabel("propertyPurpose", purpose)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex items-center justify-end gap-2">
        <Button type="button" variant="outline" asChild disabled={pending}>
          <Link href={backHref}>{t("common.cancel")}</Link>
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />}
          {mode === "create" ? t("common.create") : t("common.save")}
        </Button>
      </div>
    </form>
  );
}

function Field({
  label,
  required,
  error,
  children,
  className,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
  className?: string;
}) {
  const { t } = useI18n();
  return (
    <div className={className}>
      <Label className="mb-1.5 block">
        {label}
        {required ? (
          <span className="ms-0.5 text-destructive">*</span>
        ) : (
          <span className="ms-1 text-[10px] font-normal text-muted-foreground">({t("common.optional")})</span>
        )}
      </Label>
      {children}
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}

