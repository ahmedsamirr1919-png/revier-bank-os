"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  addMonths,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  parse,
  startOfMonth,
  startOfWeek,
} from "date-fns";
import { CalendarDays, ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useI18n } from "@/components/locale-provider";
import { cn, formatDate } from "@/lib/utils";
import type { TaskListItem } from "@/components/tasks/types";

const WEEK_START = { weekStartsOn: 1 as const };

export function CalendarView({
  month,
  tasks,
}: {
  month: string;
  tasks: TaskListItem[];
}) {
  const { t, dir, locale } = useI18n();
  const router = useRouter();
  const baseDate = parse(`${month}-01`, "yyyy-MM-dd", new Date());
  const monthStart = startOfMonth(baseDate);
  const monthEnd = endOfMonth(baseDate);
  const gridStart = startOfWeek(monthStart, WEEK_START);
  const gridEnd = endOfWeek(monthEnd, WEEK_START);
  const days = eachDayOfInterval({ start: gridStart, end: gridEnd });
  const today = new Date();

  const monthLabel = new Intl.DateTimeFormat(locale === "ar" ? "ar-AE" : "en-GB", {
    month: "long",
    year: "numeric",
    numberingSystem: "latn",
  }).format(monthStart);

  const weekdays = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(2024, 0, 1 + index); // Monday, 1 Jan 2024
    return new Intl.DateTimeFormat(locale === "ar" ? "ar-AE" : "en-GB", {
      weekday: "short",
    }).format(day);
  });

  const navigate = (date: Date) => {
    router.push(`/calendar?month=${format(date, "yyyy-MM")}`);
  };

  const PrevIcon = dir === "rtl" ? ChevronRight : ChevronLeft;
  const NextIcon = dir === "rtl" ? ChevronLeft : ChevronRight;

  const tasksFor = (day: Date) =>
    tasks.filter((task) => isSameDay(new Date(task.dueAt), day));

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-col gap-3 border-b p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon-sm" onClick={() => navigate(addMonths(baseDate, -1))}>
            <PrevIcon />
          </Button>
          <h2 className="min-w-40 text-center text-sm font-semibold capitalize">{monthLabel}</h2>
          <Button variant="outline" size="icon-sm" onClick={() => navigate(addMonths(baseDate, 1))}>
            <NextIcon />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => navigate(today)}>
            {t("calendar.today")}
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link href="/tasks">
              <CalendarDays />
              {t("tasks.title")}
            </Link>
          </Button>
          <Button size="sm" asChild>
            <Link href={`/tasks/new?dueAt=${format(today, "yyyy-MM-dd")}`}>
              <Plus />
              {t("calendar.addEvent")}
            </Link>
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <div className="min-w-[760px]">
          <div className="grid grid-cols-7 border-b bg-muted/40">
            {weekdays.map((weekday) => (
              <div
                key={weekday}
                className="px-2 py-2 text-center text-[11px] font-medium uppercase tracking-wide text-muted-foreground"
              >
                {weekday}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7">
            {days.map((day) => {
              const dayTasks = tasksFor(day);
              const inMonth = isSameMonth(day, baseDate);
              const isToday = isSameDay(day, today);
              return (
                <div
                  key={day.toISOString()}
                  className={cn(
                    "min-h-[112px] border-b border-e p-1.5 last:border-e-0",
                    !inMonth && "bg-muted/30",
                  )}
                >
                  <div className="mb-1 flex items-center justify-between">
                    <span
                      className={cn(
                        "flex size-6 items-center justify-center rounded-full text-xs",
                        !inMonth && "text-muted-foreground/60",
                        isToday && "bg-primary font-semibold text-primary-foreground",
                      )}
                    >
                      {format(day, "d")}
                    </span>
                    {dayTasks.length > 0 && (
                      <span className="text-[10px] text-muted-foreground">{dayTasks.length}</span>
                    )}
                  </div>

                  <div className="space-y-1">
                    {dayTasks.slice(0, 3).map((task) => {
                      const overdue =
                        task.status === "PENDING" && new Date(task.dueAt).getTime() < Date.now();
                      const done = task.status === "DONE";
                      return (
                        <Link
                          key={task.id}
                          href={`/tasks/${task.id}/edit`}
                          className={cn(
                            "block truncate rounded border-s-2 bg-muted/60 px-1.5 py-0.5 text-[10px] transition-colors hover:bg-accent",
                            overdue && "border-s-rose-500 bg-rose-500/10 text-rose-700 dark:text-rose-300",
                            done && "border-s-emerald-500 opacity-60 line-through",
                            !overdue && !done && "border-s-primary",
                          )}
                          title={`${task.title} · ${formatDate(task.dueAt, locale, true)}`}
                        >
                          {task.title}
                        </Link>
                      );
                    })}
                    {dayTasks.length > 3 && (
                      <p className="px-1 text-[10px] text-muted-foreground">
                        +{dayTasks.length - 3}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-4 border-t px-4 py-2.5 text-[11px] text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="size-2 rounded-full bg-primary" />
          {t("calendar.task")}
        </span>
        <span className="flex items-center gap-1.5">
          <span className="size-2 rounded-full bg-rose-500" />
          {t("tasks.overdue")}
        </span>
        <span className="flex items-center gap-1.5">
          <span className="size-2 rounded-full bg-emerald-500" />
          {t("tasks.completed")}
        </span>
      </div>
    </Card>
  );
}
