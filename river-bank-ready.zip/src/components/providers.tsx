"use client";

import type { ReactNode } from "react";
import { ThemeProvider } from "next-themes";
import { Toaster } from "sonner";
import { LocaleProvider } from "@/components/locale-provider";
import { TooltipProvider } from "@/components/ui/tooltip";
import type { Locale } from "@/lib/utils";

export function Providers({ initialLocale, children }: { initialLocale: Locale; children: ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      <LocaleProvider initialLocale={initialLocale}>
        <TooltipProvider delayDuration={250}>{children}</TooltipProvider>
        <Toaster richColors closeButton position="top-center" />
      </LocaleProvider>
    </ThemeProvider>
  );
}
