import type { NextAuthConfig } from "next-auth";
import type { Role } from "./lib/rbac";

export const SESSION_MAX_AGE_SECONDS = 30 * 24 * 60 * 60;
export const SHORT_SESSION_MS = 8 * 60 * 60 * 1000;
export const REMEMBER_SESSION_MS = SESSION_MAX_AGE_SECONDS * 1000;

/**
 * Edge-safe portion of the Auth.js config. Imported by middleware, so it must
 * not touch Prisma, bcrypt or any Node-only module.
 */
export const authConfig = {
  trustHost: true,
  pages: { signIn: "/login" },
  session: { strategy: "jwt", maxAge: SESSION_MAX_AGE_SECONDS },
  providers: [],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id as string;
        token.role = (user.role as Role) ?? "AGENT";
        token.managerId = user.managerId ?? null;
        token.mustChangePassword = Boolean(user.mustChangePassword);
        token.locale = user.locale ?? "en";
        token.remember = Boolean(user.remember);
        token.authAt = Date.now();
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = (token.id as string) ?? token.sub ?? "";
        session.user.role = (token.role as Role) ?? "AGENT";
        session.user.managerId = (token.managerId as string | null) ?? null;
        session.user.mustChangePassword = Boolean(token.mustChangePassword);
        session.user.locale = (token.locale as string) ?? "en";
      }
      session.authAt = token.authAt as number | undefined;
      session.remember = Boolean(token.remember);
      return session;
    },
  },
} satisfies NextAuthConfig;
