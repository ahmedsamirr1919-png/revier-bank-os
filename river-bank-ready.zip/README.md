# River Bank CRM

A full-stack real-estate CRM built with Next.js App Router, TypeScript, Tailwind CSS, shadcn/ui, Prisma and PostgreSQL (Supabase).

## Stack

- Next.js 15 (App Router) + React 19 + TypeScript
- Tailwind CSS 4 (CSS-first) + shadcn/ui
- Prisma 6 + PostgreSQL (Supabase)
- Auth.js (NextAuth) credentials + bcrypt + sessions
- Zod validation, recharts, jsPDF, xlsx
- Arabic (RTL) and English UI, UTF-8 throughout

## Database

The application database is Supabase PostgreSQL. Prisma is used as the data-access layer only; it is not a database.

Use the **transaction pooler** URL (port `6543`, `pgbouncer=true`) for the app and the **direct** URL (port `5432`) for schema changes. See `.env.example`. Never commit `.env`.

## Getting started

```bash
cd river-bank
npm install
cp .env.example .env
# edit .env: DATABASE_URL, DIRECT_URL, AUTH_SECRET, and Supabase storage keys
npx prisma db push
npx tsx scripts/search-reindex.ts
npm run dev
```

Open http://localhost:3000.

### Create a fresh database from the SQL export

`riverbank-supabase.sql` contains the full schema plus data (UTF-8, no BOM). It contains real CRM data and password hashes, so keep it private and never commit it to a public repository.

To import it:

1. Create an empty Supabase project.
2. Paste the whole file into the Supabase SQL Editor and run it.
3. Set `DATABASE_URL` / `DIRECT_URL` in `.env`.
4. Rebuild the search index: `npx tsx scripts/search-reindex.ts`.

### Data tools

- `node scripts/verify-all-data.cjs [path-to.xlsx]` - compares every customer, property, activity and user against the Excel source and checks for encoding problems.
- `node scripts/build-sql-export.cjs` - regenerates `riverbank-supabase.sql` from the live database (UTF-8, no BOM).
- `npx tsx scripts/search-reindex.ts` - rebuilds the derived search index.

The latest full verification is recorded in `DATA-VERIFICATION.md`.

## Scripts

- `npm run dev` - development server
- `npm run build` - production build
- `npm run start` - production server
- `npm run typecheck` - TypeScript
- `npm run db:migrate` - create/apply migrations (dev)
- `npm run db:push` - push schema without migration
- `npm run db:seed` - seed demo data
- `npm run db:reset` - drop, migrate and seed (destructive)

## Production deployment

1. Set the environment variables from `.env.example` in the hosting provider (Vercel, Railway, Render, or a VPS).
2. Run `npm run build`.
3. Run `npm run start` (or let the platform run it).
4. Verify `/api/health`, `/login` and `/dashboard`.

For serverless platforms keep `connection_limit=1` in `DATABASE_URL`; the pooler handles the real connection pool.

## Demo credentials

| Role  | Email               | Password    |
| ----- | ------------------- | ----------- |
| Admin | admin@riverbank.com | Admin@12345 |

Imported Excel users use `<username>@riverbank.local`. Change the admin password after the first login in production.

## Roles & scope

- **Admin** - full access, including user management, settings, soft-delete/restore, audit log.
- **Sales Manager** - sees own records plus direct reports and unassigned records.
- **Sales Agent** - sees only own records.

Protection is enforced in middleware, API routes and query-level scopes.

## Notable features

- Customers with 7-stage pipeline, search/filter/sort/pagination, timeline, CSV import/export.
- Properties with images, owner details, tags, rent/sale purpose and customer links.
- Deals (kanban + table), stage history, tasks/reminders, calendar.
- Feedback: internal logging, tokenized public form (`/f/<token>`), replies, resolve/reopen, negative-feedback alerts.
- Dashboard with cards, charts, employee performance and alerts; Reports with PDF/Excel export.
- Arabic (RTL) + English toggle, dark mode, responsive layout.
- Admin database backup download at `/api/backup`.

## Environment

See `.env.example`. Key variables: `DATABASE_URL`, `DIRECT_URL`, `AUTH_SECRET`, `AUTH_TRUST_HOST`, `NEXTAUTH_URL`, `NEXT_PUBLIC_APP_URL`, `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_STORAGE_BUCKET`.
