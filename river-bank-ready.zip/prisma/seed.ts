/**
 * River Bank CRM — demo seed
 * Run with: npm run db:seed
 *
 * Creates: 3 users (one per role), 20 customers, 10 properties, 8 deals,
 * 10 tasks, 8 feedback entries, activity timeline, audit log and notifications.
 */
import { PrismaClient } from "@prisma/client";
import { hashSync } from "bcryptjs";
import { randomBytes } from "node:crypto";

const prisma = new PrismaClient();

const DAY = 24 * 60 * 60 * 1000;
const now = Date.now();
const daysAgo = (days: number, hour = 10) => {
  const d = new Date(now - days * DAY);
  d.setHours(hour, 0, 0, 0);
  return d;
};
const daysAhead = (days: number, hour = 10) => daysAgo(-days, hour);
const pad = (n: number, width = 4) => String(n).padStart(width, "0");
const token = () => randomBytes(24).toString("hex");
const commission = (value: number, rate = 2.5) => Math.round((value * rate) / 100);

const adminId = "usr_admin_riverbank";
const managerId = "usr_manager_riverbank";
const agentId = "usr_agent_riverbank";

const PASSWORD_ADMIN = "Admin@12345";
const PASSWORD_MANAGER = "Manager@12345";
const PASSWORD_AGENT = "Agent@12345";

async function main() {
  console.log("🌊 Seeding River Bank CRM…");

  // Wipe in dependency order so the seed is repeatable.
  await prisma.notification.deleteMany();
  await prisma.feedbackReply.deleteMany();
  await prisma.feedback.deleteMany();
  await prisma.task.deleteMany();
  await prisma.dealStageHistory.deleteMany();
  await prisma.deal.deleteMany();
  await prisma.customerProperty.deleteMany();
  await prisma.propertyImage.deleteMany();
  await prisma.property.deleteMany();
  await prisma.customerActivity.deleteMany();
  await prisma.customer.deleteMany();
  await prisma.activityLog.deleteMany();
  await prisma.setting.deleteMany();
  await prisma.user.deleteMany();

  // ── Users ────────────────────────────────────────────────────────────────
  const admin = await prisma.user.create({
    data: {
      id: adminId,
      name: "Omar Haddad",
      email: "admin@riverbank.com",
      passwordHash: hashSync(PASSWORD_ADMIN, 10),
      role: "ADMIN",
      phone: "+971 50 100 1000",
      mustChangePassword: true,
      locale: "en",
      lastLoginAt: daysAgo(1),
    },
  });

  const manager = await prisma.user.create({
    data: {
      id: managerId,
      name: "Faisal Al Mansoori",
      email: "manager@riverbank.com",
      passwordHash: hashSync(PASSWORD_MANAGER, 10),
      role: "MANAGER",
      phone: "+971 50 200 2000",
      locale: "en",
      lastLoginAt: daysAgo(2),
    },
  });

  const agent = await prisma.user.create({
    data: {
      id: agentId,
      name: "Layla Hassan",
      email: "agent@riverbank.com",
      passwordHash: hashSync(PASSWORD_AGENT, 10),
      role: "AGENT",
      phone: "+971 50 300 3000",
      locale: "en",
      managerId: manager.id,
      lastLoginAt: daysAgo(0, 8),
    },
  });

  // ── Customers ────────────────────────────────────────────────────────────
  const customersSeed: Array<{
    name: string;
    phone: string;
    email: string;
    source: string;
    status: string;
    area: string;
    type: string;
    min: number;
    max: number;
    days: number;
    agent: string | null;
    notes?: string;
  }> = [
    { name: "Ahmed Al Suwaidi", phone: "+971 50 411 2201", email: "ahmed.suwaidi@example.com", source: "WEBSITE", status: "NEW", area: "Dubai Marina", type: "APARTMENT", min: 1_200_000, max: 1_900_000, days: 2, agent: agentId, notes: "Wants a marina view, cash buyer." },
    { name: "Sarah Mitchell", phone: "+971 50 411 2202", email: "sarah.mitchell@example.com", source: "ADS", status: "NEW", area: "Dubai Hills", type: "VILLA", min: 2_000_000, max: 3_000_000, days: 4, agent: agentId },
    { name: "Rajesh Menon", phone: "+971 50 411 2203", email: "rajesh.menon@example.com", source: "REFERRAL", status: "CONTACTED", area: "Business Bay", type: "APARTMENT", min: 900_000, max: 1_400_000, days: 6, agent: agentId },
    { name: "Fatima Al Zahra", phone: "+971 50 411 2204", email: "fatima.zahra@example.com", source: "WALK_IN", status: "CONTACTED", area: "JVC", type: "APARTMENT", min: 600_000, max: 950_000, days: 8, agent: agentId },
    { name: "Daniel Okafor", phone: "+971 50 411 2205", email: "daniel.okafor@example.com", source: "SOCIAL", status: "INTERESTED", area: "Creek Harbour", type: "APARTMENT", min: 1_800_000, max: 3_000_000, days: 12, agent: agentId },
    { name: "Nour Haddad", phone: "+971 50 411 2206", email: "nour.haddad@example.com", source: "WEBSITE", status: "INTERESTED", area: "Downtown Dubai", type: "APARTMENT", min: 1_300_000, max: 1_800_000, days: 15, agent: agentId },
    { name: "James Whitfield", phone: "+971 50 411 2207", email: "james.whitfield@example.com", source: "ADS", status: "SITE_VISIT", area: "Arabian Ranches", type: "VILLA", min: 2_200_000, max: 3_100_000, days: 20, agent: agentId },
    { name: "Mariam Al Balushi", phone: "+971 50 411 2208", email: "mariam.balushi@example.com", source: "REFERRAL", status: "SITE_VISIT", area: "Palm Jumeirah", type: "VILLA", min: 3_000_000, max: 4_500_000, days: 26, agent: agentId },
    { name: "Hassan Karim", phone: "+971 50 411 2209", email: "hassan.karim@example.com", source: "WEBSITE", status: "NEGOTIATION", area: "Dubai Marina", type: "APARTMENT", min: 1_500_000, max: 2_000_000, days: 34, agent: agentId, notes: "Negotiating 5% off the Marina unit." },
    { name: "Elena Petrova", phone: "+971 50 411 2210", email: "elena.petrova@example.com", source: "REFERRAL", status: "NEGOTIATION", area: "Palm Jumeirah", type: "VILLA", min: 2_800_000, max: 3_800_000, days: 41, agent: agentId },
    { name: "Omar Farouk", phone: "+971 50 411 2211", email: "omar.farouk@example.com", source: "WALK_IN", status: "CLOSED_WON", area: "Downtown Dubai", type: "APARTMENT", min: 1_200_000, max: 1_600_000, days: 68, agent: agentId },
    { name: "Priya Sharma", phone: "+971 50 411 2212", email: "priya.sharma@example.com", source: "WEBSITE", status: "CLOSED_WON", area: "Dubai Hills", type: "VILLA", min: 1_800_000, max: 2_300_000, days: 95, agent: agentId },
    { name: "Khalid Al Nuaimi", phone: "+971 50 411 2213", email: "khalid.nuaimi@example.com", source: "REFERRAL", status: "CLOSED_WON", area: "Creek Harbour", type: "APARTMENT", min: 3_500_000, max: 4_500_000, days: 120, agent: managerId, notes: "Investor, referred by the Al Nuaimi family office." },
    { name: "Sophie Laurent", phone: "+971 50 411 2214", email: "sophie.laurent@example.com", source: "ADS", status: "CLOSED_LOST", area: "JVC", type: "APARTMENT", min: 700_000, max: 1_000_000, days: 140, agent: agentId, notes: "Chose a competing project on payment plan." },
    { name: "Vikram Patel", phone: "+971 50 411 2215", email: "vikram.patel@example.com", source: "WEBSITE", status: "NEW", area: "Business Bay", type: "COMMERCIAL", min: 1_000_000, max: 1_800_000, days: 55, agent: agentId },
    { name: "Aisha Rahman", phone: "+971 50 411 2216", email: "aisha.rahman@example.com", source: "SOCIAL", status: "NEW", area: "Al Barsha", type: "APARTMENT", min: 800_000, max: 1_200_000, days: 61, agent: managerId },
    { name: "Luca Moretti", phone: "+971 50 411 2217", email: "luca.moretti@example.com", source: "REFERRAL", status: "CONTACTED", area: "Mudon", type: "LAND", min: 600_000, max: 900_000, days: 72, agent: agentId },
    { name: "Huda Al Hashimi", phone: "+971 50 411 2218", email: "huda.hashimi@example.com", source: "WALK_IN", status: "INTERESTED", area: "Dubai Hills", type: "VILLA", min: 2_000_000, max: 2_800_000, days: 80, agent: managerId },
    { name: "Michael Chen", phone: "+971 50 411 2219", email: "michael.chen@example.com", source: "WEBSITE", status: "SITE_VISIT", area: "Business Bay", type: "COMMERCIAL", min: 900_000, max: 1_300_000, days: 88, agent: agentId },
    { name: "Layla Salem", phone: "+971 50 411 2220", email: "layla.salem@example.com", source: "ADS", status: "NEGOTIATION", area: "Dubai Marina", type: "APARTMENT", min: 1_100_000, max: 1_600_000, days: 110, agent: null },
  ];

  const customers = [] as Array<{ id: string }>;
  for (const [index, c] of customersSeed.entries()) {
    const created = daysAgo(c.days, 9 + (index % 8));
    const customer = await prisma.customer.create({
      data: {
        code: `RB-C-${pad(index + 1)}`,
        fullName: c.name,
        phone: c.phone,
        email: c.email,
        whatsapp: c.phone,
        source: c.source,
        status: c.status,
        budgetMin: c.min,
        budgetMax: c.max,
        currency: "EGP",
        preferredArea: c.area,
        propertyType: c.type,
        assignedAgentId: c.agent,
        createdById: index % 3 === 0 ? managerId : agentId,
        notes: c.notes ?? null,
        createdAt: created,
        updatedAt: created,
      },
      select: { id: true },
    });
    customers.push(customer);
  }

  // ── Properties ───────────────────────────────────────────────────────────
  const propertiesSeed = [
    { title: "Marina Skyline Residence", type: "APARTMENT", price: 1_850_000, area: 128, location: "Dubai Marina", bedrooms: 2, bathrooms: 2, status: "AVAILABLE", description: "High-floor two-bedroom with full marina views, private balcony and access to a 25m pool.", ownerName: "Khalid Al Mansoori", ownerPhone: "+971501234567", ownerEmail: "khalid.almansoori@example.com", ownerIdNumber: "784-1985-1234567-1", ownerNotes: "Prefers contact via WhatsApp in the evening." },
    { title: "Palm Jumeirah Signature Villa", type: "VILLA", price: 3_400_000, area: 420, location: "Palm Jumeirah", bedrooms: 5, bathrooms: 6, status: "RESERVED", description: "Frond villa with private beach segment, landscaped garden and majlis.", ownerName: "Fatima Al Suwaidi", ownerPhone: "+971502345678", ownerEmail: "fatima.alsuwaidi@example.com", ownerIdNumber: "784-1979-2345678-2", ownerNotes: null },
    { title: "Downtown Burj View Apartment", type: "APARTMENT", price: 1_450_000, area: 96, location: "Downtown Dubai", bedrooms: 2, bathrooms: 2, status: "SOLD", description: "Direct Burj Khalifa views from the living room and both bedrooms.", ownerName: "Omar Al Falasi", ownerPhone: "+971503456789", ownerEmail: "omar.alfalasi@example.com", ownerIdNumber: "784-1982-3456789-3", ownerNotes: "Title deed available at the office." },
    { title: "Dubai Hills Family Villa", type: "VILLA", price: 2_100_000, area: 310, location: "Dubai Hills Estate", bedrooms: 4, bathrooms: 4, status: "SOLD", description: "Golf-facing family home with a shaded garden and upgraded kitchen.", ownerName: "Mariam Al Zaabi", ownerPhone: "+971504567890", ownerEmail: "mariam.alzaabi@example.com", ownerIdNumber: "784-1988-4567890-4", ownerNotes: null },
    { title: "Creek Harbour Waterfront Penthouse", type: "APARTMENT", price: 4_300_000, area: 240, location: "Creek Harbour", bedrooms: 3, bathrooms: 4, status: "SOLD", description: "Duplex penthouse with a 60 sqm terrace overlooking the creek and skyline.", ownerName: "Ahmed Al Hashimi", ownerPhone: "+971505678901", ownerEmail: "ahmed.alhashimi@example.com", ownerIdNumber: "784-1975-5678901-5", ownerNotes: null },
    { title: "JVC Starter Apartment", type: "APARTMENT", price: 900_000, area: 72, location: "Jumeirah Village Circle", bedrooms: 1, bathrooms: 1, status: "AVAILABLE", description: "Bright one-bedroom, fully fitted kitchen, ready to move in.", ownerName: "Noor Al Marri", ownerPhone: "+971506789012", ownerEmail: "noor.almarri@example.com", ownerIdNumber: "784-1992-6789012-6", ownerNotes: null },
    { title: "Business Bay Office Floor", type: "COMMERCIAL", price: 1_100_000, area: 180, location: "Business Bay", bedrooms: null, bathrooms: null, status: "AVAILABLE", description: "Fitted half-floor office with 12 workstations and a meeting room.", ownerName: "Sultan Al Qasimi", ownerPhone: "+971507890123", ownerEmail: "sultan.alqasimi@example.com", ownerIdNumber: "784-1980-7890123-7", ownerNotes: "Company-owned unit; invoices required for all transactions." },
    { title: "Arabian Ranches Townhouse", type: "VILLA", price: 2_700_000, area: 285, location: "Arabian Ranches", bedrooms: 4, bathrooms: 3, status: "RESERVED", description: "Corner townhouse backing onto the community park.", ownerName: "Huda Al Ketbi", ownerPhone: "+971508901234", ownerEmail: "huda.alketbi@example.com", ownerIdNumber: "784-1986-8901234-8", ownerNotes: null },
    { title: "Al Barsha Retail Unit", type: "COMMERCIAL", price: 1_600_000, area: 140, location: "Al Barsha", bedrooms: null, bathrooms: null, status: "AVAILABLE", description: "Ground-floor retail with 18m frontage and ample parking.", ownerName: "Rashid Al Nuaimi", ownerPhone: "+971509012345", ownerEmail: "rashid.alnuaimi@example.com", ownerIdNumber: "784-1977-9012345-9", ownerNotes: null },
    { title: "Mudon Residential Plot", type: "LAND", price: 750_000, area: 500, location: "Mudon", bedrooms: null, bathrooms: null, status: "AVAILABLE", description: "G+1 plot in a established villa community, utilities connected.", ownerName: "Layla Al Shamsi", ownerPhone: "+971500123456", ownerEmail: "layla.alshamsi@example.com", ownerIdNumber: "784-1990-0123456-0", ownerNotes: "Plot boundary survey attached to the listing file." },
  ];

  const properties = [] as Array<{ id: string }>;
  for (const [index, p] of propertiesSeed.entries()) {
    const created = daysAgo(140 - index * 9, 11);
    const property = await prisma.property.create({
      data: {
        code: `RB-P-${pad(index + 1)}`,
        title: p.title,
        type: p.type,
        price: p.price,
        area: p.area,
        location: p.location,
        city: "Dubai",
        bedrooms: p.bedrooms,
        bathrooms: p.bathrooms,
        status: p.status,
        description: p.description,
        ownerName: p.ownerName,
        ownerPhone: p.ownerPhone,
        ownerEmail: p.ownerEmail,
        ownerIdNumber: p.ownerIdNumber,
        ownerNotes: p.ownerNotes,
        createdById: index % 2 === 0 ? adminId : managerId,
        createdAt: created,
        updatedAt: created,
        images: {
          create: [
            { url: `https://picsum.photos/seed/rb-property-${index + 1}/1200/800`, alt: p.title, sortOrder: 0, isPrimary: true },
            { url: `https://picsum.photos/seed/rb-property-${index + 1}-b/1200/800`, alt: `${p.title} interior`, sortOrder: 1 },
          ],
        },
      },
      select: { id: true },
    });
    properties.push(property);
  }

  // ── Customer timelines ───────────────────────────────────────────────────
  const activitySamples = [
    { type: "CALL", title: "Introductory call", body: "Discussed budget and preferred areas. Sending a shortlist next." },
    { type: "NOTE", title: "Qualified the lead", body: "Cash buyer, ready to move within 60 days." },
    { type: "MEETING", title: "Office meeting", body: "Walked through three options in the marina and downtown." },
    { type: "SITE_VISIT", title: "Site visit completed", body: "Liked the layout; asked about service charges and parking." },
  ];

  for (const [i, customer] of customers.slice(0, 12).entries()) {
    const base = customersSeed[i].days;
    for (let j = 0; j < 3; j += 1) {
      const sample = activitySamples[(i + j) % activitySamples.length];
      await prisma.customerActivity.create({
        data: {
          customerId: customer.id,
          userId: customersSeed[i].agent ?? agentId,
          type: sample.type,
          title: sample.title,
          body: sample.body,
          occurredAt: daysAgo(Math.max(0, base - j * 3 - 1), 10 + j),
          createdAt: daysAgo(Math.max(0, base - j * 3 - 1), 10 + j),
        },
      });
    }
  }

  // ── Deals ────────────────────────────────────────────────────────────────
  const dealsSeed = [
    { customer: 8, property: 0, agent: agentId, value: 1_800_000, stage: "NEGOTIATION", probability: 65, days: 34, close: 18, title: "Marina Skyline — Hassan Karim" },
    { customer: 9, property: 1, agent: agentId, value: 3_200_000, stage: "UNDER_CONTRACT", probability: 85, days: 41, close: 9, title: "Palm Signature Villa — Elena Petrova" },
    { customer: 10, property: 2, agent: agentId, value: 1_450_000, stage: "CLOSED_WON", probability: 100, days: 68, close: -45, title: "Downtown Burj View — Omar Farouk", closedDaysAgo: 45 },
    { customer: 11, property: 3, agent: agentId, value: 2_100_000, stage: "CLOSED_WON", probability: 100, days: 95, close: -18, title: "Dubai Hills Villa — Priya Sharma", closedDaysAgo: 18 },
    { customer: 12, property: 4, agent: managerId, value: 4_300_000, stage: "CLOSED_WON", probability: 100, days: 120, close: -7, title: "Creek Penthouse — Khalid Al Nuaimi", closedDaysAgo: 7 },
    { customer: 13, property: 5, agent: agentId, value: 900_000, stage: "CLOSED_LOST", probability: 0, days: 140, close: -60, title: "JVC Starter — Sophie Laurent", closedDaysAgo: 60, lostReason: "Chose a competing project with a longer payment plan." },
    { customer: 18, property: 6, agent: agentId, value: 1_100_000, stage: "PROSPECTING", probability: 25, days: 88, close: 30, title: "Business Bay Office — Michael Chen" },
    { customer: 17, property: 7, agent: managerId, value: 2_700_000, stage: "ON_HOLD", probability: 40, days: 80, close: 45, title: "Arabian Ranches — Huda Al Hashimi" },
  ];

  const deals = [] as Array<{ id: string; code: string }>;
  for (const [index, d] of dealsSeed.entries()) {
    const createdAt = daysAgo(d.days, 12);
    const closedAt = d.closedDaysAgo !== undefined ? daysAgo(d.closedDaysAgo, 16) : null;
    const deal = await prisma.deal.create({
      data: {
        code: `RB-D-${pad(index + 1)}`,
        title: d.title,
        customerId: customers[d.customer].id,
        propertyId: properties[d.property].id,
        agentId: d.agent,
        value: d.value,
        commissionRate: 2.5,
        commissionAmount: commission(d.value),
        stage: d.stage,
        probability: d.probability,
        expectedCloseDate: daysAhead(d.close, 17),
        closedAt,
        lostReason: d.lostReason ?? null,
        notes: null,
        createdAt,
        updatedAt: closedAt ?? createdAt,
        stageHistory: {
          create: [
            { toStage: "PROSPECTING", createdAt, note: "Deal created" },
            ...(d.stage !== "PROSPECTING"
              ? [{ fromStage: "PROSPECTING", toStage: d.stage, changedById: d.agent, createdAt: closedAt ?? daysAgo(Math.max(1, d.days - 20), 15) }]
              : []),
          ],
        },
      },
      select: { id: true, code: true },
    });
    deals.push(deal);
  }

  // Link interested / purchased properties to customers
  const links: Array<{ customer: number; property: number; relation: string }> = [
    { customer: 0, property: 0, relation: "INTERESTED" },
    { customer: 1, property: 1, relation: "INTERESTED" },
    { customer: 4, property: 4, relation: "INTERESTED" },
    { customer: 5, property: 2, relation: "INTERESTED" },
    { customer: 6, property: 7, relation: "INTERESTED" },
    { customer: 7, property: 1, relation: "INTERESTED" },
    { customer: 8, property: 0, relation: "INTERESTED" },
    { customer: 9, property: 1, relation: "INTERESTED" },
    { customer: 10, property: 2, relation: "PURCHASED" },
    { customer: 11, property: 3, relation: "PURCHASED" },
    { customer: 12, property: 4, relation: "PURCHASED" },
    { customer: 13, property: 5, relation: "INTERESTED" },
    { customer: 17, property: 7, relation: "INTERESTED" },
    { customer: 18, property: 6, relation: "INTERESTED" },
  ];
  for (const link of links) {
    await prisma.customerProperty.create({
      data: {
        customerId: customers[link.customer].id,
        propertyId: properties[link.property].id,
        relation: link.relation,
      },
    });
  }

  // ── Tasks ────────────────────────────────────────────────────────────────
  const tasksSeed = [
    { title: "Call Hassan about the Marina counter-offer", type: "CALL_BACK", priority: "HIGH", status: "PENDING", due: daysAhead(0, 14), agent: agentId, customer: 8, deal: 0, description: "Confirm whether 1.8M is accepted." },
    { title: "Site visit — Palm villa with Elena", type: "SITE_VISIT", priority: "HIGH", status: "PENDING", due: daysAhead(1, 11), agent: agentId, customer: 9, deal: 1, property: 1 },
    { title: "Prepare contract summary for Omar", type: "MEETING", priority: "MEDIUM", status: "PENDING", due: daysAhead(3, 10), agent: agentId, customer: 10, deal: 2 },
    { title: "Follow up Priya on handover", type: "FOLLOW_UP", priority: "HIGH", status: "PENDING", due: daysAgo(1, 9), agent: agentId, customer: 11, deal: 3 },
    { title: "Send floor plans to Michael", type: "OTHER", priority: "MEDIUM", status: "PENDING", due: daysAhead(2, 12), agent: agentId, customer: 18, deal: 6 },
    { title: "Weekly pipeline review", type: "MEETING", priority: "MEDIUM", status: "PENDING", due: daysAhead(5, 9), agent: managerId },
    { title: "Call back Aisha Rahman", type: "CALL_BACK", priority: "MEDIUM", status: "PENDING", due: daysAhead(1, 15), agent: agentId, customer: 15 },
    { title: "Collect feedback from Khalid", type: "FOLLOW_UP", priority: "LOW", status: "PENDING", due: daysAhead(6, 10), agent: managerId, customer: 12, deal: 4 },
    { title: "Update listing photos for JVC apartment", type: "OTHER", priority: "LOW", status: "DONE", due: daysAgo(2, 11), agent: agentId, completedDaysAgo: 2 },
    { title: "Confirm payment receipt for Sophie", type: "FOLLOW_UP", priority: "MEDIUM", status: "CANCELLED", due: daysAgo(5, 13), agent: agentId, customer: 13, deal: 5 },
  ];

  for (const task of tasksSeed) {
    await prisma.task.create({
      data: {
        title: task.title,
        description: task.description ?? null,
        type: task.type,
        priority: task.priority,
        status: task.status,
        dueAt: task.due,
        completedAt: task.completedDaysAgo ? daysAgo(task.completedDaysAgo, 12) : null,
        customerId: task.customer !== undefined ? customers[task.customer].id : null,
        dealId: task.deal !== undefined ? deals[task.deal].id : null,
        propertyId: task.property !== undefined ? properties[task.property].id : null,
        assignedToId: task.agent,
        createdById: task.agent === managerId ? adminId : managerId,
      },
    });
  }

  // ── Feedback ─────────────────────────────────────────────────────────────
  const feedbackSeed = [
    { rating: 5, categories: ["service", "property"], comment: "The whole process felt effortless. The team knew every detail of the building.", customer: 10, deal: 2, agent: agentId, days: 42, status: "RESOLVED" },
    { rating: 4, categories: ["agent_behavior"], comment: "Layla was responsive and honest about the delays. Very professional.", customer: 11, deal: 3, agent: agentId, days: 15, status: "NEW" },
    { rating: 2, categories: ["price", "service"], comment: "Service charges were not explained clearly before the reservation.", customer: 13, deal: 5, agent: agentId, days: 55, status: "NEW", negative: true },
    { rating: 5, categories: ["service"], comment: "Faisal handled the negotiation personally. We felt looked after.", customer: 12, deal: 4, agent: managerId, days: 6, status: "RESOLVED" },
    { rating: 3, categories: ["property"], comment: "The apartment is good but the parking allocation was smaller than promised.", customer: 9, deal: 1, agent: agentId, days: 9, status: "RESOLVED" },
    { rating: 1, categories: ["agent_behavior"], comment: "I had to chase for a call back three times. Disappointing.", customer: 14, deal: 5, agent: agentId, days: 70, status: "NEW", negative: true },
    { rating: 4, categories: ["price"], comment: "Fair price for the area. Paperwork was quick.", customer: 8, deal: 0, agent: agentId, days: 3, status: "NEW" },
    { rating: 5, categories: ["service", "agent_behavior"], comment: "Would recommend to friends. Everything was transparent.", customer: 18, deal: 6, agent: agentId, days: 20, status: "RESOLVED" },
  ];

  for (const [index, f] of feedbackSeed.entries()) {
    const created = daysAgo(f.days, 17);
    const feedback = await prisma.feedback.create({
      data: {
        token: token(),
        source: index % 3 === 0 ? "PUBLIC" : "INTERNAL",
        rating: f.rating,
        categories: JSON.stringify(f.categories),
        comment: f.comment,
        customerId: customers[f.customer].id,
        dealId: deals[f.deal].id,
        agentId: f.agent,
        submittedByName: customersSeed[f.customer].name,
        isNegative: Boolean(f.negative) || f.rating <= 2,
        status: f.status,
        resolvedAt: f.status === "RESOLVED" ? daysAgo(Math.max(0, f.days - 2), 12) : null,
        resolvedById: f.status === "RESOLVED" ? managerId : null,
        createdAt: created,
        updatedAt: created,
      },
    });

    if (f.status === "RESOLVED") {
      await prisma.feedbackReply.create({
        data: {
          feedbackId: feedback.id,
          authorId: f.agent === managerId ? adminId : managerId,
          body: "Thank you for the detailed feedback — we have shared it with the team and followed up with you directly.",
          createdAt: daysAgo(Math.max(0, f.days - 1), 11),
        },
      });
    }
  }

  // ── Audit log ────────────────────────────────────────────────────────────
  const auditEntries = [
    { userId: adminId, email: "admin@riverbank.com", action: "LOGIN", entityType: "User", entityId: adminId, description: "Omar Haddad signed in", days: 1 },
    { userId: managerId, email: "manager@riverbank.com", action: "LOGIN", entityType: "User", entityId: managerId, description: "Faisal Al Mansoori signed in", days: 2 },
    { userId: agentId, email: "agent@riverbank.com", action: "LOGIN", entityType: "User", entityId: agentId, description: "Layla Hassan signed in", days: 0 },
    { userId: managerId, email: "manager@riverbank.com", action: "CREATE", entityType: "Customer", entityId: customers[0].id, description: "Created customer Ahmed Al Suwaidi", days: 2 },
    { userId: agentId, email: "agent@riverbank.com", action: "STATUS_CHANGE", entityType: "Customer", entityId: customers[8].id, description: "Moved Hassan Karim to NEGOTIATION", days: 4 },
    { userId: agentId, email: "agent@riverbank.com", action: "CREATE", entityType: "Deal", entityId: deals[0].id, description: "Created deal RB-D-0001", days: 34 },
    { userId: managerId, email: "manager@riverbank.com", action: "STATUS_CHANGE", entityType: "Deal", entityId: deals[2].id, description: "Closed deal RB-D-0003 as won", days: 45 },
    { userId: managerId, email: "manager@riverbank.com", action: "RESOLVE", entityType: "Feedback", entityId: "feedback-1", description: "Resolved feedback from Omar Farouk", days: 40 },
    { userId: adminId, email: "admin@riverbank.com", action: "IMPORT", entityType: "Customer", entityId: null, description: "Imported 6 customers from CSV", days: 8 },
    { userId: agentId, email: "agent@riverbank.com", action: "EXPORT", entityType: "Customer", entityId: null, description: "Exported 12 customers to CSV", days: 3 },
    { userId: managerId, email: "manager@riverbank.com", action: "ASSIGN", entityType: "Customer", entityId: customers[15].id, description: "Assigned Aisha Rahman to Layla Hassan", days: 55 },
    { userId: null, email: "unknown@example.com", action: "LOGIN_FAILED", entityType: "User", entityId: null, description: "Failed sign-in for unknown email unknown@example.com", days: 1 },
  ];

  for (const entry of auditEntries) {
    await prisma.activityLog.create({
      data: {
        userId: entry.userId,
        userEmail: entry.email,
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId,
        description: entry.description,
        ip: "127.0.0.1",
        userAgent: "Mozilla/5.0 (seed)",
        createdAt: daysAgo(entry.days, 12),
      },
    });
  }

  // ── Notifications ────────────────────────────────────────────────────────
  await prisma.notification.createMany({
    data: [
      { userId: agentId, type: "TASK_DUE", title: "Call Hassan about the Marina counter-offer", body: "Due today at 14:00", link: "/tasks", isRead: false, createdAt: daysAgo(0, 8) },
      { userId: agentId, type: "FEEDBACK_NEGATIVE", title: "Negative feedback received", body: "A 2★ rating was submitted for RB-D-0006", link: "/feedback", isRead: false, createdAt: daysAgo(1, 9) },
      { userId: managerId, type: "FEEDBACK_NEGATIVE", title: "Negative feedback needs attention", body: "Layla Hassan received a 1★ rating", link: "/feedback", isRead: false, createdAt: daysAgo(1, 9) },
      { userId: agentId, type: "DEAL_WON", title: "Deal closed won", body: "RB-D-0004 — Dubai Hills Villa", link: "/deals", isRead: true, createdAt: daysAgo(18, 16) },
    ],
  });

  // ── Settings ─────────────────────────────────────────────────────────────
  await prisma.setting.createMany({
    data: [
      { key: "company.name", value: "River Bank Real Estate" },
      { key: "company.currency", value: "EGP" },
      { key: "deals.commissionRate", value: "2.5" },
      { key: "feedback.negativeThreshold", value: "2" },
      { key: "app.version", value: "1.0.0" },
    ],
  });

  console.log("✅ Seed complete");
  console.log("   Admin   admin@riverbank.com   / " + PASSWORD_ADMIN + "  (must change on first login)");
  console.log("   Manager manager@riverbank.com / " + PASSWORD_MANAGER);
  console.log("   Agent   agent@riverbank.com   / " + PASSWORD_AGENT);
}

main()
  .catch((error) => {
    console.error("❌ Seed failed", error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
