# Data verification report

Verified on 2026-11-03 against the Excel source.

## Source file

- Primary path `E:\Riverbank.xlsx` was not connected during verification.
- Verified against the identical copy at `D:\Ahmed Refay\Riverbank.xlsx` (the source used for the import).

## Result: ALL CHECKS PASSED

| Check | Excel | Database | Mismatches |
| --- | ---: | ---: | ---: |
| Customers | 339 | 339 | 0 |
| Properties | 343 | 343 | 0 |
| Activities | 21 | 21 | 0 |
| Users (Excel) | 8 | 8 | 0 |
| Users (total, incl. admin) | - | 9 | - |

Field-level checks (every row):

- Customer full name: 0 mismatches
- Customer phone: 0 mismatches
- Property title/address: 0 mismatches
- Property location: 0 mismatches
- Property price: 0 mismatches
- Property area: 0 mismatches
- Property owner name: 0 mismatches
- Arabic mojibake (`Ø`, `Ù`, `Ã`, `Â`, U+FFFD): 0 rows in Customer, Property, CustomerActivity and User

## SQL export

File: `riverbank-supabase.sql`

- Encoding: UTF-8 without BOM
- Arabic sample: `C0109` = `احمد`
- SQL literals checked against the database: 1082 values, 0 missing
- Replacement characters: none
- Control characters: none
- Rows: 9 users, 339 customers, 343 properties, 21 activities, 5 settings

## Build checks

- `tsc --noEmit`: passed
- `next build`: passed
- `/api/health`: HTTP 200

## Re-run

```bash
node scripts/verify-all-data.cjs "D:\Ahmed Refay\Riverbank.xlsx"
node scripts/build-sql-export.cjs
node scripts/check-i18n.cjs
```
