const fs = require("fs");
const en = JSON.parse(fs.readFileSync("messages/en.json", "utf8"));
const ar = JSON.parse(fs.readFileSync("messages/ar.json", "utf8"));

function flatten(obj, prefix = "", out = {}) {
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === "object" && !Array.isArray(v)) flatten(v, key, out);
    else out[key] = v;
  }
  return out;
}

const fe = flatten(en);
const fa = flatten(ar);
const missing = Object.keys(fe).filter((k) => !(k in fa));
const extra = Object.keys(fa).filter((k) => !(k in fe));
const same = Object.keys(fe).filter((k) => k in fa && fe[k] === fa[k] && /[A-Za-z]/.test(String(fe[k])) && !/^[\d\s.,:;!?()\-–—/%+#'"@&]*$/.test(String(fe[k])));

console.log("missing in ar:", missing.length);
console.log(JSON.stringify(missing, null, 2));
console.log("extra in ar:", extra.length);
console.log(JSON.stringify(extra, null, 2));
console.log("identical values (review):", same.length);
for (const k of same) console.log(k, "=>", JSON.stringify(fe[k]));
