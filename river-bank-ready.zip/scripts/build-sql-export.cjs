/**
 * Builds riverbank-supabase.sql from the current database.
 *
 * Usage:
 *   node scripts/build-sql-export.cjs
 *
 * Requires DATABASE_URL in .env (loaded by Prisma automatically).
 * Output is UTF-8 without BOM so Arabic text stays intact in the SQL Editor.
 */
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");
const { PrismaClient } = require("@prisma/client");

const p = new PrismaClient();
const ROOT = path.resolve(__dirname, "..");
const SCHEMA = path.join(ROOT, "prisma", "schema.prisma");
const PG_SCHEMA = path.join(ROOT, "prisma", "schema.postgres.prisma");
const OUT = path.join(ROOT, "riverbank-supabase.sql");

function sqlVal(v) {
  if (v === null || v === undefined) return "NULL";
  if (v instanceof Date) return `'${v.toISOString()}'`;
  if (typeof v === "boolean") return v ? "TRUE" : "FALSE";
  if (typeof v === "number") return String(v);
  return `'${String(v).replace(/'/g, "''")}'`;
}

async function dump(model, table) {
  const rows = await p[model].findMany();
  if (rows.length === 0) return "";
  const cols = Object.keys(rows[0]);
  let out = "";
  for (const row of rows) {
    const vals = cols.map((c) => sqlVal(row[c]));
    out += `INSERT INTO "${table}" (${cols.map((c) => `"${c}"`).join(", ")}) VALUES (${vals.join(", ")});\n`;
  }
  return out;
}

function buildDdl() {
  const source = fs.readFileSync(SCHEMA, "utf8").replace(/^\uFEFF/, "");
  const pg = source
    .replace(/provider\s*=\s*"sqlite"/g, 'provider = "postgresql"')
    .replace(/^\uFEFF/, "");
  fs.writeFileSync(PG_SCHEMA, pg, "utf8");

  const prismaCli = path.join(ROOT, "node_modules", "prisma", "build", "index.js");
  return execFileSync(
    process.execPath,
    [prismaCli, "migrate", "diff", "--from-empty", "--to-schema-datamodel", PG_SCHEMA, "--script"],
    { encoding: "utf8", maxBuffer: 50 * 1024 * 1024 }
  );
}

async function main() {
  const ddl = buildDdl().replace(/^\uFEFF/, "");

  let data = "";
  data += await dump("user", "User");
  data += await dump("customer", "Customer");
  data += await dump("property", "Property");
  data += await dump("customerProperty", "CustomerProperty");
  data += await dump("propertyImage", "PropertyImage");
  data += await dump("deal", "Deal");
  data += await dump("customerActivity", "CustomerActivity");
  data += await dump("task", "Task");
  data += await dump("feedback", "Feedback");
  data += await dump("setting", "Setting");
  data += await dump("synonym", "Synonym");
  data += await dump("savedSearch", "SavedSearch");

  const header = [
    "-- RiverBank CRM - Supabase / PostgreSQL import",
    "-- Generated from the live database (source: Riverbank.xlsx)",
    "-- Run this whole file in the Supabase SQL Editor on a fresh project.",
    "-- Encoding: UTF-8 without BOM.",
    "--",
    "-- SECURITY: this file contains real CRM data and password hashes.",
    "-- Keep it private. Never publish it or commit it to a public repository.",
    "",
    "BEGIN;",
    "",
    "-- =====================================================================",
    "-- 1) Schema",
    "-- =====================================================================",
    "",
  ].join("\n");

  const footer = [
    "",
    "-- =====================================================================",
    "-- 2) Done",
    "-- =====================================================================",
    "",
    "COMMIT;",
    "",
    "-- NOTE: SearchIndex is derived data. Rebuild it after import:",
    "--   npx tsx scripts/search-reindex.ts",
    "",
  ].join("\n");

  const sql =
    header +
    ddl.trimEnd() +
    "\n\n-- =====================================================================\n-- Data\n-- =====================================================================\n\n" +
    data.trimEnd() +
    "\n" +
    footer;

  fs.writeFileSync(OUT, sql, "utf8");
  fs.rmSync(PG_SCHEMA, { force: true });

  const buf = fs.readFileSync(OUT);
  const text = buf.toString("utf8");

  const problems = [];
  if (buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) problems.push("BOM present");
  if (text.includes("\uFFFD")) problems.push("replacement character present");
  if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(text)) problems.push("control characters present");

  const counts = {};
  for (const table of ["User", "Customer", "Property", "CustomerProperty", "Deal", "CustomerActivity", "Task", "Feedback", "Setting", "Synonym", "SavedSearch"]) {
    counts[table] = (text.match(new RegExp(`INSERT INTO "${table}"`, "g")) || []).length;
  }

  console.log(JSON.stringify({
    file: OUT,
    bytes: buf.length,
    bom: false,
    counts,
    problems: problems.length ? problems : "none",
  }, null, 2));

  if (problems.length) process.exitCode = 1;
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => p.$disconnect());
