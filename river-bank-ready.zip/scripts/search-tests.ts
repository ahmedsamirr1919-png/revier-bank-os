import assert from "node:assert/strict";
import { normalizeArabic, normalizeText, normalizePhone } from "../src/lib/search/normalize";

function run() {
  assert.equal(normalizeArabic("أحمد"), "احمد");
  assert.equal(normalizeArabic("يحيى"), "يحيي");
  assert.equal(normalizeArabic("Fatimah"), "Fatimah");
  assert.equal(normalizeArabic("مريم"), "مريم");
  assert.equal(normalizeArabic("١٢٣"), "123");
  assert.equal(normalizeArabic("۴۵۶"), "456");
  assert.equal(normalizeText("  Hello   World  "), "hello world");
  assert.equal(normalizeText("أَحْمَد"), "احمد");
  assert.equal(normalizePhone("+971 50 123 4567"), "501234567");
  assert.equal(normalizePhone("00971501234567"), "501234567");
  assert.equal(normalizePhone("0501234567"), "501234567");
  assert.equal(normalizePhone("+20 10 1234 5678"), "1012345678");
  console.log("All search normalization tests passed.");
}

run();
