const { PrismaClient } = require("@prisma/client");
const X = require("xlsx");
const fs = require("fs");

const p = new PrismaClient();
const EXCEL_PATH =
  process.argv[2] ||
  (fs.existsSync("E:\\Riverbank.xlsx") ? "E:\\Riverbank.xlsx" : "D:\\Ahmed Refay\\Riverbank.xlsx");
const wb = X.readFile(EXCEL_PATH);
console.log("Source file:", EXCEL_PATH);

function clean(v) {
  if (v === null || v === undefined) return null;
  if (typeof v === "string") {
    const s = v.trim();
    if (s === "" || s.toLowerCase() === "null") return null;
    return s;
  }
  return v;
}
function norm(v) {
  if (v === null || v === undefined) return null;
  return String(v).replace(/\s+/g, " ").trim();
}
function isMojibake(s) {
  if (typeof s !== "string") return false;
  // Typical UTF-8 -> Latin-1 double encoding artifacts
  if (/[ÃÂ][\u0080-\u00bf]/.test(s)) return true;
  if (/[ØÙ][\u0080-\u00bf\u2018-\u203a]/.test(s)) return true;
  if (s.includes("\u00d8") || s.includes("\u00d9")) return true;
  return false;
}

function normPhone(v) {
  if (v === null || v === undefined) return null;
  return String(v).replace(/[^\d+]/g, "");
}

async function main() {
  const report = {};

  // ---------------- Customers ----------------
  const clientRows = X.utils
    .sheet_to_json(wb.Sheets["Clients"], { defval: null })
    .filter((r) => clean(r["Client ID"]) && clean(r["name"]) && clean(r["Phone"]));

  const dbCustomers = await p.customer.findMany({
    select: { code: true, fullName: true, phone: true },
  });
  const dbCustMap = new Map(dbCustomers.map((c) => [c.code, c]));

  const custMissing = [];
  const custNameMismatch = [];
  const custPhoneMismatch = [];
  const custMojibake = [];

  for (const r of clientRows) {
    const code = clean(r["Client ID"]);
    const name = clean(r["name"]);
    const phone = clean(r["Phone"]);
    const db = dbCustMap.get(code);
    if (!db) {
      custMissing.push(code);
      continue;
    }
    if (norm(name) !== norm(db.fullName)) {
      custNameMismatch.push({ code, excel: name, db: db.fullName });
    }
    if (normPhone(phone) !== normPhone(db.phone)) {
      custPhoneMismatch.push({ code, excel: phone, db: db.phone });
    }
    if (isMojibake(db.fullName)) custMojibake.push({ code, value: db.fullName });
  }

  report.customers = {
    excel: clientRows.length,
    db: dbCustomers.length,
    missingInDb: custMissing.length,
    extraInDb: dbCustomers.filter((c) => !clientRows.some((r) => clean(r["Client ID"]) === c.code)).length,
    nameMismatches: custNameMismatch.length,
    phoneMismatches: custPhoneMismatch.length,
    mojibake: custMojibake.length,
    samples: {
      missing: custMissing.slice(0, 5),
      nameMismatch: custNameMismatch.slice(0, 5),
      phoneMismatch: custPhoneMismatch.slice(0, 5),
    },
  };

  // ---------------- Properties ----------------
  const propRows = X.utils
    .sheet_to_json(wb.Sheets["Properties"], { defval: null })
    .filter((r) => clean(r["Property ID"]) && r["Price Numeric"] && r["Area Numeric"]);

  const dbProps = await p.property.findMany({
    select: {
      code: true, title: true, location: true, price: true, area: true,
      ownerName: true, ownerPhone: true, bedrooms: true, bathrooms: true,
    },
  });
  const dbPropMap = new Map(dbProps.map((x) => [x.code, x]));

  const propMissing = [];
  const propTitleMismatch = [];
  const propLocMismatch = [];
  const propPriceMismatch = [];
  const propAreaMismatch = [];
  const propOwnerMismatch = [];
  const propMojibake = [];

  for (const r of propRows) {
    const code = clean(r["Property ID"]);
    const db = dbPropMap.get(code);
    if (!db) {
      propMissing.push(code);
      continue;
    }
    const excelTitle = norm(clean(r["Address"]));
    if (excelTitle && excelTitle !== norm(db.title)) {
      propTitleMismatch.push({ code, excel: excelTitle, db: db.title });
    }
    const excelLoc = norm(clean(r["Location"]));
    if (excelLoc && excelLoc !== norm(db.location)) {
      propLocMismatch.push({ code, excel: excelLoc, db: db.location });
    }
    const excelPrice = Math.round(Number(r["Price Numeric"]));
    if (excelPrice !== db.price) {
      propPriceMismatch.push({ code, excel: excelPrice, db: db.price });
    }
    const excelArea = Number(r["Area Numeric"]);
    if (Math.abs(excelArea - db.area) > 0.01) {
      propAreaMismatch.push({ code, excel: excelArea, db: db.area });
    }
    const excelOwner = norm(clean(r["Client / Owner"]));
    if (excelOwner !== norm(db.ownerName)) {
      propOwnerMismatch.push({ code, excel: excelOwner, db: db.ownerName });
    }
    if (isMojibake(db.title) || isMojibake(db.location) || isMojibake(db.ownerName)) {
      propMojibake.push({ code, title: db.title, location: db.location, owner: db.ownerName });
    }
  }

  report.properties = {
    excel: propRows.length,
    db: dbProps.length,
    missingInDb: propMissing.length,
    extraInDb: dbProps.filter((x) => !propRows.some((r) => clean(r["Property ID"]) === x.code)).length,
    titleMismatches: propTitleMismatch.length,
    locationMismatches: propLocMismatch.length,
    priceMismatches: propPriceMismatch.length,
    areaMismatches: propAreaMismatch.length,
    ownerMismatches: propOwnerMismatch.length,
    mojibake: propMojibake.length,
    samples: {
      missing: propMissing.slice(0, 5),
      titleMismatch: propTitleMismatch.slice(0, 5),
      locationMismatch: propLocMismatch.slice(0, 5),
      priceMismatch: propPriceMismatch.slice(0, 5),
      ownerMismatch: propOwnerMismatch.slice(0, 5),
      mojibake: propMojibake.slice(0, 5),
    },
  };

  // ---------------- Activities ----------------
  const actRows = X.utils
    .sheet_to_json(wb.Sheets["Activities"], { defval: null })
    .filter((r) => clean(r["Client ID"]));
  const dbActs = await p.customerActivity.count();
  const actMojibake = await p.customerActivity.findMany({
    where: { OR: [{ title: { contains: "Ø" } }, { body: { contains: "Ø" } }, { outcome: { contains: "Ø" } }] },
    select: { id: true },
  });

  report.activities = {
    excel: actRows.length,
    db: dbActs,
    mojibake: actMojibake.length,
  };

  // ---------------- Users ----------------
  const userRows = X.utils
    .sheet_to_json(wb.Sheets["Users"], { defval: null })
    .filter((r) => clean(r["__EMPTY"]) && clean(r["RIVERBANK PROPERTIES  |  USERS & ACCESS"]));
  const userNames = userRows
    .map((r) => clean(r["__EMPTY"]))
    .filter((n) => n && n !== "Username" && !/^(my clients|dashboard)$/i.test(n));
  const dbUsers = await p.user.findMany({ select: { email: true, name: true } });
  const localUsers = dbUsers.filter((u) => u.email.endsWith("@riverbank.local"));
  const missingUsers = userNames.filter(
    (n) => !dbUsers.some((u) => u.email === `${n.toLowerCase()}@riverbank.local`)
  );

  report.users = {
    excelUsernames: userNames.length,
    excelUsernamesList: userNames,
    dbTotal: dbUsers.length,
    dbLocal: localUsers.length,
    missingLocal: missingUsers,
  };

  // ---------------- SQL export check ----------------
  const sqlPath = "riverbank-supabase.sql";
  if (fs.existsSync(sqlPath)) {
    const buf = fs.readFileSync(sqlPath);
    const text = buf.toString("utf8");
    const parse = (t) => (text.match(new RegExp(`INSERT INTO "${t}"`, "g")) || []).length;
    const idx = text.indexOf("'C0109'");
    let arabic = null;
    if (idx >= 0) {
      const s = text.lastIndexOf("INSERT INTO", idx);
      const e = text.indexOf("\n", idx);
      const line = text.slice(s, e);
      const m = line.match(/VALUES \('[^']*', 'C0109', '([^']*)'/);
      arabic = m ? m[1] : null;
    }
    report.sqlExport = {
      bytes: buf.length,
      hasBom: buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf,
      hasMojibake: text.includes("Ø") || text.includes("Ù"),
      counts: {
        User: parse("User"),
        Customer: parse("Customer"),
        Property: parse("Property"),
        CustomerActivity: parse("CustomerActivity"),
      },
      c0109Name: arabic,
    };
  }

  // ---------------- SQL export content check ----------------
  if (fs.existsSync(sqlPath)) {
    const text = fs.readFileSync(sqlPath, "utf8").replace(/^\uFEFF/, "");

    const esc = (v) => (v === null || v === undefined ? null : String(v).replace(/'/g, "''"));

    const missingFromSql = { customers: [], properties: [], activities: [] };
    let checked = 0;

    for (const c of dbCustomers) {
      const lit = esc(c.fullName);
      if (!lit) continue;
      checked++;
      if (!text.includes(`'${lit}'`)) missingFromSql.customers.push({ code: c.code, value: c.fullName });
    }
    for (const x of dbProps) {
      for (const val of [x.title, x.location, x.ownerName]) {
        const lit = esc(val);
        if (!lit) continue;
        checked++;
        if (!text.includes(`'${lit}'`)) missingFromSql.properties.push({ code: x.code, value: val });
      }
    }
    const dbActRows = await p.customerActivity.findMany({ select: { id: true, body: true, title: true } });
    for (const a of dbActRows) {
      for (const val of [a.title, a.body]) {
        const lit = esc(val);
        if (!lit) continue;
        checked++;
        if (!text.includes(`'${lit}'`)) missingFromSql.activities.push({ id: a.id, value: val });
      }
    }

    report.sqlExport.contentCheck = {
      valuesChecked: checked,
      missing: missingFromSql.customers.length + missingFromSql.properties.length + missingFromSql.activities.length,
      sampleMissing: {
        customers: missingFromSql.customers.slice(0, 5),
        properties: missingFromSql.properties.slice(0, 5),
        activities: missingFromSql.activities.slice(0, 5),
      },
      hasReplacementChar: text.includes("\uFFFD"),
      hasControlChars: /[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(text),
    };
  }

  // Overall verdict
  const sqlProblems = report.sqlExport && report.sqlExport.contentCheck
    ? report.sqlExport.contentCheck.missing +
      (report.sqlExport.contentCheck.hasReplacementChar ? 1 : 0) +
      (report.sqlExport.contentCheck.hasControlChars ? 1 : 0) +
      (report.sqlExport.hasBom ? 1 : 0)
    : 0;

  const problems =
    custMissing.length + custNameMismatch.length + custPhoneMismatch.length + custMojibake.length +
    propMissing.length + propTitleMismatch.length + propLocMismatch.length +
    propPriceMismatch.length + propAreaMismatch.length + propOwnerMismatch.length + propMojibake.length +
    actMojibake.length + missingUsers.length + sqlProblems;

  report.verdict = problems === 0 ? "ALL CHECKS PASSED" : `${problems} PROBLEM(S) FOUND`;
  report.generatedAt = new Date().toISOString();

  fs.writeFileSync("data-verification-report.json", JSON.stringify(report, null, 2), "utf8");
  console.log(JSON.stringify(report, null, 2));
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => p.$disconnect());
