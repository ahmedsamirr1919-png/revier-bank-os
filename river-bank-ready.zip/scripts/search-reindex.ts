import { PrismaClient } from "@prisma/client";
import { buildSearchBody, normalizeText } from "../src/lib/search/normalize";

const prisma = new PrismaClient();

async function upsertIndex(entityType: string, entityId: string, title: string, subtitle: string | null, body: string, ownerAgentId: string | null) {
  const normalizedText = normalizeText([title, subtitle, body].filter(Boolean).join(" "));
  await prisma.searchIndex.upsert({
    where: { entityType_entityId: { entityType, entityId } },
    update: { title, subtitle, body, normalizedText, ownerAgentId, updatedAt: new Date() },
    create: { entityType, entityId, title, subtitle, body, normalizedText, ownerAgentId },
  });
}

async function main() {
  console.log("Reindexing search index...");

  // Rebuild from scratch so rows for deleted or reseeded records do not linger.
  await prisma.searchIndex.deleteMany();

  const customers = await prisma.customer.findMany({ where: { isDeleted: false } });
  for (const c of customers) {
    await upsertIndex(
      "customer",
      c.id,
      c.fullName,
      c.code,
      buildSearchBody([c.phone, c.email, c.whatsapp, c.preferredArea, c.notes, c.source, c.status]),
      c.assignedAgentId,
    );
  }

  const properties = await prisma.property.findMany({ where: { isDeleted: false } });
  for (const p of properties) {
    await upsertIndex(
      "property",
      p.id,
      p.title,
      p.code,
      buildSearchBody([
        p.location,
        p.city,
        p.type,
        p.status,
        p.description,
        p.ownerName,
        p.ownerPhone,
        p.ownerEmail,
        p.ownerIdNumber,
        p.ownerNotes,
        p.tags,
      ]),
      p.createdById,
    );
  }

  const deals = await prisma.deal.findMany({ where: { isDeleted: false } });
  for (const d of deals) {
    await upsertIndex(
      "deal",
      d.id,
      d.title,
      d.code,
      buildSearchBody([d.stage, d.notes, String(d.value), d.lostReason]),
      d.agentId,
    );
  }

  const tasks = await prisma.task.findMany();
  for (const t of tasks) {
    await upsertIndex(
      "task",
      t.id,
      t.title,
      t.type,
      buildSearchBody([t.description, t.status, t.priority]),
      t.assignedToId,
    );
  }

  const feedback = await prisma.feedback.findMany();
  for (const f of feedback) {
    const customer = f.customerId ? await prisma.customer.findUnique({ where: { id: f.customerId }, select: { fullName: true } }) : null;
    await upsertIndex(
      "feedback",
      f.id,
      customer?.fullName ?? f.submittedByName ?? "Feedback",
      f.status,
      buildSearchBody([f.comment, f.categories, String(f.rating)]),
      f.agentId,
    );
  }

  console.log("Reindex complete.");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
